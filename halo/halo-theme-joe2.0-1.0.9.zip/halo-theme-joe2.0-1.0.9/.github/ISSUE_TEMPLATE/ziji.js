(function (e) {
    var t = {};

    function n(o) {
        if (t[o]) return t[o].exports;
        var r = t[o] = {
            i: o,
            l: !1,
            exports: {}
        };
        return e[o].call(r.exports, r, r.exports, n), r.l = !0, r.exports
    }
    n.m = e, n.c = t, n.d = function (e, t, o) {
        n.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: o
        })
    }, n.r = function (e) {
        "undefined" !== typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, n.t = function (e, t) {
        if (1 & t && (e = n(e)), 8 & t) return e;
        if (4 & t && "object" === typeof e && e && e.__esModule) return e;
        var o = Object.create(null);
        if (n.r(o), Object.defineProperty(o, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
            for (var r in e) n.d(o, r, function (t) {
                return e[t]
            }.bind(null, r));
        return o
    }, n.n = function (e) {
        var t = e && e.__esModule ? function () {
            return e["default"]
        } : function () {
            return e
        };
        return n.d(t, "a", t), t
    }, n.o = function (e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, n.p = "", n(n.s = "5a74")
})({
    "00ce": function (e, t, n) {
        "use strict";
        var o, r = SyntaxError,
            i = Function,
            a = TypeError,
            s = function (e) {
                try {
                    return i('"use strict"; return (' + e + ").constructor;")()
                } catch (t) {}
            },
            c = Object.getOwnPropertyDescriptor;
        if (c) try {
            c({}, "")
        } catch (E) {
            c = null
        }
        var l = function () {
                throw new a
            },
            u = c ? function () {
                try {
                    return l
                } catch (e) {
                    try {
                        return c(arguments, "callee").get
                    } catch (t) {
                        return l
                    }
                }
            }() : l,
            m = n("5156")(),
            p = Object.getPrototypeOf || function (e) {
                return e.__proto__
            },
            d = {},
            h = "undefined" === typeof Uint8Array ? o : p(Uint8Array),
            f = {
                "%AggregateError%": "undefined" === typeof AggregateError ? o : AggregateError,
                "%Array%": Array,
                "%ArrayBuffer%": "undefined" === typeof ArrayBuffer ? o : ArrayBuffer,
                "%ArrayIteratorPrototype%": m ? p([][Symbol.iterator]()) : o,
                "%AsyncFromSyncIteratorPrototype%": o,
                "%AsyncFunction%": d,
                "%AsyncGenerator%": d,
                "%AsyncGeneratorFunction%": d,
                "%AsyncIteratorPrototype%": d,
                "%Atomics%": "undefined" === typeof Atomics ? o : Atomics,
                "%BigInt%": "undefined" === typeof BigInt ? o : BigInt,
                "%Boolean%": Boolean,
                "%DataView%": "undefined" === typeof DataView ? o : DataView,
                "%Date%": Date,
                "%decodeURI%": decodeURI,
                "%decodeURIComponent%": decodeURIComponent,
                "%encodeURI%": encodeURI,
                "%encodeURIComponent%": encodeURIComponent,
                "%Error%": Error,
                "%eval%": eval,
                "%EvalError%": EvalError,
                "%Float32Array%": "undefined" === typeof Float32Array ? o : Float32Array,
                "%Float64Array%": "undefined" === typeof Float64Array ? o : Float64Array,
                "%FinalizationRegistry%": "undefined" === typeof FinalizationRegistry ? o : FinalizationRegistry,
                "%Function%": i,
                "%GeneratorFunction%": d,
                "%Int8Array%": "undefined" === typeof Int8Array ? o : Int8Array,
                "%Int16Array%": "undefined" === typeof Int16Array ? o : Int16Array,
                "%Int32Array%": "undefined" === typeof Int32Array ? o : Int32Array,
                "%isFinite%": isFinite,
                "%isNaN%": isNaN,
                "%IteratorPrototype%": m ? p(p([][Symbol.iterator]())) : o,
                "%JSON%": "object" === typeof JSON ? JSON : o,
                "%Map%": "undefined" === typeof Map ? o : Map,
                "%MapIteratorPrototype%": "undefined" !== typeof Map && m ? p((new Map)[Symbol.iterator]()) : o,
                "%Math%": Math,
                "%Number%": Number,
                "%Object%": Object,
                "%parseFloat%": parseFloat,
                "%parseInt%": parseInt,
                "%Promise%": "undefined" === typeof Promise ? o : Promise,
                "%Proxy%": "undefined" === typeof Proxy ? o : Proxy,
                "%RangeError%": RangeError,
                "%ReferenceError%": ReferenceError,
                "%Reflect%": "undefined" === typeof Reflect ? o : Reflect,
                "%RegExp%": RegExp,
                "%Set%": "undefined" === typeof Set ? o : Set,
                "%SetIteratorPrototype%": "undefined" !== typeof Set && m ? p((new Set)[Symbol.iterator]()) : o,
                "%SharedArrayBuffer%": "undefined" === typeof SharedArrayBuffer ? o : SharedArrayBuffer,
                "%String%": String,
                "%StringIteratorPrototype%": m ? p("" [Symbol.iterator]()) : o,
                "%Symbol%": m ? Symbol : o,
                "%SyntaxError%": r,
                "%ThrowTypeError%": u,
                "%TypedArray%": h,
                "%TypeError%": a,
                "%Uint8Array%": "undefined" === typeof Uint8Array ? o : Uint8Array,
                "%Uint8ClampedArray%": "undefined" === typeof Uint8ClampedArray ? o : Uint8ClampedArray,
                "%Uint16Array%": "undefined" === typeof Uint16Array ? o : Uint16Array,
                "%Uint32Array%": "undefined" === typeof Uint32Array ? o : Uint32Array,
                "%URIError%": URIError,
                "%WeakMap%": "undefined" === typeof WeakMap ? o : WeakMap,
                "%WeakRef%": "undefined" === typeof WeakRef ? o : WeakRef,
                "%WeakSet%": "undefined" === typeof WeakSet ? o : WeakSet
            },
            b = function e(t) {
                var n;
                if ("%AsyncFunction%" === t) n = s("async function () {}");
                else if ("%GeneratorFunction%" === t) n = s("function* () {}");
                else if ("%AsyncGeneratorFunction%" === t) n = s("async function* () {}");
                else if ("%AsyncGenerator%" === t) {
                    var o = e("%AsyncGeneratorFunction%");
                    o && (n = o.prototype)
                } else if ("%AsyncIteratorPrototype%" === t) {
                    var r = e("%AsyncGenerator%");
                    r && (n = p(r.prototype))
                }
                return f[t] = n, n
            },
            g = {
                "%ArrayBufferPrototype%": ["ArrayBuffer", "prototype"],
                "%ArrayPrototype%": ["Array", "prototype"],
                "%ArrayProto_entries%": ["Array", "prototype", "entries"],
                "%ArrayProto_forEach%": ["Array", "prototype", "forEach"],
                "%ArrayProto_keys%": ["Array", "prototype", "keys"],
                "%ArrayProto_values%": ["Array", "prototype", "values"],
                "%AsyncFunctionPrototype%": ["AsyncFunction", "prototype"],
                "%AsyncGenerator%": ["AsyncGeneratorFunction", "prototype"],
                "%AsyncGeneratorPrototype%": ["AsyncGeneratorFunction", "prototype", "prototype"],
                "%BooleanPrototype%": ["Boolean", "prototype"],
                "%DataViewPrototype%": ["DataView", "prototype"],
                "%DatePrototype%": ["Date", "prototype"],
                "%ErrorPrototype%": ["Error", "prototype"],
                "%EvalErrorPrototype%": ["EvalError", "prototype"],
                "%Float32ArrayPrototype%": ["Float32Array", "prototype"],
                "%Float64ArrayPrototype%": ["Float64Array", "prototype"],
                "%FunctionPrototype%": ["Function", "prototype"],
                "%Generator%": ["GeneratorFunction", "prototype"],
                "%GeneratorPrototype%": ["GeneratorFunction", "prototype", "prototype"],
                "%Int8ArrayPrototype%": ["Int8Array", "prototype"],
                "%Int16ArrayPrototype%": ["Int16Array", "prototype"],
                "%Int32ArrayPrototype%": ["Int32Array", "prototype"],
                "%JSONParse%": ["JSON", "parse"],
                "%JSONStringify%": ["JSON", "stringify"],
                "%MapPrototype%": ["Map", "prototype"],
                "%NumberPrototype%": ["Number", "prototype"],
                "%ObjectPrototype%": ["Object", "prototype"],
                "%ObjProto_toString%": ["Object", "prototype", "toString"],
                "%ObjProto_valueOf%": ["Object", "prototype", "valueOf"],
                "%PromisePrototype%": ["Promise", "prototype"],
                "%PromiseProto_then%": ["Promise", "prototype", "then"],
                "%Promise_all%": ["Promise", "all"],
                "%Promise_reject%": ["Promise", "reject"],
                "%Promise_resolve%": ["Promise", "resolve"],
                "%RangeErrorPrototype%": ["RangeError", "prototype"],
                "%ReferenceErrorPrototype%": ["ReferenceError", "prototype"],
                "%RegExpPrototype%": ["RegExp", "prototype"],
                "%SetPrototype%": ["Set", "prototype"],
                "%SharedArrayBufferPrototype%": ["SharedArrayBuffer", "prototype"],
                "%StringPrototype%": ["String", "prototype"],
                "%SymbolPrototype%": ["Symbol", "prototype"],
                "%SyntaxErrorPrototype%": ["SyntaxError", "prototype"],
                "%TypedArrayPrototype%": ["TypedArray", "prototype"],
                "%TypeErrorPrototype%": ["TypeError", "prototype"],
                "%Uint8ArrayPrototype%": ["Uint8Array", "prototype"],
                "%Uint8ClampedArrayPrototype%": ["Uint8ClampedArray", "prototype"],
                "%Uint16ArrayPrototype%": ["Uint16Array", "prototype"],
                "%Uint32ArrayPrototype%": ["Uint32Array", "prototype"],
                "%URIErrorPrototype%": ["URIError", "prototype"],
                "%WeakMapPrototype%": ["WeakMap", "prototype"],
                "%WeakSetPrototype%": ["WeakSet", "prototype"]
            },
            y = n("0f7c"),
            w = n("a0d3"),
            v = y.call(Function.call, Array.prototype.concat),
            x = y.call(Function.apply, Array.prototype.splice),
            k = y.call(Function.call, String.prototype.replace),
            j = y.call(Function.call, String.prototype.slice),
            S =
            /[^%.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|%$))/g,
            _ = /\\(\\)?/g,
            A = function (e) {
                var t = j(e, 0, 1),
                    n = j(e, -1);
                if ("%" === t && "%" !== n) throw new r("invalid intrinsic syntax, expected closing `%`");
                if ("%" === n && "%" !== t) throw new r("invalid intrinsic syntax, expected opening `%`");
                var o = [];
                return k(e, S, (function (e, t, n, r) {
                    o[o.length] = n ? k(r, _, "$1") : t || e
                })), o
            },
            C = function (e, t) {
                var n, o = e;
                if (w(g, o) && (n = g[o], o = "%" + n[0] + "%"), w(f, o)) {
                    var i = f[o];
                    if (i === d && (i = b(o)), "undefined" === typeof i && !t) throw new a("intrinsic " + e +
                        " exists, but is not available. Please file an issue!");
                    return {
                        alias: n,
                        name: o,
                        value: i
                    }
                }
                throw new r("intrinsic " + e + " does not exist!")
            };
        e.exports = function (e, t) {
            if ("string" !== typeof e || 0 === e.length) throw new a(
                "intrinsic name must be a non-empty string");
            if (arguments.length > 1 && "boolean" !== typeof t) throw new a(
                '"allowMissing" argument must be a boolean');
            var n = A(e),
                o = n.length > 0 ? n[0] : "",
                i = C("%" + o + "%", t),
                s = i.name,
                l = i.value,
                u = !1,
                m = i.alias;
            m && (o = m[0], x(n, v([0, 1], m)));
            for (var p = 1, d = !0; p < n.length; p += 1) {
                var h = n[p],
                    b = j(h, 0, 1),
                    g = j(h, -1);
                if (('"' === b || "'" === b || "`" === b || '"' === g || "'" === g || "`" === g) && b !==
                    g) throw new r("property names with quotes must have matching quotes");
                if ("constructor" !== h && d || (u = !0), o += "." + h, s = "%" + o + "%", w(f, s)) l = f[s];
                else if (null != l) {
                    if (!(h in l)) {
                        if (!t) throw new a("base intrinsic for " + e +
                            " exists, but the property is not available.");
                        return
                    }
                    if (c && p + 1 >= n.length) {
                        var y = c(l, h);
                        d = !!y, l = d && "get" in y && !("originalValue" in y.get) ? y.get : l[h]
                    } else d = w(l, h), l = l[h];
                    d && !u && (f[s] = l)
                }
            }
            return l
        }
    },
    "00d8": function (e, t) {
        (function () {
            var t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
                n = {
                    rotl: function (e, t) {
                        return e << t | e >>> 32 - t
                    },
                    rotr: function (e, t) {
                        return e << 32 - t | e >>> t
                    },
                    endian: function (e) {
                        if (e.constructor == Number) return 16711935 & n.rotl(e, 8) | 4278255360 & n.rotl(
                            e, 24);
                        for (var t = 0; t < e.length; t++) e[t] = n.endian(e[t]);
                        return e
                    },
                    randomBytes: function (e) {
                        for (var t = []; e > 0; e--) t.push(Math.floor(256 * Math.random()));
                        return t
                    },
                    bytesToWords: function (e) {
                        for (var t = [], n = 0, o = 0; n < e.length; n++, o += 8) t[o >>> 5] |= e[n] <<
                            24 - o % 32;
                        return t
                    },
                    wordsToBytes: function (e) {
                        for (var t = [], n = 0; n < 32 * e.length; n += 8) t.push(e[n >>> 5] >>> 24 - n %
                            32 & 255);
                        return t
                    },
                    bytesToHex: function (e) {
                        for (var t = [], n = 0; n < e.length; n++) t.push((e[n] >>> 4).toString(16)), t
                            .push((15 & e[n]).toString(16));
                        return t.join("")
                    },
                    hexToBytes: function (e) {
                        for (var t = [], n = 0; n < e.length; n += 2) t.push(parseInt(e.substr(n, 2),
                            16));
                        return t
                    },
                    bytesToBase64: function (e) {
                        for (var n = [], o = 0; o < e.length; o += 3)
                            for (var r = e[o] << 16 | e[o + 1] << 8 | e[o + 2], i = 0; i < 4; i++) 8 *
                                o + 6 * i <= 8 * e.length ? n.push(t.charAt(r >>> 6 * (3 - i) & 63)) :
                                n.push("=");
                        return n.join("")
                    },
                    base64ToBytes: function (e) {
                        e = e.replace(/[^A-Z0-9+\/]/gi, "");
                        for (var n = [], o = 0, r = 0; o < e.length; r = ++o % 4) 0 != r && n.push((t.indexOf(
                            e.charAt(o - 1)) & Math.pow(2, -2 * r + 8) - 1) << 2 * r | t.indexOf(
                            e.charAt(o)) >>> 6 - 2 * r);
                        return n
                    }
                };
            e.exports = n
        })()
    },
    "00ee": function (e, t, n) {
        var o = n("b622"),
            r = o("toStringTag"),
            i = {};
        i[r] = "z", e.exports = "[object z]" === String(i)
    },
    "044b": function (e, t) {
        function n(e) {
            return !!e.constructor && "function" === typeof e.constructor.isBuffer && e.constructor.isBuffer(e)
        }

        function o(e) {
            return "function" === typeof e.readFloatLE && "function" === typeof e.slice && n(e.slice(0, 0))
        }
        /*!
         * Determine if an object is a Buffer
         *
         * @author   Feross Aboukhadijeh <https://feross.org>
         * @license  MIT
         */
        e.exports = function (e) {
            return null != e && (n(e) || o(e) || !!e._isBuffer)
        }
    },
    "063c": function (e, t, n) {
        "use strict";
        var o = n("bc3a"),
            r = n.n(o);
        n("09bd").shim();
        const i = r.a.create({
            baseURL: "",
            timeout: 5e3,
            withCredentials: !0
        });
        i.interceptors.request.use(e => e, e => Promise.reject(e)), i.interceptors.response.use(e => e, e => {
            if (r.a.isCancel(e)) return Promise.reject(e);
            const t = e.response,
                n = t ? t.data : null;
            return n && (400 === n.status || 401 === n.status || 403 === n.status || 404 === n.status ||
                n.status), Promise.reject(e)
        });
        var a = i;
        const s = "/api/content",
            c = "/api/admin",
            l = {};
        let u;
        const m = async e => {
            const t = {
                response: {
                    status: 400,
                    data: {
                        message: "undefined error"
                    }
                }
            };
            let n = "",
                o = "",
                i = "";
            if (e && e.blogAdminUserName) o = e.blogAdminUserName;
            else if (o = prompt("「身份验证」您是博主，请输入用户名:", ""), !o) throw console.log("您取消了用户名的输入"), t.response
                .data.message = "您取消了用户名的输入", t;
            if (i = prompt("「身份验证」您是博主，请输入密码:", ""), !i) throw console.log("您取消了密码的输入"), t.response.data
                .message = "您取消了密码的输入", t;
            try {
                const e = await r.a.post(c + "/login", {
                    password: i,
                    username: o
                });
                if (e.status >= 400) throw console.error("身份验证失败, 您的用户名/密码不正确, loginResult:", e), t.response
                    .data.message = "身份验证失败, 您的用户名/密码不正确", t;
                return n = e.data.data.access_token, localStorage.setItem("halo__Access-Token", JSON.stringify({
                    expire: Date.now(),
                    value: e.data.data
                })), {
                    adminUserName: o,
                    adminUserPwd: i,
                    adminAuthorization: n
                }
            } catch (a) {
                throw console.error("身份验证失败, 您的用户名/密码不正确, err1:", a, " ,errResponse:", a && a.response),
                    t.response.data.message = "身份验证失败, 您的用户名/密码不正确", t
            }
        }, p = () => {
            let e = void 0;
            const t = localStorage.getItem("halo__Access-Token");
            if (t) try {
                const {
                    expire: n,
                    value: o
                } = JSON.parse(t);
                if (n && o && "object" === typeof o) {
                    const {
                        access_token: t,
                        expired_in: r
                    } = o;
                    n + 1e3 * r > Date.now() && (e = t)
                }
            } catch (n) {
                console.error("catch err:", n, " ,cacheAdminAccessTokenStr:", t)
            }
            return e
        }, d = e => {
            const t = (e.content || "").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g,
                    "&").replace(/&quot;/g, '"').replace(/&apos;/g, "'"),
                n = t.split('<i style="display: none;" class="qiushaocloud_comment_extra_json">');
            if (n && n.length >= 2) {
                e.content = n[0] || "";
                const t = n[1];
                if (t) try {
                    const {
                        avatar: n,
                        ip: o,
                        location: r
                    } = JSON.parse(window.decodeURIComponent(t.substring(0, t.lastIndexOf("</i>"))));
                    e.avatarFromContent = n, e.ipAddress === o && (e.ipLocation = r)
                } catch (r) {
                    console.error("JSON.parse catch err:", r, n, e)
                }
            }
            const o = e.children;
            if (o && Array.isArray(o) && o.length)
                for (const i of o) d(i)
        }, h = async (e, t = {}, n) => {
            e.headers = e.headers || {};
            const {
                blogAuthorEmail: o
            } = t, r = n || localStorage.getItem("qiushaocloud-halo-comment-email");
            let i = !1,
                s = "",
                c = "",
                l = "";
            if (o && r && o === r) {
                if (s = p(), !s) try {
                    const {
                        adminUserName: e,
                        adminUserPwd: n,
                        adminAuthorization: o
                    } = await m(t);
                    c = e, l = n, s = o
                } catch (h) {
                    throw h
                }
                e.headers["Admin-Authorization"] = s, i = !0
            }
            let u = void 0,
                d = void 0;
            try {
                u = await a(e)
            } catch (f) {
                if (i && !c && !l && f.response && 401 === f.response.status) {
                    try {
                        const {
                            adminUserName: e,
                            adminUserPwd: n,
                            adminAuthorization: o
                        } = await m(t);
                        c = e, l = n, s = o
                    } catch (h) {
                        throw h
                    }
                    e.headers["Admin-Authorization"] = s;
                    try {
                        u = await a(e)
                    } catch (b) {
                        d = b
                    }
                } else d = f
            }
            if (d) throw d;
            return u
        };
        l.createComment = async (e, t, n = {}) => {
            const {
                isGetIpLocation: o,
                blogAuthorEmail: i
            } = n, l = {}, m = Object.assign({}, t), p = t.email;
            let f = void 0,
                b = void 0,
                g = `${s}/${e}/comments`,
                y = i && i === p;
            if (o) try {
                u || (u = await r.a.get("https://www.qiushaocloud.top/get_ip_location").then(e => {
                    if (e.status >= 400) throw e;
                    return e.data
                }), console.log("cacheLocationResult:", u)), f = u.ip, b = u.location
            } catch (v) {
                console.error("createComment getIpLocation err:", v, m)
            }
            if (t.avatar && (l.avatar = t.avatar), f && b && (l.ip = f, l.location = b), y && (g =
                    `${c}/${e}/comments`, delete l.avatar), Object.keys(l).length) {
                const e = t.content || "";
                m.content = e + '<i style="display: none;" class="qiushaocloud_comment_extra_json">' +
                    window.encodeURIComponent(JSON.stringify(l)) + "</i>"
            }
            const w = {
                url: g,
                method: "post",
                data: m
            };
            try {
                let e = void 0;
                e = y ? await h(w, n, p) : await a(w);
                const t = e.data.data;
                return d(t), e
            } catch (x) {
                throw console.error("createComment reqError:", x), x
            }
        }, l.deleteComment = async (e, t, n = {}) => {
            const o = {
                url: `${c}/${e}/comments/${t}`,
                method: "delete"
            };
            return h(o, n)
        }, l.listComments = (e, t, n = "tree_view", o) => a({
            url: `${s}/${e}/${t}/comments/${n}`,
            params: o,
            method: "get"
        }).then(e => {
            const t = e.data.data.content;
            for (const n of t) d(n);
            return e
        }), l.getIpLocation = e => r.a.get("https://www.qiushaocloud.top/get_ip_location?ip=" + e).then(
            e => {
                if (200 !== e.status) throw e;
                return e.data
            }), l.uploadAvatar = (e, t) => {
            const n = new FormData;
            n.append("image", e);
            const o = {
                headers: {
                    "Content-Type": "multipart/form-data"
                }
            };
            return t && (o.headers.token = t), r.a.post("https://img.78al.net/api/upload", n, o)
        };
        t["a"] = l
    },
    "06cf": function (e, t, n) {
        var o = n("83ab"),
            r = n("c65b"),
            i = n("d1e7"),
            a = n("5c6c"),
            s = n("fc6a"),
            c = n("a04b"),
            l = n("1a2d"),
            u = n("0cfb"),
            m = Object.getOwnPropertyDescriptor;
        t.f = o ? m : function (e, t) {
            if (e = s(e), t = c(t), u) try {
                return m(e, t)
            } catch (n) {}
            if (l(e, t)) return a(!r(i.f, e, t), e[t])
        }
    },
    "07fa": function (e, t, n) {
        var o = n("50c4");
        e.exports = function (e) {
            return o(e.length)
        }
    },
    "09bd": function (e, t, n) {
        "use strict";
        var o = n("3eb1"),
            r = n("f367"),
            i = n("7b13"),
            a = n("8926"),
            s = n("522d"),
            c = o(a());
        r(c, {
            getPolyfill: a,
            implementation: i,
            shim: s
        }), e.exports = c
    },
    "0a06": function (e, t, n) {
        "use strict";
        var o = n("c532"),
            r = n("30b5"),
            i = n("f6b4"),
            a = n("5270"),
            s = n("4a7b"),
            c = n("848b"),
            l = c.validators;

        function u(e) {
            this.defaults = e, this.interceptors = {
                request: new i,
                response: new i
            }
        }
        u.prototype.request = function (e) {
            "string" === typeof e ? (e = arguments[1] || {}, e.url = arguments[0]) : e = e || {}, e = s(
                    this.defaults, e), e.method ? e.method = e.method.toLowerCase() : this.defaults.method ?
                e.method = this.defaults.method.toLowerCase() : e.method = "get";
            var t = e.transitional;
            void 0 !== t && c.assertOptions(t, {
                silentJSONParsing: l.transitional(l.boolean, "1.0.0"),
                forcedJSONParsing: l.transitional(l.boolean, "1.0.0"),
                clarifyTimeoutError: l.transitional(l.boolean, "1.0.0")
            }, !1);
            var n = [],
                o = !0;
            this.interceptors.request.forEach((function (t) {
                "function" === typeof t.runWhen && !1 === t.runWhen(e) || (o = o && t.synchronous,
                    n.unshift(t.fulfilled, t.rejected))
            }));
            var r, i = [];
            if (this.interceptors.response.forEach((function (e) {
                    i.push(e.fulfilled, e.rejected)
                })), !o) {
                var u = [a, void 0];
                Array.prototype.unshift.apply(u, n), u = u.concat(i), r = Promise.resolve(e);
                while (u.length) r = r.then(u.shift(), u.shift());
                return r
            }
            var m = e;
            while (n.length) {
                var p = n.shift(),
                    d = n.shift();
                try {
                    m = p(m)
                } catch (h) {
                    d(h);
                    break
                }
            }
            try {
                r = a(m)
            } catch (h) {
                return Promise.reject(h)
            }
            while (i.length) r = r.then(i.shift(), i.shift());
            return r
        }, u.prototype.getUri = function (e) {
            return e = s(this.defaults, e), r(e.url, e.params, e.paramsSerializer).replace(/^\?/, "")
        }, o.forEach(["delete", "get", "head", "options"], (function (e) {
            u.prototype[e] = function (t, n) {
                return this.request(s(n || {}, {
                    method: e,
                    url: t,
                    data: (n || {}).data
                }))
            }
        })), o.forEach(["post", "put", "patch"], (function (e) {
            u.prototype[e] = function (t, n, o) {
                return this.request(s(o || {}, {
                    method: e,
                    url: t,
                    data: n
                }))
            }
        })), e.exports = u
    },
    "0cfb": function (e, t, n) {
        var o = n("83ab"),
            r = n("d039"),
            i = n("cc12");
        e.exports = !o && !r((function () {
            return 7 != Object.defineProperty(i("div"), "a", {
                get: function () {
                    return 7
                }
            }).a
        }))
    },
    "0d51": function (e, t, n) {
        var o = n("da84"),
            r = o.String;
        e.exports = function (e) {
            try {
                return r(e)
            } catch (t) {
                return "Object"
            }
        }
    },
    "0df6": function (e, t, n) {
        "use strict";
        e.exports = function (e) {
            return function (t) {
                return e.apply(null, t)
            }
        }
    },
    "0e27": function (e, t, n) {
        (function () {
            var t = ["direction", "boxSizing", "width", "height", "overflowX", "overflowY",
                    "borderTopWidth", "borderRightWidth", "borderBottomWidth", "borderLeftWidth",
                    "borderStyle", "paddingTop", "paddingRight", "paddingBottom", "paddingLeft",
                    "fontStyle", "fontVariant", "fontWeight", "fontStretch", "fontSize", "fontSizeAdjust",
                    "lineHeight", "fontFamily", "textAlign", "textTransform", "textIndent",
                    "textDecoration", "letterSpacing", "wordSpacing", "tabSize", "MozTabSize"],
                n = null != window.mozInnerScreenX;

            function o(e, o, r) {
                var i = r && r.debug || !1;
                if (i) {
                    var a = document.querySelector("#input-textarea-caret-position-mirror-div");
                    a && a.parentNode.removeChild(a)
                }
                var s = document.createElement("div");
                s.id = "input-textarea-caret-position-mirror-div", document.body.appendChild(s);
                var c = s.style,
                    l = window.getComputedStyle ? getComputedStyle(e) : e.currentStyle;
                c.whiteSpace = "pre-wrap", "INPUT" !== e.nodeName && (c.wordWrap = "break-word"), c.position =
                    "absolute", i || (c.visibility = "hidden"), t.forEach((function (e) {
                        c[e] = l[e]
                    })), n ? e.scrollHeight > parseInt(l.height) && (c.overflowY = "scroll") : c.overflow =
                    "hidden", s.textContent = e.value.substring(0, o), "INPUT" === e.nodeName && (s.textContent =
                        s.textContent.replace(/\s/g, " "));
                var u = document.createElement("span");
                u.textContent = e.value.substring(o) || ".", s.appendChild(u);
                var m = {
                    top: u.offsetTop + parseInt(l["borderTopWidth"]),
                    left: u.offsetLeft + parseInt(l["borderLeftWidth"])
                };
                return i ? u.style.backgroundColor = "#aaa" : document.body.removeChild(s), m
            }
            "undefined" != typeof e.exports ? e.exports = o : window.getCaretCoordinates = o
        })()
    },
    "0e4d": function (e, t, n) {
        "use strict";
        var o = {
            replyId: 0
        };
        t["a"] = o
    },
    "0f7c": function (e, t, n) {
        "use strict";
        var o = n("688e");
        e.exports = Function.prototype.bind || o
    },
    1626: function (e, t) {
        e.exports = function (e) {
            return "function" == typeof e
        }
    },
    1696: function (e, t, n) {
        "use strict";
        e.exports = function () {
            if ("function" !== typeof Symbol || "function" !== typeof Object.getOwnPropertySymbols) return !
                1;
            if ("symbol" === typeof Symbol.iterator) return !0;
            var e = {},
                t = Symbol("test"),
                n = Object(t);
            if ("string" === typeof t) return !1;
            if ("[object Symbol]" !== Object.prototype.toString.call(t)) return !1;
            if ("[object Symbol]" !== Object.prototype.toString.call(n)) return !1;
            var o = 42;
            for (t in e[t] = o, e) return !1;
            if ("function" === typeof Object.keys && 0 !== Object.keys(e).length) return !1;
            if ("function" === typeof Object.getOwnPropertyNames && 0 !== Object.getOwnPropertyNames(e).length)
                return !1;
            var r = Object.getOwnPropertySymbols(e);
            if (1 !== r.length || r[0] !== t) return !1;
            if (!Object.prototype.propertyIsEnumerable.call(e, t)) return !1;
            if ("function" === typeof Object.getOwnPropertyDescriptor) {
                var i = Object.getOwnPropertyDescriptor(e, t);
                if (i.value !== o || !0 !== i.enumerable) return !1
            }
            return !0
        }
    },
    "1a2d": function (e, t, n) {
        var o = n("e330"),
            r = n("7b0b"),
            i = o({}.hasOwnProperty);
        e.exports = Object.hasOwn || function (e, t) {
            return i(r(e), t)
        }
    },
    "1d2b": function (e, t, n) {
        "use strict";
        e.exports = function (e, t) {
            return function () {
                for (var n = new Array(arguments.length), o = 0; o < n.length; o++) n[o] = arguments[o];
                return e.apply(t, n)
            }
        }
    },
    "1d80": function (e, t, n) {
        var o = n("da84"),
            r = o.TypeError;
        e.exports = function (e) {
            if (void 0 == e) throw r("Can't call method on " + e);
            return e
        }
    },
    2054: function (e, t, n) {
        "use strict";
        e.exports = n("21d0")
    },
    2057: function (e, t, n) {
        "use strict";
        e.exports = Number.isNaN || function (e) {
            return e !== e
        }
    },
    "21d0": function (e, t, n) {
        "use strict";
        var o, r, i = Function.prototype.toString,
            a = "object" === typeof Reflect && null !== Reflect && Reflect.apply;
        if ("function" === typeof a && "function" === typeof Object.defineProperty) try {
            o = Object.defineProperty({}, "length", {
                get: function () {
                    throw r
                }
            }), r = {}, a((function () {
                throw 42
            }), null, o)
        } catch (f) {
            f !== r && (a = null)
        } else a = null;
        var s = /^\s*class\b/,
            c = function (e) {
                try {
                    var t = i.call(e);
                    return s.test(t)
                } catch (n) {
                    return !1
                }
            },
            l = function (e) {
                try {
                    return !c(e) && (i.call(e), !0)
                } catch (t) {
                    return !1
                }
            },
            u = Object.prototype.toString,
            m = "[object Function]",
            p = "[object GeneratorFunction]",
            d = "function" === typeof Symbol && !!Symbol.toStringTag,
            h = "object" === typeof document && "undefined" === typeof document.all && void 0 !== document.all ?
            document.all : {};
        e.exports = a ? function (e) {
            if (e === h) return !0;
            if (!e) return !1;
            if ("function" !== typeof e && "object" !== typeof e) return !1;
            if ("function" === typeof e && !e.prototype) return !0;
            try {
                a(e, null, o)
            } catch (t) {
                if (t !== r) return !1
            }
            return !c(e)
        } : function (e) {
            if (e === h) return !0;
            if (!e) return !1;
            if ("function" !== typeof e && "object" !== typeof e) return !1;
            if ("function" === typeof e && !e.prototype) return !0;
            if (d) return l(e);
            if (c(e)) return !1;
            var t = u.call(e);
            return t === m || t === p
        }
    },
    "23cb": function (e, t, n) {
        var o = n("5926"),
            r = Math.max,
            i = Math.min;
        e.exports = function (e, t) {
            var n = o(e);
            return n < 0 ? r(n + t, 0) : i(n, t)
        }
    },
    "23e7": function (e, t, n) {
        var o = n("da84"),
            r = n("06cf").f,
            i = n("9112"),
            a = n("6eeb"),
            s = n("ce4e"),
            c = n("e893"),
            l = n("94ca");
        e.exports = function (e, t) {
            var n, u, m, p, d, h, f = e.target,
                b = e.global,
                g = e.stat;
            if (u = b ? o : g ? o[f] || s(f, {}) : (o[f] || {}).prototype, u)
                for (m in t) {
                    if (d = t[m], e.noTargetGet ? (h = r(u, m), p = h && h.value) : p = u[m], n = l(b ? m :
                            f + (g ? "." : "#") + m, e.forced), !n && void 0 !== p) {
                        if (typeof d == typeof p) continue;
                        c(d, p)
                    }(e.sham || p && p.sham) && i(d, "sham", !0), a(u, m, d, e)
                }
        }
    },
    "241c": function (e, t, n) {
        var o = n("ca84"),
            r = n("7839"),
            i = r.concat("length", "prototype");
        t.f = Object.getOwnPropertyNames || function (e) {
            return o(e, i)
        }
    },
    2444: function (e, t, n) {
        "use strict";
        (function (t) {
            var o = n("c532"),
                r = n("c8af"),
                i = n("387f"),
                a = {
                    "Content-Type": "application/x-www-form-urlencoded"
                };

            function s(e, t) {
                !o.isUndefined(e) && o.isUndefined(e["Content-Type"]) && (e["Content-Type"] = t)
            }

            function c() {
                var e;
                return ("undefined" !== typeof XMLHttpRequest || "undefined" !== typeof t &&
                    "[object process]" === Object.prototype.toString.call(t)) && (e = n("b50d")), e
            }

            function l(e, t, n) {
                if (o.isString(e)) try {
                    return (t || JSON.parse)(e), o.trim(e)
                } catch (r) {
                    if ("SyntaxError" !== r.name) throw r
                }
                return (n || JSON.stringify)(e)
            }
            var u = {
                transitional: {
                    silentJSONParsing: !0,
                    forcedJSONParsing: !0,
                    clarifyTimeoutError: !1
                },
                adapter: c(),
                transformRequest: [function (e, t) {
                    return r(t, "Accept"), r(t, "Content-Type"), o.isFormData(e) || o.isArrayBuffer(
                            e) || o.isBuffer(e) || o.isStream(e) || o.isFile(e) || o.isBlob(e) ?
                        e : o.isArrayBufferView(e) ? e.buffer : o.isURLSearchParams(e) ? (s(t,
                            "application/x-www-form-urlencoded;charset=utf-8"), e.toString()) :
                        o.isObject(e) || t && "application/json" === t["Content-Type"] ? (s(t,
                            "application/json"), l(e)) : e
                }],
                transformResponse: [function (e) {
                    var t = this.transitional,
                        n = t && t.silentJSONParsing,
                        r = t && t.forcedJSONParsing,
                        a = !n && "json" === this.responseType;
                    if (a || r && o.isString(e) && e.length) try {
                        return JSON.parse(e)
                    } catch (s) {
                        if (a) {
                            if ("SyntaxError" === s.name) throw i(s, this, "E_JSON_PARSE");
                            throw s
                        }
                    }
                    return e
                }],
                timeout: 0,
                xsrfCookieName: "XSRF-TOKEN",
                xsrfHeaderName: "X-XSRF-TOKEN",
                maxContentLength: -1,
                maxBodyLength: -1,
                validateStatus: function (e) {
                    return e >= 200 && e < 300
                },
                headers: {
                    common: {
                        Accept: "application/json, text/plain, */*"
                    }
                }
            };
            o.forEach(["delete", "get", "head"], (function (e) {
                u.headers[e] = {}
            })), o.forEach(["post", "put", "patch"], (function (e) {
                u.headers[e] = o.merge(a)
            })), e.exports = u
        }).call(this, n("4362"))
    },
    "24fb": function (e, t, n) {
        "use strict";

        function o(e, t) {
            var n = e[1] || "",
                o = e[3];
            if (!o) return n;
            if (t && "function" === typeof btoa) {
                var i = r(o),
                    a = o.sources.map((function (e) {
                        return "/*# sourceURL=".concat(o.sourceRoot || "").concat(e, " */")
                    }));
                return [n].concat(a).concat([i]).join("\n")
            }
            return [n].join("\n")
        }

        function r(e) {
            var t = btoa(unescape(encodeURIComponent(JSON.stringify(e)))),
                n = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(t);
            return "/*# ".concat(n, " */")
        }
        e.exports = function (e) {
            var t = [];
            return t.toString = function () {
                return this.map((function (t) {
                    var n = o(t, e);
                    return t[2] ? "@media ".concat(t[2], " {").concat(n, "}") : n
                })).join("")
            }, t.i = function (e, n, o) {
                "string" === typeof e && (e = [[null, e, ""]]);
                var r = {};
                if (o)
                    for (var i = 0; i < this.length; i++) {
                        var a = this[i][0];
                        null != a && (r[a] = !0)
                    }
                for (var s = 0; s < e.length; s++) {
                    var c = [].concat(e[s]);
                    o && r[c[0]] || (n && (c[2] ? c[2] = "".concat(n, " and ").concat(c[2]) : c[2] = n),
                        t.push(c))
                }
            }, t
        }
    },
    "27b1": function (e, t, n) {
        "use strict";
        var o = n("00ce"),
            r = o("%Array%"),
            i = !r.isArray && n("545e")("Object.prototype.toString");
        e.exports = r.isArray || function (e) {
            return "[object Array]" === i(e)
        }
    },
    2877: function (e, t, n) {
        "use strict";

        function o(e, t, n, o, r, i, a, s) {
            var c, l = "function" === typeof e ? e.options : e;
            if (t && (l.render = t, l.staticRenderFns = n, l._compiled = !0), o && (l.functional = !0), i && (l
                    ._scopeId = "data-v-" + i), a ? (c = function (e) {
                    e = e || this.$vnode && this.$vnode.ssrContext || this.parent && this.parent.$vnode &&
                        this.parent.$vnode.ssrContext, e || "undefined" === typeof __VUE_SSR_CONTEXT__ || (
                            e = __VUE_SSR_CONTEXT__), r && r.call(this, e), e && e._registeredComponents &&
                        e._registeredComponents.add(a)
                }, l._ssrRegister = c) : r && (c = s ? function () {
                    r.call(this, (l.functional ? this.parent : this).$root.$options.shadowRoot)
                } : r), c)
                if (l.functional) {
                    l._injectStyles = c;
                    var u = l.render;
                    l.render = function (e, t) {
                        return c.call(t), u(e, t)
                    }
                } else {
                    var m = l.beforeCreate;
                    l.beforeCreate = m ? [].concat(m, c) : [c]
                } return {
                exports: e,
                options: l
            }
        }
        n.d(t, "a", (function () {
            return o
        }))
    },
    "2a6d": function (e, t, n) {
        "use strict";
        var o = n("00ce"),
            r = o("%Object.defineProperty%", !0);
        if (r) try {
            r({}, "a", {
                value: 1
            })
        } catch (l) {
            r = null
        }
        var i = Object.defineProperty && 0 === Object.defineProperty([], "length", {
                value: 1
            }).length,
            a = i && n("27b1"),
            s = n("545e"),
            c = s("Object.prototype.propertyIsEnumerable");
        e.exports = function (e, t, n, o, s, l) {
            if (!r) {
                if (!e(l)) return !1;
                if (!l["[[Configurable]]"] || !l["[[Writable]]"]) return !1;
                if (s in o && c(o, s) !== !!l["[[Enumerable]]"]) return !1;
                var u = l["[[Value]]"];
                return o[s] = u, t(o[s], u)
            }
            return i && "length" === s && "[[Value]]" in l && a(o) && o.length !== l["[[Value]]"] ? (o.length =
                l["[[Value]]"], o.length === l["[[Value]]"]) : (r(o, s, n(l)), !0)
        }
    },
    "2af9": function (e, t, n) {
        "use strict";
        var o = n("8bbf"),
            r = n.n(o),
            i = n("3f17"),
            a = n("f9af"),
            s = function () {
                var e = this,
                    t = e.$createElement,
                    n = e._self._c || t;
                return n("div", {
                    staticClass: "comment-loader-container"
                }, ["default" === e.configs.loadingStyle ? n("div", {
                        staticClass: "comment-loader-default"
                    }, [n("span"), n("span"), n("span"), n("span")]) : "circle" === e.configs.loadingStyle ?
                    n("div", {
                        staticClass: "comment-loader-circle"
                    }) : "balls" === e.configs.loadingStyle ? n("div", {
                        staticClass: "comment-loader-balls"
                    }, [n("div"), n("div"), n("div")]) : e._e()])
            },
            c = [],
            l = {
                name: "CommentLoading",
                props: {
                    configs: {
                        type: Object,
                        required: !0
                    }
                }
            },
            u = l,
            m = n("2877"),
            p = Object(m["a"])(u, s, c, !1, null, null, null, !0),
            d = p.exports,
            h = function () {
                var e = this,
                    t = e.$createElement,
                    n = e._self._c || t;
                return n("ul", {
                    staticClass: "page"
                }, [n("li", {
                    staticClass: "page-item",
                    class: {
                        disabled: !e.hasPrev
                    }
                }, [n("button", {
                    staticClass: "prev-button",
                    attrs: {
                        tabindex: "-1"
                    },
                    on: {
                        click: e.handlePrevClick
                    }
                }, [n("svg", {
                    attrs: {
                        viewBox: "0 0 1024 1024",
                        version: "1.1",
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "18",
                        height: "18"
                    }
                }, [n("path", {
                    attrs: {
                        d: "M507.733333 490.666667L768 230.4 704 170.666667 384 490.666667l320 320 59.733333-59.733334-256-260.266666zM341.333333 170.666667H256v640h85.333333V170.666667z"
                    }
                })])])]), null != e.firstPage ? n("li", {
                    staticClass: "page-item",
                    class: {
                        active: e.page === e.firstPage
                    }
                }, [n("button", {
                    class: {
                        active: e.page === e.firstPage
                    },
                    on: {
                        click: function (t) {
                            return e.handlePageItemClick(e.firstPage)
                        }
                    }
                }, [e._v(e._s(e.firstPage + 1))])]) : e._e(), n("li", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: e.hasMorePrev,
                        expression: "hasMorePrev"
                    }],
                    staticClass: "page-item"
                }, [n("span", [e._v("...")])]), e._l(e.middlePages, (function (t) {
                    return n("li", {
                        key: t,
                        staticClass: "page-item",
                        class: {
                            active: t === e.page
                        }
                    }, [n("button", {
                        class: {
                            active: t === e.page
                        },
                        on: {
                            click: function (n) {
                                return e.handlePageItemClick(t)
                            }
                        }
                    }, [e._v(" " + e._s(t + 1) + " ")])])
                })), n("li", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: e.hasMoreNext,
                        expression: "hasMoreNext"
                    }],
                    staticClass: "page-item"
                }, [n("span", [e._v("...")])]), e.lastPage ? n("li", {
                    staticClass: "page-item",
                    class: {
                        active: e.page === e.lastPage
                    }
                }, [n("button", {
                    class: {
                        active: e.page === e.lastPage
                    },
                    on: {
                        click: function (t) {
                            return e.handlePageItemClick(e.lastPage)
                        }
                    }
                }, [e._v(" " + e._s(e.lastPage + 1) + " ")])]) : e._e(), n("li", {
                    staticClass: "page-item",
                    class: {
                        disabled: !e.hasNext
                    }
                }, [n("button", {
                    staticClass: "next-button",
                    on: {
                        click: e.handleNextClick
                    }
                }, [n("svg", {
                    attrs: {
                        viewBox: "0 0 1024 1024",
                        version: "1.1",
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "18",
                        height: "18"
                    }
                }, [n("path", {
                    attrs: {
                        d: "M516.266667 490.666667L256 230.4 315.733333 170.666667l320 320L315.733333 810.666667 256 750.933333l260.266667-260.266666zM678.4 170.666667h85.333333v640h-85.333333V170.666667z"
                    }
                })])])])], 2)
            },
            f = [],
            b = {
                name: "Pagination",
                model: {
                    prop: "page",
                    event: "change"
                },
                props: {
                    page: {
                        type: Number,
                        required: !1,
                        default: 0
                    },
                    size: {
                        type: Number,
                        required: !1,
                        default: 10
                    },
                    total: {
                        type: Number,
                        required: !1,
                        default: 0
                    }
                },
                data() {
                    return {
                        middleSize: 3
                    }
                },
                computed: {
                    pages() {
                        return Math.ceil(this.total / this.size)
                    },
                    hasNext() {
                        return this.page < this.pages - 1
                    },
                    hasPrev() {
                        return this.page > 0
                    },
                    firstPage() {
                        return 0 === this.pages ? null : 0
                    },
                    hasMorePrev() {
                        return !(null === this.firstPage || this.pages <= this.middleSize + 2) && this.page >=
                            2 + this.middleSize / 2
                    },
                    hasMoreNext() {
                        return !(null === this.lastPage || this.pages <= this.middleSize + 2) && this.page <
                            this.lastPage - 1 - this.middleSize / 2
                    },
                    middlePages() {
                        if (this.pages <= 2) return [];
                        if (this.pages <= 2 + this.middleSize) return this.range(1, this.lastPage);
                        const e = Math.floor(this.middleSize / 2);
                        let t = this.page - e,
                            n = this.page + e;
                        return this.page <= this.firstPage + e + 1 ? (t = this.firstPage + 1, n = t + this.middleSize -
                            1) : this.page >= this.lastPage - e - 1 && (n = this.lastPage - 1, t = n - this
                            .middleSize + 1), this.range(t, n + 1)
                    },
                    lastPage() {
                        return 0 === this.pages || 1 === this.pages ? 0 : this.pages - 1
                    }
                },
                methods: {
                    handleNextClick() {
                        this.hasNext && this.$emit("change", this.page + 1)
                    },
                    handlePrevClick() {
                        this.hasPrev && this.$emit("change", this.page - 1)
                    },
                    handlePageItemClick(e) {
                        this.$emit("change", e)
                    },
                    range(e, t) {
                        if (e >= t) return [];
                        const n = [];
                        for (let o = e; o < t; o++) n.push(o);
                        return n
                    }
                }
            },
            g = b,
            y = Object(m["a"])(g, h, f, !1, null, null, null, !0),
            w = y.exports;
        const v = {
                CommentEditor: i["a"],
                CommentNode: a["default"],
                CommentLoading: d,
                Pagination: w
            },
            x = {};
        Object.keys(v).forEach(e => {
            x[e] = r.a.component(e, v[e])
        })
    },
    "2b80": function (e, t, n) {
        var o;
        (function (r, i) {
            "use strict";
            var a = "0.7.31",
                s = "",
                c = "?",
                l = "function",
                u = "undefined",
                m = "object",
                p = "string",
                d = "major",
                h = "model",
                f = "name",
                b = "type",
                g = "vendor",
                y = "version",
                w = "architecture",
                v = "console",
                x = "mobile",
                k = "tablet",
                j = "smarttv",
                S = "wearable",
                _ = "embedded",
                A = 255,
                C = "Amazon",
                E = "Apple",
                O = "ASUS",
                z = "BlackBerry",
                P = "Browser",
                T = "Chrome",
                I = "Edge",
                $ = "Firefox",
                R = "Google",
                N = "Huawei",
                q = "LG",
                L = "Microsoft",
                U = "Motorola",
                D = "Opera",
                B = "Samsung",
                M = "Sony",
                F = "Xiaomi",
                Y = "Zebra",
                H = "Facebook",
                W = function (e, t) {
                    var n = {};
                    for (var o in e) t[o] && t[o].length % 2 === 0 ? n[o] = t[o].concat(e[o]) : n[o] = e[o];
                    return n
                },
                V = function (e) {
                    for (var t = {}, n = 0; n < e.length; n++) t[e[n].toUpperCase()] = e[n];
                    return t
                },
                G = function (e, t) {
                    return typeof e === p && -1 !== Q(t).indexOf(Q(e))
                },
                Q = function (e) {
                    return e.toLowerCase()
                },
                J = function (e) {
                    return typeof e === p ? e.replace(/[^\d\.]/g, s).split(".")[0] : i
                },
                Z = function (e, t) {
                    if (typeof e === p) return e = e.replace(/^\s\s*/, s).replace(/\s\s*$/, s), typeof t ===
                        u ? e : e.substring(0, A)
                },
                X = function (e, t) {
                    var n, o, r, a, s, c, u = 0;
                    while (u < t.length && !s) {
                        var p = t[u],
                            d = t[u + 1];
                        n = o = 0;
                        while (n < p.length && !s)
                            if (s = p[n++].exec(e), s)
                                for (r = 0; r < d.length; r++) c = s[++o], a = d[r], typeof a === m && a.length >
                                    0 ? 2 === a.length ? typeof a[1] == l ? this[a[0]] = a[1].call(this, c) :
                                    this[a[0]] = a[1] : 3 === a.length ? typeof a[1] !== l || a[1].exec &&
                                    a[1].test ? this[a[0]] = c ? c.replace(a[1], a[2]) : i : this[a[0]] = c ?
                                    a[1].call(this, c, a[2]) : i : 4 === a.length && (this[a[0]] = c ? a[3]
                                        .call(this, c.replace(a[1], a[2])) : i) : this[a] = c || i;
                        u += 2
                    }
                },
                K = function (e, t) {
                    for (var n in t)
                        if (typeof t[n] === m && t[n].length > 0) {
                            for (var o = 0; o < t[n].length; o++)
                                if (G(t[n][o], e)) return n === c ? i : n
                        } else if (G(t[n], e)) return n === c ? i : n;
                    return e
                },
                ee = {
                    "1.0": "/8",
                    1.2: "/1",
                    1.3: "/3",
                    "2.0": "/412",
                    "2.0.2": "/416",
                    "2.0.3": "/417",
                    "2.0.4": "/419",
                    "?": "/"
                },
                te = {
                    ME: "4.90",
                    "NT 3.11": "NT3.51",
                    "NT 4.0": "NT4.0",
                    2e3: "NT 5.0",
                    XP: ["NT 5.1", "NT 5.2"],
                    Vista: "NT 6.0",
                    7: "NT 6.1",
                    8: "NT 6.2",
                    8.1: "NT 6.3",
                    10: ["NT 6.4", "NT 10.0"],
                    RT: "ARM"
                },
                ne = {
                    browser: [[/\b(?:crmo|crios)\/([\w\.]+)/i], [y, [f, "Chrome"]], [
                            /edg(?:e|ios|a)?\/([\w\.]+)/i], [y, [f, "Edge"]], [
                            /(opera mini)\/([-\w\.]+)/i,
                            /(opera [mobiletab]{3,6})\b.+version\/([-\w\.]+)/i,
                            /(opera)(?:.+version\/|[\/ ]+)([\w\.]+)/i], [f, y], [
                            /opios[\/ ]+([\w\.]+)/i], [y, [f, D + " Mini"]], [/\bopr\/([\w\.]+)/i], [y,
                            [f, D]], [/(kindle)\/([\w\.]+)/i,
                            /(lunascape|maxthon|netfront|jasmine|blazer)[\/ ]?([\w\.]*)/i,
                            /(avant |iemobile|slim)(?:browser)?[\/ ]?([\w\.]*)/i,
                            /(ba?idubrowser)[\/ ]?([\w\.]+)/i, /(?:ms|\()(ie) ([\w\.]+)/i,
                            /(flock|rockmelt|midori|epiphany|silk|skyfire|ovibrowser|bolt|iron|vivaldi|iridium|phantomjs|bowser|quark|qupzilla|falkon|rekonq|puffin|brave|whale|qqbrowserlite|qq)\/([-\w\.]+)/i,
                            /(weibo)__([\d\.]+)/i], [f, y], [
                            /(?:\buc? ?browser|(?:juc.+)ucweb)[\/ ]?([\w\.]+)/i], [y, [f, "UC" + P]], [
                            /\bqbcore\/([\w\.]+)/i], [y, [f, "WeChat(Win) Desktop"]], [
                            /micromessenger\/([\w\.]+)/i], [y, [f, "WeChat"]], [/konqueror\/([\w\.]+)/i],
                        [y, [f, "Konqueror"]], [/trident.+rv[: ]([\w\.]{1,9})\b.+like gecko/i], [y, [f,
                            "IE"]], [/yabrowser\/([\w\.]+)/i], [y, [f, "Yandex"]], [
                            /(avast|avg)\/([\w\.]+)/i], [[f, /(.+)/, "$1 Secure " + P], y], [
                            /\bfocus\/([\w\.]+)/i], [y, [f, $ + " Focus"]], [/\bopt\/([\w\.]+)/i], [y,
                            [f, D + " Touch"]], [/coc_coc\w+\/([\w\.]+)/i], [y, [f, "Coc Coc"]], [
                            /dolfin\/([\w\.]+)/i], [y, [f, "Dolphin"]], [/coast\/([\w\.]+)/i], [y, [f,
                            D + " Coast"]], [/miuibrowser\/([\w\.]+)/i], [y, [f, "MIUI " + P]], [
                            /fxios\/([-\w\.]+)/i], [y, [f, $]], [/\bqihu|(qi?ho?o?|360)browser/i], [[f,
                            "360 " + P]], [/(oculus|samsung|sailfish)browser\/([\w\.]+)/i], [[f, /(.+)/,
                            "$1 " + P], y], [/(comodo_dragon)\/([\w\.]+)/i], [[f, /_/g, " "], y], [
                            /(electron)\/([\w\.]+) safari/i,
                            /(tesla)(?: qtcarbrowser|\/(20\d\d\.[-\w\.]+))/i,
                            /m?(qqbrowser|baiduboxapp|2345Explorer)[\/ ]?([\w\.]+)/i], [f, y], [
                            /(metasr)[\/ ]?([\w\.]+)/i, /(lbbrowser)/i], [f], [
                            /((?:fban\/fbios|fb_iab\/fb4a)(?!.+fbav)|;fbav\/([\w\.]+);)/i], [[f, H], y],
                        [/safari (line)\/([\w\.]+)/i, /\b(line)\/([\w\.]+)\/iab/i,
                            /(chromium|instagram)[\/ ]([-\w\.]+)/i], [f, y], [
                            /\bgsa\/([\w\.]+) .*safari\//i], [y, [f, "GSA"]], [
                            /headlesschrome(?:\/([\w\.]+)| )/i], [y, [f, T + " Headless"]], [
                            / wv\).+(chrome)\/([\w\.]+)/i], [[f, T + " WebView"], y], [
                            /droid.+ version\/([\w\.]+)\b.+(?:mobile safari|safari)/i], [y, [f,
                            "Android " + P]], [
                            /(chrome|omniweb|arora|[tizenoka]{5} ?browser)\/v?([\w\.]+)/i], [f, y], [
                            /version\/([\w\.]+) .*mobile\/\w+ (safari)/i], [y, [f, "Mobile Safari"]], [
                            /version\/([\w\.]+) .*(mobile ?safari|safari)/i], [y, f], [
                            /webkit.+?(mobile ?safari|safari)(\/[\w\.]+)/i], [f, [y, K, ee]], [
                            /(webkit|khtml)\/([\w\.]+)/i], [f, y], [
                            /(navigator|netscape\d?)\/([-\w\.]+)/i], [[f, "Netscape"], y], [
                            /mobile vr; rv:([\w\.]+)\).+firefox/i], [y, [f, $ + " Reality"]], [
                            /ekiohf.+(flow)\/([\w\.]+)/i, /(swiftfox)/i,
                            /(icedragon|iceweasel|camino|chimera|fennec|maemo browser|minimo|conkeror|klar)[\/ ]?([\w\.\+]+)/i,
                            /(seamonkey|k-meleon|icecat|iceape|firebird|phoenix|palemoon|basilisk|waterfox)\/([-\w\.]+)$/i,
                            /(firefox)\/([\w\.]+)/i, /(mozilla)\/([\w\.]+) .+rv\:.+gecko\/\d+/i,
                            /(polaris|lynx|dillo|icab|doris|amaya|w3m|netsurf|sleipnir|obigo|mosaic|(?:go|ice|up)[\. ]?browser)[-\/ ]?v?([\w\.]+)/i,
                            /(links) \(([\w\.]+)/i], [f, y]],
                    cpu: [[/(?:(amd|x(?:(?:86|64)[-_])?|wow|win)64)[;\)]/i], [[w, "amd64"]], [
                        /(ia32(?=;))/i], [[w, Q]], [/((?:i[346]|x)86)[;\)]/i], [[w, "ia32"]], [
                        /\b(aarch64|arm(v?8e?l?|_?64))\b/i], [[w, "arm64"]], [
                        /\b(arm(?:v[67])?ht?n?[fl]p?)\b/i], [[w, "armhf"]], [
                        /windows (ce|mobile); ppc;/i], [[w, "arm"]], [
                        /((?:ppc|powerpc)(?:64)?)(?: mac|;|\))/i], [[w, /ower/, s, Q]], [
                        /(sun4\w)[;\)]/i], [[w, "sparc"]], [
                        /((?:avr32|ia64(?=;))|68k(?=\))|\barm(?=v(?:[1-7]|[5-7]1)l?|;|eabi)|(?=atmel )avr|(?:irix|mips|sparc)(?:64)?\b|pa-risc)/i
                        ], [[w, Q]]],
                    device: [[
                            /\b(sch-i[89]0\d|shw-m380s|sm-[pt]\w{2,4}|gt-[pn]\d{2,4}|sgh-t8[56]9|nexus 10)/i
                            ], [h, [g, B], [b, k]], [/\b((?:s[cgp]h|gt|sm)-\w+|galaxy nexus)/i,
                            /samsung[- ]([-\w]+)/i, /sec-(sgh\w+)/i], [h, [g, B], [b, x]], [
                            /\((ip(?:hone|od)[\w ]*);/i], [h, [g, E], [b, x]], [
                            /\((ipad);[-\w\),; ]+apple/i, /applecoremedia\/[\w\.]+ \((ipad)/i,
                            /\b(ipad)\d\d?,\d\d?[;\]].+ios/i], [h, [g, E], [b, k]], [
                            /\b((?:ag[rs][23]?|bah2?|sht?|btv)-a?[lw]\d{2})\b(?!.+d\/s)/i], [h, [g, N],
                            [b, k]], [/(?:huawei|honor)([-\w ]+)[;\)]/i,
                            /\b(nexus 6p|\w{2,4}-[atu]?[ln][01259x][012359][an]?)\b(?!.+d\/s)/i], [h, [
                            g, N], [b, x]], [/\b(poco[\w ]+)(?: bui|\))/i, /\b; (\w+) build\/hm\1/i,
                            /\b(hm[-_ ]?note?[_ ]?(?:\d\w)?) bui/i,
                            /\b(redmi[\-_ ]?(?:note|k)?[\w_ ]+)(?: bui|\))/i,
                            /\b(mi[-_ ]?(?:a\d|one|one[_ ]plus|note lte|max)?[_ ]?(?:\d?\w?)[_ ]?(?:plus|se|lite)?)(?: bui|\))/i
                            ], [[h, /_/g, " "], [g, F], [b, x]], [
                            /\b(mi[-_ ]?(?:pad)(?:[\w_ ]+))(?: bui|\))/i], [[h, /_/g, " "], [g, F], [b,
                            k]], [/; (\w+) bui.+ oppo/i,
                            /\b(cph[12]\d{3}|p(?:af|c[al]|d\w|e[ar])[mt]\d0|x9007|a101op)\b/i], [h, [g,
                            "OPPO"], [b, x]], [/vivo (\w+)(?: bui|\))/i,
                            /\b(v[12]\d{3}\w?[at])(?: bui|;)/i], [h, [g, "Vivo"], [b, x]], [
                            /\b(rmx[12]\d{3})(?: bui|;|\))/i], [h, [g, "Realme"], [b, x]], [
                            /\b(milestone|droid(?:[2-4x]| (?:bionic|x2|pro|razr))?:?( 4g)?)\b[\w ]+build\//i,
                            /\bmot(?:orola)?[- ](\w*)/i,
                            /((?:moto[\w\(\) ]+|xt\d{3,4}|nexus 6)(?= bui|\)))/i], [h, [g, U], [b, x]],
                        [/\b(mz60\d|xoom[2 ]{0,2}) build\//i], [h, [g, U], [b, k]], [
                            /((?=lg)?[vl]k\-?\d{3}) bui| 3\.[-\w; ]{10}lg?-([06cv9]{3,4})/i], [h, [g, q],
                            [b, k]], [/(lm(?:-?f100[nv]?|-[\w\.]+)(?= bui|\))|nexus [45])/i,
                            /\blg[-e;\/ ]+((?!browser|netcast|android tv)\w+)/i, /\blg-?([\d\w]+) bui/i
                            ], [h, [g, q], [b, x]], [/(ideatab[-\w ]+)/i,
                            /lenovo ?(s[56]000[-\w]+|tab(?:[\w ]+)|yt[-\d\w]{6}|tb[-\d\w]{6})/i], [h, [
                            g, "Lenovo"], [b, k]], [/(?:maemo|nokia).*(n900|lumia \d+)/i,
                            /nokia[-_ ]?([-\w\.]*)/i], [[h, /_/g, " "], [g, "Nokia"], [b, x]], [
                            /(pixel c)\b/i], [h, [g, R], [b, k]], [
                            /droid.+; (pixel[\daxl ]{0,6})(?: bui|\))/i], [h, [g, R], [b, x]], [
                            /droid.+ ([c-g]\d{4}|so[-gl]\w+|xq-a\w[4-7][12])(?= bui|\).+chrome\/(?![1-6]{0,1}\d\.))/i
                            ], [h, [g, M], [b, x]], [/sony tablet [ps]/i,
                            /\b(?:sony)?sgp\w+(?: bui|\))/i], [[h, "Xperia Tablet"], [g, M], [b, k]], [
                            / (kb2005|in20[12]5|be20[12][59])\b/i,
                            /(?:one)?(?:plus)? (a\d0\d\d)(?: b|\))/i], [h, [g, "OnePlus"], [b, x]], [
                            /(alexa)webm/i, /(kf[a-z]{2}wi)( bui|\))/i, /(kf[a-z]+)( bui|\)).+silk\//i],
                        [h, [g, C], [b, k]], [/((?:sd|kf)[0349hijorstuw]+)( bui|\)).+silk\//i], [[h,
                            /(.+)/g, "Fire Phone $1"], [g, C], [b, x]], [/(playbook);[-\w\),; ]+(rim)/i],
                        [h, g, [b, k]], [/\b((?:bb[a-f]|st[hv])100-\d)/i, /\(bb10; (\w+)/i], [h, [g, z],
                            [b, x]], [
                            /(?:\b|asus_)(transfo[prime ]{4,10} \w+|eeepc|slider \w+|nexus 7|padfone|p00[cj])/i
                            ], [h, [g, O], [b, k]], [/ (z[bes]6[027][012][km][ls]|zenfone \d\w?)\b/i],
                        [h, [g, O], [b, x]], [/(nexus 9)/i], [h, [g, "HTC"], [b, k]], [
                            /(htc)[-;_ ]{1,2}([\w ]+(?=\)| bui)|\w+)/i,
                            /(zte)[- ]([\w ]+?)(?: bui|\/|\))/i,
                            /(alcatel|geeksphone|nexian|panasonic|sony)[-_ ]?([-\w]*)/i], [g, [h, /_/g,
                            " "], [b, x]], [/droid.+; ([ab][1-7]-?[0178a]\d\d?)/i], [h, [g, "Acer"], [b,
                            k]], [/droid.+; (m[1-5] note) bui/i, /\bmz-([-\w]{2,})/i], [h, [g, "Meizu"],
                            [b, x]], [/\b(sh-?[altvz]?\d\d[a-ekm]?)/i], [h, [g, "Sharp"], [b, x]], [
                            /(blackberry|benq|palm(?=\-)|sonyericsson|acer|asus|dell|meizu|motorola|polytron)[-_ ]?([-\w]*)/i,
                            /(hp) ([\w ]+\w)/i, /(asus)-?(\w+)/i, /(microsoft); (lumia[\w ]+)/i,
                            /(lenovo)[-_ ]?([-\w]+)/i, /(jolla)/i, /(oppo) ?([\w ]+) bui/i], [g, h, [b,
                            x]], [/(archos) (gamepad2?)/i, /(hp).+(touchpad(?!.+tablet)|tablet)/i,
                            /(kindle)\/([\w\.]+)/i, /(nook)[\w ]+build\/(\w+)/i,
                            /(dell) (strea[kpr\d ]*[\dko])/i, /(le[- ]+pan)[- ]+(\w{1,9}) bui/i,
                            /(trinity)[- ]*(t\d{3}) bui/i, /(gigaset)[- ]+(q\w{1,9}) bui/i,
                            /(vodafone) ([\w ]+)(?:\)| bui)/i], [g, h, [b, k]], [/(surface duo)/i], [h,
                            [g, L], [b, k]], [/droid [\d\.]+; (fp\du?)(?: b|\))/i], [h, [g, "Fairphone"],
                            [b, x]], [/(u304aa)/i], [h, [g, "AT&T"], [b, x]], [/\bsie-(\w*)/i], [h, [g,
                            "Siemens"], [b, x]], [/\b(rct\w+) b/i], [h, [g, "RCA"], [b, k]], [
                            /\b(venue[\d ]{2,7}) b/i], [h, [g, "Dell"], [b, k]], [
                            /\b(q(?:mv|ta)\w+) b/i], [h, [g, "Verizon"], [b, k]], [
                            /\b(?:barnes[& ]+noble |bn[rt])([\w\+ ]*) b/i], [h, [g, "Barnes & Noble"],
                            [b, k]], [/\b(tm\d{3}\w+) b/i], [h, [g, "NuVision"], [b, k]], [/\b(k88) b/i],
                        [h, [g, "ZTE"], [b, k]], [/\b(nx\d{3}j) b/i], [h, [g, "ZTE"], [b, x]], [
                            /\b(gen\d{3}) b.+49h/i], [h, [g, "Swiss"], [b, x]], [/\b(zur\d{3}) b/i], [h,
                            [g, "Swiss"], [b, k]], [/\b((zeki)?tb.*\b) b/i], [h, [g, "Zeki"], [b, k]],
                        [/\b([yr]\d{2}) b/i, /\b(dragon[- ]+touch |dt)(\w{5}) b/i], [[g, "Dragon Touch"],
                            h, [b, k]], [/\b(ns-?\w{0,9}) b/i], [h, [g, "Insignia"], [b, k]], [
                            /\b((nxa|next)-?\w{0,9}) b/i], [h, [g, "NextBook"], [b, k]], [
                            /\b(xtreme\_)?(v(1[045]|2[015]|[3469]0|7[05])) b/i], [[g, "Voice"], h, [b,
                            x]], [/\b(lvtel\-)?(v1[12]) b/i], [[g, "LvTel"], h, [b, x]], [/\b(ph-1) /i],
                        [h, [g, "Essential"], [b, x]], [/\b(v(100md|700na|7011|917g).*\b) b/i], [h, [g,
                            "Envizen"], [b, k]], [/\b(trio[-\w\. ]+) b/i], [h, [g, "MachSpeed"], [b, k]],
                        [/\btu_(1491) b/i], [h, [g, "Rotor"], [b, k]], [/(shield[\w ]+) b/i], [h, [g,
                            "Nvidia"], [b, k]], [/(sprint) (\w+)/i], [g, h, [b, x]], [
                            /(kin\.[onetw]{3})/i], [[h, /\./g, " "], [g, L], [b, x]], [
                            /droid.+; (cc6666?|et5[16]|mc[239][23]x?|vc8[03]x?)\)/i], [h, [g, Y], [b, k]],
                        [/droid.+; (ec30|ps20|tc[2-8]\d[kx])\)/i], [h, [g, Y], [b, x]], [/(ouya)/i,
                            /(nintendo) ([wids3utch]+)/i], [g, h, [b, v]], [/droid.+; (shield) bui/i],
                        [h, [g, "Nvidia"], [b, v]], [/(playstation [345portablevi]+)/i], [h, [g, M], [b,
                            v]], [/\b(xbox(?: one)?(?!; xbox))[\); ]/i], [h, [g, L], [b, v]], [
                            /smart-tv.+(samsung)/i], [g, [b, j]], [/hbbtv.+maple;(\d+)/i], [[h, /^/,
                            "SmartTV"], [g, B], [b, j]], [
                            /(nux; netcast.+smarttv|lg (netcast\.tv-201\d|android tv))/i], [[g, q], [b,
                            j]], [/(apple) ?tv/i], [g, [h, E + " TV"], [b, j]], [/crkey/i], [[h, T +
                            "cast"], [g, R], [b, j]], [/droid.+aft(\w)( bui|\))/i], [h, [g, C], [b, j]],
                        [/\(dtv[\);].+(aquos)/i], [h, [g, "Sharp"], [b, j]], [
                            /\b(roku)[\dx]*[\)\/]((?:dvp-)?[\d\.]*)/i,
                            /hbbtv\/\d+\.\d+\.\d+ +\([\w ]*; *(\w[^;]*);([^;]*)/i], [[g, Z], [h, Z], [b,
                            j]], [/\b(android tv|smart[- ]?tv|opera tv|tv; rv:)\b/i], [[b, j]], [
                            /((pebble))app/i], [g, h, [b, S]], [/droid.+; (glass) \d/i], [h, [g, R], [b,
                            S]], [/droid.+; (wt63?0{2,3})\)/i], [h, [g, Y], [b, S]], [/(quest( 2)?)/i],
                        [h, [g, H], [b, S]], [/(tesla)(?: qtcarbrowser|\/[-\w\.]+)/i], [g, [b, _]], [
                            /droid .+?; ([^;]+?)(?: bui|\) applew).+? mobile safari/i], [h, [b, x]], [
                            /droid .+?; ([^;]+?)(?: bui|\) applew).+?(?! mobile) safari/i], [h, [b, k]],
                        [/\b((tablet|tab)[;\/]|focus\/\d(?!.+mobile))/i], [[b, k]], [
                            /(phone|mobile(?:[;\/]| safari)|pda(?=.+windows ce))/i], [[b, x]], [
                            /(android[-\w\. ]{0,9});.+buil/i], [h, [g, "Generic"]]],
                    engine: [[/windows.+ edge\/([\w\.]+)/i], [y, [f, I + "HTML"]], [
                            /webkit\/537\.36.+chrome\/(?!27)([\w\.]+)/i], [y, [f, "Blink"]], [
                            /(presto)\/([\w\.]+)/i,
                            /(webkit|trident|netfront|netsurf|amaya|lynx|w3m|goanna)\/([\w\.]+)/i,
                            /ekioh(flow)\/([\w\.]+)/i, /(khtml|tasman|links)[\/ ]\(?([\w\.]+)/i,
                            /(icab)[\/ ]([23]\.[\d\.]+)/i], [f, y], [/rv\:([\w\.]{1,9})\b.+(gecko)/i],
                        [y, f]],
                    os: [[/microsoft (windows) (vista|xp)/i], [f, y], [/(windows) nt 6\.2; (arm)/i,
                            /(windows (?:phone(?: os)?|mobile))[\/ ]?([\d\.\w ]*)/i,
                            /(windows)[\/ ]?([ntce\d\. ]+\w)(?!.+xbox)/i], [f, [y, K, te]], [
                            /(win(?=3|9|n)|win 9x )([nt\d\.]+)/i], [[f, "Windows"], [y, K, te]], [
                            /ip[honead]{2,4}\b(?:.*os ([\w]+) like mac|; opera)/i,
                            /cfnetwork\/.+darwin/i], [[y, /_/g, "."], [f, "iOS"]], [
                            /(mac os x) ?([\w\. ]*)/i, /(macintosh|mac_powerpc\b)(?!.+haiku)/i], [[f,
                            "Mac OS"], [y, /_/g, "."]], [/droid ([\w\.]+)\b.+(android[- ]x86)/i], [y, f],
                        [/(android|webos|qnx|bada|rim tablet os|maemo|meego|sailfish)[-\/ ]?([\w\.]*)/i,
                            /(blackberry)\w*\/([\w\.]*)/i, /(tizen|kaios)[\/ ]([\w\.]+)/i,
                            /\((series40);/i], [f, y], [/\(bb(10);/i], [y, [f, z]], [
                            /(?:symbian ?os|symbos|s60(?=;)|series60)[-\/ ]?([\w\.]*)/i], [y, [f,
                            "Symbian"]], [
                            /mozilla\/[\d\.]+ \((?:mobile|tablet|tv|mobile; [\w ]+); rv:.+ gecko\/([\w\.]+)/i
                            ], [y, [f, $ + " OS"]], [/web0s;.+rt(tv)/i,
                            /\b(?:hp)?wos(?:browser)?\/([\w\.]+)/i], [y, [f, "webOS"]], [
                            /crkey\/([\d\.]+)/i], [y, [f, T + "cast"]], [/(cros) [\w]+ ([\w\.]+\w)/i],
                        [[f, "Chromium OS"], y], [/(nintendo|playstation) ([wids345portablevuch]+)/i,
                            /(xbox); +xbox ([^\);]+)/i, /\b(joli|palm)\b ?(?:os)?\/?([\w\.]*)/i,
                            /(mint)[\/\(\) ]?(\w*)/i, /(mageia|vectorlinux)[; ]/i,
                            /([kxln]?ubuntu|debian|suse|opensuse|gentoo|arch(?= linux)|slackware|fedora|mandriva|centos|pclinuxos|red ?hat|zenwalk|linpus|raspbian|plan 9|minix|risc os|contiki|deepin|manjaro|elementary os|sabayon|linspire)(?: gnu\/linux)?(?: enterprise)?(?:[- ]linux)?(?:-gnu)?[-\/ ]?(?!chrom|package)([-\w\.]*)/i,
                            /(hurd|linux) ?([\w\.]*)/i, /(gnu) ?([\w\.]*)/i,
                            /\b([-frentopcghs]{0,5}bsd|dragonfly)[\/ ]?(?!amd|[ix346]{1,2}86)([\w\.]*)/i,
                            /(haiku) (\w+)/i], [f, y], [/(sunos) ?([\w\.\d]*)/i], [[f, "Solaris"], y],
                        [/((?:open)?solaris)[-\/ ]?([\w\.]*)/i, /(aix) ((\d)(?=\.|\)| )[\w\.])*/i,
                            /\b(beos|os\/2|amigaos|morphos|openvms|fuchsia|hp-ux)/i,
                            /(unix) ?([\w\.]*)/i], [f, y]]
                },
                oe = function (e, t) {
                    if (typeof e === m && (t = e, e = i), !(this instanceof oe)) return new oe(e, t).getResult();
                    var n = e || (typeof r !== u && r.navigator && r.navigator.userAgent ? r.navigator.userAgent :
                            s),
                        o = t ? W(ne, t) : ne;
                    return this.getBrowser = function () {
                        var e = {};
                        return e[f] = i, e[y] = i, X.call(e, n, o.browser), e.major = J(e.version), e
                    }, this.getCPU = function () {
                        var e = {};
                        return e[w] = i, X.call(e, n, o.cpu), e
                    }, this.getDevice = function () {
                        var e = {};
                        return e[g] = i, e[h] = i, e[b] = i, X.call(e, n, o.device), e
                    }, this.getEngine = function () {
                        var e = {};
                        return e[f] = i, e[y] = i, X.call(e, n, o.engine), e
                    }, this.getOS = function () {
                        var e = {};
                        return e[f] = i, e[y] = i, X.call(e, n, o.os), e
                    }, this.getResult = function () {
                        return {
                            ua: this.getUA(),
                            browser: this.getBrowser(),
                            engine: this.getEngine(),
                            os: this.getOS(),
                            device: this.getDevice(),
                            cpu: this.getCPU()
                        }
                    }, this.getUA = function () {
                        return n
                    }, this.setUA = function (e) {
                        return n = typeof e === p && e.length > A ? Z(e, A) : e, this
                    }, this.setUA(n), this
                };
            oe.VERSION = a, oe.BROWSER = V([f, y, d]), oe.CPU = V([w]), oe.DEVICE = V([h, g, b, v, x, j, k,
                S, _]), oe.ENGINE = oe.OS = V([f, y]), typeof t !== u ? (typeof e !== u && e.exports &&
                (t = e.exports = oe), t.UAParser = oe) : "function" === l && n("3c35") ? (o = function () {
                return oe
            }.call(t, n, t, e), o === i || (e.exports = o)) : typeof r !== u && (r.UAParser = oe);
            var re = typeof r !== u && (r.jQuery || r.Zepto);
            if (re && !re.ua) {
                var ie = new oe;
                re.ua = ie.getResult(), re.ua.get = function () {
                    return ie.getUA()
                }, re.ua.set = function (e) {
                    ie.setUA(e);
                    var t = ie.getResult();
                    for (var n in t) re.ua[n] = t[n]
                }
            }
        })("object" === typeof window ? window : this)
    },
    "2ba4": function (e, t) {
        var n = Function.prototype,
            o = n.apply,
            r = n.bind,
            i = n.call;
        e.exports = "object" == typeof Reflect && Reflect.apply || (r ? i.bind(o) : function () {
            return i.apply(o, arguments)
        })
    },
    "2c10": function (e, t, n) {
        "use strict";
        var o = n("a0d3"),
            r = n("00ce"),
            i = r("%TypeError%"),
            a = n("b398"),
            s = n("ef10"),
            c = n("2054");
        e.exports = function (e) {
            if ("Object" !== a(e)) throw new i("ToPropertyDescriptor requires an object");
            var t = {};
            if (o(e, "enumerable") && (t["[[Enumerable]]"] = s(e.enumerable)), o(e, "configurable") && (t[
                    "[[Configurable]]"] = s(e.configurable)), o(e, "value") && (t["[[Value]]"] = e.value),
                o(e, "writable") && (t["[[Writable]]"] = s(e.writable)), o(e, "get")) {
                var n = e.get;
                if ("undefined" !== typeof n && !c(n)) throw new i("getter must be a function");
                t["[[Get]]"] = n
            }
            if (o(e, "set")) {
                var r = e.set;
                if ("undefined" !== typeof r && !c(r)) throw new i("setter must be a function");
                t["[[Set]]"] = r
            }
            if ((o(t, "[[Get]]") || o(t, "[[Set]]")) && (o(t, "[[Value]]") || o(t, "[[Writable]]"))) throw new i(
                "Invalid property descriptor. Cannot both specify accessors and a value or writable attribute"
            );
            return t
        }
    },
    "2d00": function (e, t, n) {
        var o, r, i = n("da84"),
            a = n("342f"),
            s = i.process,
            c = i.Deno,
            l = s && s.versions || c && c.version,
            u = l && l.v8;
        u && (o = u.split("."), r = o[0] > 0 && o[0] < 4 ? 1 : +(o[0] + o[1])), !r && a && (o = a.match(
                /Edge\/(\d+)/), (!o || o[1] >= 74) && (o = a.match(/Chrome\/(\d+)/), o && (r = +o[1]))), e.exports =
            r
    },
    "2d83": function (e, t, n) {
        "use strict";
        var o = n("387f");
        e.exports = function (e, t, n, r, i) {
            var a = new Error(e);
            return o(a, t, n, r, i)
        }
    },
    "2e67": function (e, t, n) {
        "use strict";
        e.exports = function (e) {
            return !(!e || !e.__CANCEL__)
        }
    },
    "30b5": function (e, t, n) {
        "use strict";
        var o = n("c532");

        function r(e) {
            return encodeURIComponent(e).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(
                /%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]")
        }
        e.exports = function (e, t, n) {
            if (!t) return e;
            var i;
            if (n) i = n(t);
            else if (o.isURLSearchParams(t)) i = t.toString();
            else {
                var a = [];
                o.forEach(t, (function (e, t) {
                    null !== e && "undefined" !== typeof e && (o.isArray(e) ? t += "[]" : e = [
                        e], o.forEach(e, (function (e) {
                        o.isDate(e) ? e = e.toISOString() : o.isObject(e) && (e =
                            JSON.stringify(e)), a.push(r(t) + "=" + r(e))
                    })))
                })), i = a.join("&")
            }
            if (i) {
                var s = e.indexOf("#"); - 1 !== s && (e = e.slice(0, s)), e += (-1 === e.indexOf("?") ? "?" :
                    "&") + i
            }
            return e
        }
    },
    "342f": function (e, t, n) {
        var o = n("d066");
        e.exports = o("navigator", "userAgent") || ""
    },
    "35d6": function (e, t, n) {
        "use strict";

        function o(e, t) {
            for (var n = [], o = {}, r = 0; r < t.length; r++) {
                var i = t[r],
                    a = i[0],
                    s = i[1],
                    c = i[2],
                    l = i[3],
                    u = {
                        id: e + ":" + r,
                        css: s,
                        media: c,
                        sourceMap: l
                    };
                o[a] ? o[a].parts.push(u) : n.push(o[a] = {
                    id: a,
                    parts: [u]
                })
            }
            return n
        }

        function r(e, t, n) {
            var r = o(e, t);
            i(r, n)
        }

        function i(e, t) {
            const n = t._injectedStyles || (t._injectedStyles = {});
            for (var o = 0; o < e.length; o++) {
                var r = e[o],
                    i = n[r.id];
                if (!i) {
                    for (var a = 0; a < r.parts.length; a++) s(r.parts[a], t);
                    n[r.id] = !0
                }
            }
        }

        function a(e) {
            var t = document.createElement("style");
            return t.type = "text/css", e.appendChild(t), t
        }

        function s(e, t) {
            var n = a(t),
                o = e.css,
                r = e.media,
                i = e.sourceMap;
            if (r && n.setAttribute("media", r), i && (o += "\n/*# sourceURL=" + i.sources[0] + " */", o +=
                    "\n/*# sourceMappingURL=data:application/json;base64," + btoa(unescape(encodeURIComponent(
                        JSON.stringify(i)))) + " */"), n.styleSheet) n.styleSheet.cssText = o;
            else {
                while (n.firstChild) n.removeChild(n.firstChild);
                n.appendChild(document.createTextNode(o))
            }
        }
        n.r(t), n.d(t, "default", (function () {
            return r
        }))
    },
    "387f": function (e, t, n) {
        "use strict";
        e.exports = function (e, t, n, o, r) {
            return e.config = t, n && (e.code = n), e.request = o, e.response = r, e.isAxiosError = !0, e.toJSON =
                function () {
                    return {
                        message: this.message,
                        name: this.name,
                        description: this.description,
                        number: this.number,
                        fileName: this.fileName,
                        lineNumber: this.lineNumber,
                        columnNumber: this.columnNumber,
                        stack: this.stack,
                        config: this.config,
                        code: this.code
                    }
                }, e
        }
    },
    3934: function (e, t, n) {
        "use strict";
        var o = n("c532");
        e.exports = o.isStandardBrowserEnv() ? function () {
            var e, t = /(msie|trident)/i.test(navigator.userAgent),
                n = document.createElement("a");

            function r(e) {
                var o = e;
                return t && (n.setAttribute("href", o), o = n.href), n.setAttribute("href", o), {
                    href: n.href,
                    protocol: n.protocol ? n.protocol.replace(/:$/, "") : "",
                    host: n.host,
                    search: n.search ? n.search.replace(/^\?/, "") : "",
                    hash: n.hash ? n.hash.replace(/^#/, "") : "",
                    hostname: n.hostname,
                    port: n.port,
                    pathname: "/" === n.pathname.charAt(0) ? n.pathname : "/" + n.pathname
                }
            }
            return e = r(window.location.href),
                function (t) {
                    var n = o.isString(t) ? r(t) : t;
                    return n.protocol === e.protocol && n.host === e.host
                }
        }() : function () {
            return function () {
                return !0
            }
        }()
    },
    "3a9b": function (e, t, n) {
        var o = n("e330");
        e.exports = o({}.isPrototypeOf)
    },
    "3bbe": function (e, t, n) {
        var o = n("da84"),
            r = n("1626"),
            i = o.String,
            a = o.TypeError;
        e.exports = function (e) {
            if ("object" == typeof e || r(e)) return e;
            throw a("Can't set " + i(e) + " as a prototype")
        }
    },
    "3c35": function (e, t) {
        (function (t) {
            e.exports = t
        }).call(this, {})
    },
    "3eb1": function (e, t, n) {
        "use strict";
        var o = n("0f7c"),
            r = n("00ce"),
            i = r("%Function.prototype.apply%"),
            a = r("%Function.prototype.call%"),
            s = r("%Reflect.apply%", !0) || o.call(a, i),
            c = r("%Object.getOwnPropertyDescriptor%", !0),
            l = r("%Object.defineProperty%", !0),
            u = r("%Math.max%");
        if (l) try {
            l({}, "a", {
                value: 1
            })
        } catch (p) {
            l = null
        }
        e.exports = function (e) {
            var t = s(o, a, arguments);
            if (c && l) {
                var n = c(t, "length");
                n.configurable && l(t, "length", {
                    value: 1 + u(0, e.length - (arguments.length - 1))
                })
            }
            return t
        };
        var m = function () {
            return s(o, i, arguments)
        };
        l ? l(e.exports, "apply", {
            value: m
        }) : e.exports.apply = m
    },
    "3f17": function (e, t, n) {
        "use strict";
        var o, r = function () {
                var e = this,
                    t = e.$createElement,
                    n = e._self._c || t;
                return e.isCurrReply ? n("section", {
                    ref: "editor",
                    staticClass: "comment-editor",
                    attrs: {
                        id: e.respondId,
                        role: "form"
                    }
                }, [e.isReply ? n("h3", {
                    staticClass: "comment-reply-title",
                    attrs: {
                        id: "reply-title"
                    }
                }, [n("small", [n("a", {
                    staticClass: "cancel-comment-reply-link",
                    attrs: {
                        href: "javascript:;"
                    },
                    on: {
                        click: e.cancelReply
                    }
                }, [e._v("取消回复")])])]) : e._e(), n("form", {
                    staticClass: "comment-form"
                }, [e.previewMode ? n("div", {
                    staticClass: "comment-preview markdown-body",
                    domProps: {
                        innerHTML: e._s(e.renderedContent)
                    }
                }) : n("div", {
                    staticClass: "comment-textarea"
                }, [n("textarea", {
                    directives: [{
                        name: "model",
                        rawName: "v-model",
                        value: e.comment.content,
                        expression: "comment.content"
                    }],
                    staticClass: "commentbody",
                    attrs: {
                        required: "required",
                        "aria-required": "true",
                        tabindex: "4",
                        placeholder: e.configs.aWord ||
                            "欢迎您，请点击此处，动动您的小手指，留下您的👣  ..."
                    },
                    domProps: {
                        value: e.comment.content
                    },
                    on: {
                        input: function (t) {
                            t.target.composing || e.$set(e.comment,
                                "content", t.target.value)
                        }
                    }
                }), n("label", {
                    staticClass: "input-label"
                }, [e._v(e._s(e.configs.aWord || "欢迎您，请点击此处，动动您的小手指，留下您的👣 ..."))])]), n(
                    "div", {
                        attrs: {
                            id: "upload-img-show"
                        }
                    }), n("p", {
                    staticClass: "no-select",
                    attrs: {
                        id: "emotion-toggle"
                    }
                }, [n("span", {
                    on: {
                        click: e.handleToggleDialogEmoji
                    }
                }, [e._v(e._s(e.emojiDialogVisible ? "嘿嘿嘿 😁" : "戳我试试 😘"))])]), n(
                    "transition", {
                        attrs: {
                            name: "emoji-fade"
                        }
                    }, [e.emojiDialogVisible ? n("VEmojiPicker", {
                        attrs: {
                            pack: e.emojiPack
                        },
                        on: {
                            select: e.handleSelectEmoji
                        }
                    }) : e._e()], 1), n("div", {
                    staticClass: "author-info"
                }, [n("div", {
                    staticClass: "commentator",
                    staticStyle: {
                        "pointer-events": "initial"
                    },
                    on: {
                        click: e.handleAvatarUploadInputOpen
                    }
                }, [n("input", {
                    ref: "commentAvatarUploadFileInputEle",
                    staticStyle: {
                        display: "none"
                    },
                    attrs: {
                        type: "file",
                        accept: "image/*"
                    },
                    on: {
                        change: function (t) {
                            return e.handleAvatarUpload(t)
                        }
                    }
                }), n("img", {
                    staticClass: "avatar",
                    attrs: {
                        src: e.avatar
                    },
                    on: {
                        error: e.handleAvatarError
                    }
                }), n("div", {
                    staticClass: "socila-check",
                    class: [e.checkType.back]
                }, [n("i", {
                    class: [e.checkType.icon],
                    attrs: {
                        "aria-hidden": "true"
                    }
                })])]), n("PopupInput", {
                    staticClass: "cmt-popup cmt-author",
                    attrs: {
                        popupStyle: "margin-left: -115px",
                        popupText: e.configs.authorPopup ||
                            "输入QQ号将自动拉取昵称和头像 ♪(´▽｀)",
                        inputType: "text",
                        placeholder: "* 昵称",
                        id: "author",
                        localStorageDataCacheKey: "qiushaocloud-halo-comment-author"
                    },
                    on: {
                        blurInput: e.pullInfo
                    },
                    model: {
                        value: e.comment.author,
                        callback: function (t) {
                            e.$set(e.comment, "author", t)
                        },
                        expression: "comment.author"
                    }
                }), n("PopupInput", {
                    staticClass: "cmt-popup",
                    attrs: {
                        popupStyle: "margin-left: -65px;",
                        popupText: e.configs.emailPopup || "您的邮箱将收到回复通知 ๑乛◡乛๑",
                        inputType: "text",
                        placeholder: "* 电子邮件",
                        id: "email",
                        localStorageDataCacheKey: "qiushaocloud-halo-comment-email"
                    },
                    on: {
                        blurInput: e.pullInfo
                    },
                    model: {
                        value: e.comment.email,
                        callback: function (t) {
                            e.$set(e.comment, "email", t)
                        },
                        expression: "comment.email"
                    }
                }), n("PopupInput", {
                    staticClass: "cmt-popup",
                    attrs: {
                        popupStyle: "margin-left: -55px;",
                        popupText: e.configs.urlPopup || "请不要打小广告哦 (^し^)",
                        inputType: "text",
                        placeholder: "个人站点",
                        id: "url",
                        localStorageDataCacheKey: "qiushaocloud-halo-comment-authorUrl"
                    },
                    model: {
                        value: e.comment.authorUrl,
                        callback: function (t) {
                            e.$set(e.comment, "authorUrl", t)
                        },
                        expression: "comment.authorUrl"
                    }
                })], 1), n("ul", {
                    staticClass: "comment-buttons"
                }, [e.comment.content ? n("li", {
                    staticClass: "middle",
                    staticStyle: {
                        "margin-right": "5px"
                    }
                }, [n("a", {
                    staticClass: "button-preview-edit",
                    attrs: {
                        href: "javascript:;",
                        rel: "nofollow noopener"
                    },
                    on: {
                        click: e.handlePreviewContent
                    }
                }, [e._v(e._s(e.previewMode ? "编辑" : "预览"))])]) : e._e(), n("li", {
                    staticClass: "middle"
                }, [n("a", {
                    staticClass: "button-submit",
                    attrs: {
                        href: "javascript:;",
                        tabindex: "5",
                        rel: "nofollow noopener"
                    },
                    on: {
                        click: e.handleSubmitClick
                    }
                }, [e._v("提交")])])])], 1)]) : e._e()
            },
            i = [],
            a = n("8bbf"),
            s = n.n(a),
            c = n("e7f9"),
            l = n.n(c),
            u = n("6821"),
            m = n.n(u),
            p = function () {
                var e = this,
                    t = e.$createElement,
                    n = e._self._c || t;
                return n("div", {
                    staticClass: "emotion-box no-select"
                }, [e.showCategory ? n("Categories", {
                    on: {
                        select: function (t) {
                            return e.onChangeCategory(t)
                        }
                    }
                }) : e._e(), n("keep-alive", [n("EmojiList", {
                    attrs: {
                        data: e.emojis,
                        category: e.category
                    },
                    on: {
                        select: function (t) {
                            return e.onSelectEmoji(arguments)
                        }
                    }
                })], 1)], 1)
            },
            d = [],
            h = function () {
                var e = this,
                    t = e.$createElement,
                    n = e._self._c || t;
                return n("transition", {
                    attrs: {
                        name: "category"
                    }
                }, [n("table", {
                    staticClass: "motion-switcher-table"
                }, [n("tbody", [n("tr", e._l(e.categories, (function (t, o) {
                    return n("th", {
                        key: o,
                        class: ["category", t.name + "-box", {
                            active: o === e.active
                        }, {
                            "on-hover": o === e.active
                        }],
                        on: {
                            click: function (t) {
                                return e.onSelect(o)
                            }
                        }
                    }, [e._v(" " + e._s(t.title) + " ")])
                })), 0)])])])
            },
            f = [],
            b = {
                name: "Categories",
                data: () => ({
                    categories: [{
                        name: "haha",
                        title: "Haha"
                    }, {
                        name: "bilibili",
                        title: "Bilibili"
                    }, {
                        name: "menhera",
                        title: "(✪ω✪)"
                    }],
                    active: 0
                }),
                methods: {
                    onSelect(e) {
                        this.active = e;
                        const t = this.categories[e];
                        this.$emit("select", t)
                    }
                }
            },
            g = b,
            y = n("2877"),
            w = Object(y["a"])(g, h, f, !1, null, null, null, !0),
            v = w.exports,
            x = function () {
                var e = this,
                    t = e.$createElement,
                    n = e._self._c || t;
                return n("div", {
                    staticClass: "motion-container",
                    class: e.categoryClass,
                    attrs: {
                        id: "container-emoji"
                    }
                }, e._l(e.data[e.category], (function (t, o) {
                    return n(e.categoryEmoji, {
                        key: o,
                        tag: "component",
                        attrs: {
                            data: t
                        },
                        nativeOn: {
                            click: function (n) {
                                return e.onSelect(t, e.type)
                            }
                        }
                    })
                })), 1)
            },
            k = [],
            j = function () {
                var e = this,
                    t = e.$createElement,
                    n = e._self._c || t;
                return n("span", {
                    staticClass: "emoji-item",
                    attrs: {
                        title: e.data.description
                    }
                }, [n("img", {
                    attrs: {
                        src: e.hahaSrc
                    }
                })])
            },
            S = [],
            _ = {
                name: "HahaEmoji",
                props: {
                    data: {
                        type: Object
                    },
                    url: {
                        type: String,
                        required: !1,
                        default: "https://cdn.jsdelivr.net/gh/qiushaocloud/cdn-static@master/halo-comment/emoji/haha/"
                    }
                },
                computed: {
                    hahaSrc() {
                        return this.url + "icon_" + this.data.name.replace("ha-", "") + ".png"
                    }
                }
            },
            A = _,
            C = Object(y["a"])(A, j, S, !1, null, null, null, !0),
            E = C.exports,
            O = function () {
                var e = this,
                    t = e.$createElement,
                    n = e._self._c || t;
                return n("span", {
                    staticClass: "emotion-secter emoji-item emotion-select-parent",
                    style: e.biliSpanStyle
                }, [n("div", {
                    staticClass: "img emotion-select-child",
                    style: e.biliImgStyle
                })])
            },
            z = [],
            P = {
                name: "BilibiliEmoji",
                props: {
                    data: {
                        type: Object
                    },
                    url: {
                        type: String,
                        required: !1,
                        default: "https://cdn.jsdelivr.net/gh/qiushaocloud/cdn-static@master/halo-comment/emoji/bili/"
                    }
                },
                computed: {
                    biliSpanStyle() {
                        return "background-image: url(" + this.url + "hd/ic_emoji_" + this.data.name + ".png);"
                    },
                    biliImgStyle() {
                        let e = this.url + this.data.name + ".png",
                            t = this.data,
                            n = "";
                        return Object.keys(t.style).forEach((function (e) {
                            n += e + ":" + t.style[e] + ";"
                        })), "background-image: url(" + e + ");" + n
                    }
                }
            },
            T = P,
            I = Object(y["a"])(T, O, z, !1, null, null, null, !0),
            $ = I.exports,
            R = function () {
                var e = this,
                    t = e.$createElement,
                    n = e._self._c || t;
                return n("a", {
                    staticClass: "emoji-item text"
                }, [e._v(e._s(e.data.name))])
            },
            N = [],
            q = {
                name: "MenheraEmoji",
                props: {
                    data: {
                        type: Object
                    }
                }
            },
            L = q,
            U = Object(y["a"])(L, R, N, !1, null, null, null, !0),
            D = U.exports,
            B = {
                name: "EmojiList",
                components: {
                    HahaEmoji: E,
                    BilibiliEmoji: $,
                    MenheraEmoji: D
                },
                data: () => ({
                    categories: [{
                        name: "haha",
                        title: "Haha"
                    }, {
                        name: "bilibili",
                        title: "Bilibili"
                    }, {
                        name: "menhera",
                        title: "(✪ω✪)"
                    }]
                }),
                props: {
                    data: {
                        type: Object
                    },
                    category: {
                        type: String
                    }
                },
                methods: {
                    onSelect(e, t) {
                        this.$emit("select", e, t)
                    }
                },
                computed: {
                    categoryClass() {
                        return this.category + "-container"
                    },
                    categoryEmoji() {
                        return this.category + "Emoji"
                    },
                    type() {
                        return "bilibili" === this.category ? "Math" : ["tieba", "haha"].includes(this.category) ?
                            "BBCode" : ""
                    }
                },
                watch: {
                    data() {
                        this.$refs["container-emoji"].scrollTop = 0
                    }
                }
            },
            M = B,
            F = Object(y["a"])(M, x, k, !1, null, null, null, !0),
            Y = F.exports,
            H = {
                name: "VEmojiPicker",
                props: {
                    pack: {
                        type: Array,
                        required: !0
                    },
                    showCategory: {
                        type: Boolean,
                        default: !0
                    }
                },
                components: {
                    Categories: v,
                    EmojiList: Y
                },
                data: () => ({
                    mapEmojis: {},
                    category: "haha"
                }),
                created() {
                    this.mapperData(this.pack)
                },
                methods: {
                    onChangeCategory(e) {
                        this.category = e.name, this.$emit("changeCategory", this.category)
                    },
                    onSelectEmoji(e) {
                        this.$emit("select", e)
                    },
                    mapperData(e) {
                        e.forEach(e => {
                            const t = e["category"];
                            this.mapEmojis[t] ? this.mapEmojis[t].push(e) : this.$set(this.mapEmojis, t,
                                [e])
                        })
                    }
                },
                beforeDestroy() {
                    delete this.mapEmojis
                },
                computed: {
                    emojis() {
                        return this.mapEmojis
                    }
                }
            },
            W = H,
            V = Object(y["a"])(W, p, d, !1, null, null, null, !0),
            G = V.exports,
            Q = n("fb89"),
            J = n("f058"),
            Z = n("ca00"),
            X = n("063c"),
            K = n("bc3a"),
            ee = n.n(K),
            te = function () {
                var e = this,
                    t = e.$createElement,
                    n = e._self._c || t;
                return n("div", {
                    staticClass: "popup"
                }, [n("transition", {
                    attrs: {
                        name: "fade"
                    }
                }, [n("span", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: e.isPopup,
                        expression: "isPopup"
                    }],
                    staticClass: "popuptext",
                    style: e.popupStyle
                }, [e._v(" " + e._s(e.popupText) + " ")])]), n("input", {
                    attrs: {
                        type: e.inputType,
                        required: "required",
                        "aria-required": "true",
                        placeholder: e.placeholder
                    },
                    domProps: {
                        value: e.value
                    },
                    on: {
                        focus: function (t) {
                            e.isPopup = !0
                        },
                        blur: e.inputBlur,
                        input: function (t) {
                            return e.$emit("input", t.target.value)
                        }
                    }
                })], 1)
            },
            ne = [],
            oe = {
                props: {
                    popupStyle: String,
                    popupText: {
                        type: String,
                        required: !0
                    },
                    inputType: {
                        type: String,
                        default: "text"
                    },
                    value: String,
                    placeholder: String,
                    localStorageDataCacheKey: String
                },
                methods: {
                    inputBlur(e) {
                        this.localStorageDataCacheKey && localStorage.setItem(this.localStorageDataCacheKey, e.target
                            .value), this.isPopup = !1, this.$emit("blurInput", e.target.value)
                    }
                },
                data() {
                    return {
                        isPopup: !1
                    }
                }
            },
            re = oe,
            ie = Object(y["a"])(re, te, ne, !1, null, null, null, !0),
            ae = ie.exports,
            se = n("0e4d"),
            ce = n("0e27"),
            le = n.n(ce),
            ue = document.createElement("canvas");
        ue.id = "activate-canvas", ue.width = window.innerWidth, ue.height = window.innerHeight, ue.style.cssText =
            "position:fixed;top:0;left:0;pointer-events:none;z-index:999999", window.addEventListener("resize",
                (function () {
                    ue.width = window.innerWidth, ue.height = window.innerHeight
                }));
        var me = [],
            pe = 0,
            de = !1;

        function he(e, t) {
            return Math.random() * (t - e) + e
        }

        function fe(e) {
            if (ye.colorful) {
                var t = he(0, 360);
                return "hsla(" + he(t - 10, t + 10) + ", 100%, " + he(50, 80) + "%, 1)"
            }
            return window.getComputedStyle(e).color
        }

        function be() {
            var e, t = null != document.activeElement.shadowRoot ? document.activeElement.shadowRoot.activeElement :
                document.activeElement;
            if ("TEXTAREA" === t.tagName || "INPUT" === t.tagName && "text" === t.getAttribute("type")) {
                var n = le()(t, t.selectionEnd);
                return e = t.getBoundingClientRect(), {
                    x: n.left + e.left,
                    y: n.top + e.top,
                    color: fe(t)
                }
            }
            var o = window.getSelection();
            if (o.rangeCount) {
                var r = o.getRangeAt(0),
                    i = r.startContainer;
                return i.nodeType === document.TEXT_NODE && (i = i.parentNode), e = r.getBoundingClientRect(), {
                    x: e.left,
                    y: e.top,
                    color: fe(i)
                }
            }
            return {
                x: 0,
                y: 0,
                color: "transparent"
            }
        }

        function ge(e, t, n) {
            return {
                x: e,
                y: t,
                alpha: 1,
                color: n,
                velocity: {
                    x: 2 * Math.random() - 1,
                    y: 2 * Math.random() - 3.5
                }
            }
        }

        function ye() {
            var e = null != document.activeElement.shadowRoot ? document.activeElement.shadowRoot.ownerDocument :
                document;
            null == e.getElementById("activate-canvas") && (e.body.appendChild(ue), o = ue.getContext("2d"));
            var t = be(),
                n = 5 + Math.round(10 * Math.random());
            while (n--) me[pe] = ge(t.x, t.y, t.color), pe = (pe + 1) % 500;
            if (ye.shake) {
                var r = 1 + 2 * Math.random(),
                    i = r * (Math.random() > .5 ? -1 : 1),
                    a = r * (Math.random() > .5 ? -1 : 1);
                e.body.style.marginLeft = i + "px", e.body.style.marginTop = a + "px", setTimeout((function () {
                    e.body.style.marginLeft = "", e.body.style.marginTop = ""
                }), 75)
            }
            de || requestAnimationFrame(we)
        }

        function we() {
            de = !0, o.clearRect(0, 0, ue.width, ue.height);
            for (var e = !1, t = ue.getBoundingClientRect(), n = 0; n < me.length; ++n) {
                var r = me[n];
                r.alpha <= .1 || (r.velocity.y += .075, r.x += r.velocity.x, r.y += r.velocity.y, r.alpha *=
                    .96, o.globalAlpha = r.alpha, o.fillStyle = r.color, o.fillRect(Math.round(r.x - 1.5) -
                        t.left, Math.round(r.y - 1.5) - t.top, 3, 3), e = !0)
            }
            e ? requestAnimationFrame(we) : de = !1
        }
        ye.shake = !0, ye.colorful = !1;
        var ve = {
                name: "CommentEditor",
                components: {
                    VEmojiPicker: G,
                    PopupInput: ae
                },
                props: {
                    targetId: {
                        type: Number,
                        required: !1,
                        default: 0
                    },
                    target: {
                        type: String,
                        required: !1,
                        default: "posts",
                        validator: function (e) {
                            return -1 !== ["posts", "sheets", "journals"].indexOf(e)
                        }
                    },
                    replyComment: {
                        type: Object,
                        required: !1,
                        default: () => {}
                    },
                    options: {
                        required: !1,
                        default: []
                    },
                    configs: {
                        type: Object,
                        required: !0
                    }
                },
                data() {
                    return {
                        emojiPack: Q["default"],
                        emojiDialogVisible: !1,
                        comment: {
                            author: "",
                            avatar: "",
                            authorUrl: "",
                            email: "",
                            content: ""
                        },
                        previewMode: !1,
                        infoes: [],
                        warnings: [],
                        successes: [],
                        checkType: {
                            back: "gravatar-check",
                            icon: "fa fa-google"
                        },
                        globalData: se["a"],
                        lockPullAvatar: !1,
                        avatar: ""
                    }
                },
                computed: {
                    renderedContent() {
                        const e = this.comment.content ? l()(this.comment.content) : "";
                        return Object(Z["h"])(Object(J["a"])(e))
                    },
                    isReply() {
                        return 0 != this.globalData.replyId
                    },
                    isCurrReply() {
                        const e = !this.replyComment || this.globalData.replyId == this.replyComment.id;
                        return e
                    },
                    respondId() {
                        return "respond-" + (this.replyComment ? this.replyComment.id : 0)
                    }
                },
                watch: {
                    options(e, t) {
                        e && e.gravatar_source !== t.gravatar_source && this.updateAvatar()
                    }
                },
                created() {
                    var e = localStorage.getItem("qiushaocloud-halo-comment-author"),
                        t = localStorage.getItem("qiushaocloud-halo-comment-authorUrl"),
                        n = localStorage.getItem("qiushaocloud-halo-comment-email");
                    this.comment.author = e || "", this.comment.authorUrl = t || "", this.comment.avatar = this
                        .avatar, this.comment.email = n || "", this.updateAvatar(), this.$nextTick(() => {
                            ye.colorful = !0, ye.shake = !1, document.body.addEventListener("input", ye)
                        })
                },
                methods: {
                    handleAvatarUploadInputOpen() {
                        this.configs.isAllowUploadAvatar && this.$refs.commentAvatarUploadFileInputEle.dispatchEvent(
                            new MouseEvent("click"))
                    },
                    handleAvatarUpload(e) {
                        if (!this.configs.isAllowUploadAvatar) return;
                        const t = e.target.files[0];
                        t && X["a"].uploadAvatar(t).then(e => {
                            const t = e.data;
                            200 === t.code ? (console.info("uploadAvatar success, resData:", t), this.avatar =
                                t.data.url, localStorage.setItem("qiushaocloud-halo-comment-avatar",
                                    this.avatar), localStorage.setItem(
                                    "qiushaocloud-halo-comment-avatar-key", this.comment.author +
                                    "###" + this.comment.email)) : console.error(
                                "uploadAvatar failure, resData:", t)
                        }).catch(e => {
                            console.error("uploadAvatar error:", e)
                        })
                    },
                    updateAvatar() {
                        var e = localStorage.getItem("qiushaocloud-halo-comment-avatar");
                        this.avatar = e || this.pullGravatarInfo(!0), localStorage.setItem(
                            "qiushaocloud-halo-comment-avatar", this.avatar), localStorage.setItem(
                            "qiushaocloud-halo-comment-avatar-key", this.comment.author + "###" + this.comment
                            .email)
                    },
                    handleSubmitClick() {
                        Object(Z["b"])(this.comment.author) ? this.$tips("昵称不能为空", 5e3, this) : Object(Z["b"])(
                            this.comment.email) ? this.$tips("邮箱不能为空", 5e3, this) : Object(Z["b"])(this.comment
                            .content) ? this.$tips("评论内容不能为空", 5e3, this) : (this.comment.avatar = this.avatar,
                            this.comment.postId = this.targetId, this.replyComment && (this.comment.parentId =
                                this.replyComment.id), X["a"].createComment(this.target, this.comment, this
                                .configs).then(e => {
                                localStorage.setItem("qiushaocloud-halo-comment-author", this.comment.author),
                                    localStorage.setItem("qiushaocloud-halo-comment-email", this.comment
                                        .email), localStorage.setItem(
                                        "qiushaocloud-halo-comment-authorUrl", this.comment.authorUrl),
                                    localStorage.setItem("qiushaocloud-halo-comment-avatar", this.avatar),
                                    localStorage.setItem("qiushaocloud-halo-comment-avatar-key", this.comment
                                        .author + "###" + this.comment.email), this.$emit(
                                        "checkIsAdmin"), this.comment.content = "", this.previewMode = !
                                    1, this.handleCommentCreated(e.data.data)
                            }).catch(e => {
                                this.previewMode = !1, this.handleFailedToCreateComment(e.response)
                            }))
                    },
                    handlePreviewContent() {
                        this.previewMode = !this.previewMode
                    },
                    handleCommentCreated(e) {
                        if ("PUBLISHED" === e.status) try {
                            0 === e.parentId ? this.$emit("createdNewRootCommentNode", e) : this.createdNewNode(
                                e), this.$tips("评论成功！", 5e3, this), this.$parent.$emit("post-success", {
                                target: this.target,
                                targetId: this.targetId
                            })
                        } catch {
                            this.$tips("评论成功，刷新即可显示最新评论！", 5e3, this)
                        } else this.$tips("您的评论已经投递至博主，等待博主审核！", 5e3, this)
                    },
                    handleAvatarError(e) {
                        const t = e.target || e.srcElement;
                        t.src = this.configs.avatarError, t.onerror = null
                    },
                    createdNewNode(e) {
                        let t = this.$root.$el,
                            o = {
                                targetId: this.targetId,
                                target: this.target,
                                options: this.options,
                                configs: this.configs,
                                comment: e
                            };
                        o = 0 == e.parentId ? o : {
                            ...o,
                            isChild: !0,
                            parent: this.replyComment,
                            depth: this.$parent.selfAddDepth
                        };
                        const r = () => Promise.resolve().then(n.bind(null, "f9af"));
                        let i, a = new s.a({
                            render: e => e(r, {
                                props: o
                            })
                        });
                        if (0 == e.parentId)
                            if (t.getElementsByClassName("commentwrap").length > 0) i = t.getElementsByClassName(
                                "commentwrap")[0];
                            else {
                                i = document.createElement("ul"), i.setAttribute("class", "commentwrap");
                                let e = t.getElementsByClassName("comment-empty")[0];
                                e.parentNode.replaceChild(i, e)
                            }
                        else {
                            let e = t.getElementsByClassName("comment-" + this.replyComment.id)[0],
                                n = e.getElementsByTagName("ul");
                            n.length > 0 ? i = n[0] : (i = document.createElement("ul"), i.setAttribute("class",
                                "children"), e.appendChild(i))
                        }
                        let c = document.createElement("div");
                        i.children[0] ? i.insertBefore(c, i.children[0]) : i.appendChild(c), a.$mount(c)
                    },
                    handleFailedToCreateComment(e) {
                        if (400 === e.status && e.data && (this.$tips(e.data.message, 5e3, this), e.data.data)) {
                            const t = e.data.data;
                            Object(Z["d"])(t) && Object.keys(t).forEach(e => {
                                this.$tips(t[e], 5e3, this)
                            })
                        }
                    },
                    handleToggleDialogEmoji() {
                        this.emojiDialogVisible = !this.emojiDialogVisible
                    },
                    handleSelectEmoji(e) {
                        let t, n, o;
                        0 != e.length && (e.length > 0 && (t = e[0]), e.length > 1 && (n = e[1]), n ? "Math" ===
                            n ? o = "f(x)=∫(" + t.name + ")sec²xdx" : "BBCode" === n && (o =
                                `:${t.name+("gif"===t.extension?"!":"")}:`) : o = t.name, this.comment.content +=
                            " " + o + " ")
                    },
                    handleGithubLogin() {
                        const e = "http://github.com/login/oauth/authorize",
                            t = {
                                client_id: "a1aacd842bc158abd65b",
                                redirect_uri: window.location.href,
                                scope: "public_repo"
                            };
                        window.location.href = `${e}?${Object(Z["f"])(t)}`
                    },
                    handleGetGithubUser() {
                        const e = this.handleGetGithubAccessToken();
                        ee.a.get("https://cors-anywhere.herokuapp.com/https://api.github.com/user", {
                            params: {
                                access_token: e
                            }
                        }).then((function (e) {
                            this.$tips(e, 5e3, this)
                        })).catch(e => {
                            this.$tips(e, 5e3, this)
                        })
                    },
                    handleGetGithubAccessToken() {
                        const e = Object(Z["a"])("code");
                        e && ee.a.get(
                            "https://cors-anywhere.herokuapp.com/https://github.com/login/oauth/access_token", {
                                params: {
                                    client_id: "a1aacd842bc158abd65b",
                                    client_secret: "0daedb3923a4cdeb72620df511bdb11685dfe282",
                                    code: e
                                }
                            }).then((function (e) {
                            let t = e.split("&"),
                                n = t[0].split("="),
                                o = n[1];
                            return this.$tips(o, 5e3, this), o
                        })).catch(e => {
                            this.$tips(e, 5e3, this)
                        })
                    },
                    cancelReply(e) {
                        e.stopPropagation(), this.globalData.replyId = 0, this.globalData.isReplyData = !1
                    },
                    pullInfo() {
                        this.$emit("checkIsAdmin");
                        let e = this.comment.author,
                            t = e;
                        const n = window.localStorage.getItem("qiushaocloud-halo-comment-qq"),
                            o = n ? JSON.parse(n) : void 0;
                        t && o && this.comment.email === o.email && t === o.nickname && (t = o.qq), t && 0 != t
                            .length && Object(Z["e"])(t) ? this.pullQQInfo(() => {
                                this.$tips("拉取QQ信息失败！尝试拉取Gravatar", 2e3, this), this.pullGravatarInfo()
                            }) : this.lockPullAvatar ? this.lockPullAvatar = !1 : this.pullGravatarInfo()
                    },
                    pullQQInfo(e) {
                        let t = this,
                            n = t.comment.author;
                        const o = window.localStorage.getItem("qiushaocloud-halo-comment-qq"),
                            r = o ? JSON.parse(o) : void 0;
                        if (n && r && t.comment.email === r.email && n === r.nickname) {
                            if (Date.now() - r.saveTs < 6e4) return new Promise(e => {
                                t.comment.author = r.nickname, t.comment.email = r.email, t.avatar =
                                    r.avatar, e()
                            });
                            n = r.qq
                        }
                        ee.a.get("https://api.lixingyong.com/api/qq", {
                            params: {
                                id: n
                            }
                        }).then((function (n) {
                            let o = n.data;
                            o.code && 500 == o.code && e(), t.comment.author === o.nickname && t.comment
                                .email === o.email && t.avatar === o.avatar || ( /*t.$tips("拉取QQ头像成功！",2e3,t),*/
                                    t.comment.author = o.nickname, t.comment.email = o.email, t.avatar =
                                    o.avatar, t.lockPullAvatar = !0, t.comment.avatar = t.avatar,
                                    localStorage.setItem("qiushaocloud-halo-comment-author", t.comment
                                        .author), localStorage.setItem(
                                        "qiushaocloud-halo-comment-email", t.comment.email),
                                    localStorage.setItem("qiushaocloud-halo-comment-authorUrl", t.comment
                                        .authorUrl), localStorage.setItem(
                                        "qiushaocloud-halo-comment-avatar", t.avatar), localStorage
                                    .setItem("qiushaocloud-halo-comment-avatar-key", t.comment.author +
                                        "###" + t.comment.email), localStorage.setItem(
                                        "qiushaocloud-halo-comment-qq", JSON.stringify({
                                            qq: o.qq,
                                            nickname: o.nickname,
                                            email: o.email,
                                            avatar: o.avatar,
                                            saveTs: Date.now()
                                        })), t.$emit("checkIsAdmin"))
                        })).catch(() => {
                            e()
                        })
                    },
                    pullGravatarInfo(e) {
                        let t = localStorage.getItem("qiushaocloud-halo-comment-avatar");
                        const n = localStorage.getItem("qiushaocloud-halo-comment-avatar-key");
                        n !== this.comment.author + "###" + this.comment.email && (t = void 0);
                        const o = "/" + m()(this.comment.email),
                            r = this.configs.gravatarSource || this.options.gravatar_source || this.configs.gravatarSourceDefault,
                            i = t || r + (o + "?s=256&d=") + this.options.comment_gravatar_default;
                        if (e) return i;
                        this.avatar = i, localStorage.setItem("qiushaocloud-halo-comment-avatar", this.avatar),
                            localStorage.setItem("qiushaocloud-halo-comment-avatar-key", this.comment.author +
                                "###" + this.comment.email)
                    },
                    viewJump(e, t) {
                        this.$nextTick(() => {
                            var n = t || this.$el;
                            Object(Z["c"])(n, this.$root.$el, "bottom") || e(n)
                        })
                    }
                }
            },
            xe = ve,
            ke = Object(y["a"])(xe, r, i, !1, null, null, null, !0);
        t["a"] = ke.exports
    },
    4362: function (e, t, n) {
        t.nextTick = function (e) {
                var t = Array.prototype.slice.call(arguments);
                t.shift(), setTimeout((function () {
                    e.apply(null, t)
                }), 0)
            }, t.platform = t.arch = t.execPath = t.title = "browser", t.pid = 1, t.browser = !0, t.env = {}, t
            .argv = [], t.binding = function (e) {
                throw new Error("No such module. (Possibly not yet loaded)")
            },
            function () {
                var e, o = "/";
                t.cwd = function () {
                    return o
                }, t.chdir = function (t) {
                    e || (e = n("df7c")), o = e.resolve(t, o)
                }
            }(), t.exit = t.kill = t.umask = t.dlopen = t.uptime = t.memoryUsage = t.uvCounters = function () {},
            t.features = {}
    },
    "44ad": function (e, t, n) {
        var o = n("da84"),
            r = n("e330"),
            i = n("d039"),
            a = n("c6b6"),
            s = o.Object,
            c = r("".split);
        e.exports = i((function () {
            return !s("z").propertyIsEnumerable(0)
        })) ? function (e) {
            return "String" == a(e) ? c(e, "") : s(e)
        } : s
    },
    4600: function (e, t, n) {
        "use strict";
        var o = n("a0d3"),
            r = n("c46d"),
            i = n("b398");
        e.exports = function (e) {
            return "undefined" !== typeof e && (r(i, "Property Descriptor", "Desc", e), !(!o(e, "[[Value]]") &&
                !o(e, "[[Writable]]")))
        }
    },
    "467f": function (e, t, n) {
        "use strict";
        var o = n("2d83");
        e.exports = function (e, t, n) {
            var r = n.config.validateStatus;
            n.status && r && !r(n.status) ? t(o("Request failed with status code " + n.status, n.config,
                null, n.request, n)) : e(n)
        }
    },
    "485a": function (e, t, n) {
        var o = n("da84"),
            r = n("c65b"),
            i = n("1626"),
            a = n("861d"),
            s = o.TypeError;
        e.exports = function (e, t) {
            var n, o;
            if ("string" === t && i(n = e.toString) && !a(o = r(n, e))) return o;
            if (i(n = e.valueOf) && !a(o = r(n, e))) return o;
            if ("string" !== t && i(n = e.toString) && !a(o = r(n, e))) return o;
            throw s("Can't convert object to primitive value")
        }
    },
    4930: function (e, t, n) {
        var o = n("2d00"),
            r = n("d039");
        e.exports = !!Object.getOwnPropertySymbols && !r((function () {
            var e = Symbol();
            return !String(e) || !(Object(e) instanceof Symbol) || !Symbol.sham && o && o < 41
        }))
    },
    "4a0c": function (e) {
        e.exports = JSON.parse(
            '{"name":"axios","version":"0.21.4","description":"Promise based HTTP client for the browser and node.js","main":"index.js","scripts":{"test":"grunt test","start":"node ./sandbox/server.js","build":"NODE_ENV=production grunt build","preversion":"npm test","version":"npm run build && grunt version && git add -A dist && git add CHANGELOG.md bower.json package.json","postversion":"git push && git push --tags","examples":"node ./examples/server.js","coveralls":"cat coverage/lcov.info | ./node_modules/coveralls/bin/coveralls.js","fix":"eslint --fix lib/**/*.js"},"repository":{"type":"git","url":"https://github.com/axios/axios.git"},"keywords":["xhr","http","ajax","promise","node"],"author":"Matt Zabriskie","license":"MIT","bugs":{"url":"https://github.com/axios/axios/issues"},"homepage":"https://axios-http.com","devDependencies":{"coveralls":"^3.0.0","es6-promise":"^4.2.4","grunt":"^1.3.0","grunt-banner":"^0.6.0","grunt-cli":"^1.2.0","grunt-contrib-clean":"^1.1.0","grunt-contrib-watch":"^1.0.0","grunt-eslint":"^23.0.0","grunt-karma":"^4.0.0","grunt-mocha-test":"^0.13.3","grunt-ts":"^6.0.0-beta.19","grunt-webpack":"^4.0.2","istanbul-instrumenter-loader":"^1.0.0","jasmine-core":"^2.4.1","karma":"^6.3.2","karma-chrome-launcher":"^3.1.0","karma-firefox-launcher":"^2.1.0","karma-jasmine":"^1.1.1","karma-jasmine-ajax":"^0.1.13","karma-safari-launcher":"^1.0.0","karma-sauce-launcher":"^4.3.6","karma-sinon":"^1.0.5","karma-sourcemap-loader":"^0.3.8","karma-webpack":"^4.0.2","load-grunt-tasks":"^3.5.2","minimist":"^1.2.0","mocha":"^8.2.1","sinon":"^4.5.0","terser-webpack-plugin":"^4.2.3","typescript":"^4.0.5","url-search-params":"^0.10.0","webpack":"^4.44.2","webpack-dev-server":"^3.11.0"},"browser":{"./lib/adapters/http.js":"./lib/adapters/xhr.js"},"jsdelivr":"dist/axios.min.js","unpkg":"dist/axios.min.js","typings":"./index.d.ts","dependencies":{"follow-redirects":"^1.14.0"},"bundlesize":[{"path":"./dist/axios.min.js","threshold":"5kB"}]}'
        )
    },
    "4a7b": function (e, t, n) {
        "use strict";
        var o = n("c532");
        e.exports = function (e, t) {
            t = t || {};
            var n = {},
                r = ["url", "method", "data"],
                i = ["headers", "auth", "proxy", "params"],
                a = ["baseURL", "transformRequest", "transformResponse", "paramsSerializer", "timeout",
                    "timeoutMessage", "withCredentials", "adapter", "responseType", "xsrfCookieName",
                    "xsrfHeaderName", "onUploadProgress", "onDownloadProgress", "decompress",
                    "maxContentLength", "maxBodyLength", "maxRedirects", "transport", "httpAgent",
                    "httpsAgent", "cancelToken", "socketPath", "responseEncoding"],
                s = ["validateStatus"];

            function c(e, t) {
                return o.isPlainObject(e) && o.isPlainObject(t) ? o.merge(e, t) : o.isPlainObject(t) ? o.merge({},
                    t) : o.isArray(t) ? t.slice() : t
            }

            function l(r) {
                o.isUndefined(t[r]) ? o.isUndefined(e[r]) || (n[r] = c(void 0, e[r])) : n[r] = c(e[r], t[r])
            }
            o.forEach(r, (function (e) {
                o.isUndefined(t[e]) || (n[e] = c(void 0, t[e]))
            })), o.forEach(i, l), o.forEach(a, (function (r) {
                o.isUndefined(t[r]) ? o.isUndefined(e[r]) || (n[r] = c(void 0, e[r])) : n[r] =
                    c(void 0, t[r])
            })), o.forEach(s, (function (o) {
                o in t ? n[o] = c(e[o], t[o]) : o in e && (n[o] = c(void 0, e[o]))
            }));
            var u = r.concat(i).concat(a).concat(s),
                m = Object.keys(e).concat(Object.keys(t)).filter((function (e) {
                    return -1 === u.indexOf(e)
                }));
            return o.forEach(m, l), n
        }
    },
    "4d64": function (e, t, n) {
        var o = n("fc6a"),
            r = n("23cb"),
            i = n("07fa"),
            a = function (e) {
                return function (t, n, a) {
                    var s, c = o(t),
                        l = i(c),
                        u = r(a, l);
                    if (e && n != n) {
                        while (l > u)
                            if (s = c[u++], s != s) return !0
                    } else
                        for (; l > u; u++)
                            if ((e || u in c) && c[u] === n) return e || u || 0;
                    return !e && -1
                }
            };
        e.exports = {
            includes: a(!0),
            indexOf: a(!1)
        }
    },
    5018: function (e, t, n) {
        "use strict";
        var o = n("e9ac"),
            r = o("%Reflect.construct%", !0),
            i = n("ae57");
        try {
            i({}, "", {
                "[[Get]]": function () {}
            })
        } catch (c) {
            i = null
        }
        if (i && r) {
            var a = {},
                s = {};
            i(s, "length", {
                "[[Get]]": function () {
                    throw a
                },
                "[[Enumerable]]": !0
            }), e.exports = function (e) {
                try {
                    r(e, s)
                } catch (t) {
                    return t === a
                }
            }
        } else e.exports = function (e) {
            return "function" === typeof e && !!e.prototype
        }
    },
    "50c4": function (e, t, n) {
        var o = n("5926"),
            r = Math.min;
        e.exports = function (e) {
            return e > 0 ? r(o(e), 9007199254740991) : 0
        }
    },
    5156: function (e, t, n) {
        "use strict";
        var o = "undefined" !== typeof Symbol && Symbol,
            r = n("1696");
        e.exports = function () {
            return "function" === typeof o && ("function" === typeof Symbol && ("symbol" === typeof o("foo") &&
                ("symbol" === typeof Symbol("bar") && r())))
        }
    },
    5183: function (e, t, n) {
        "use strict";
        e.exports = function (e) {
            return null === e ? "Null" : "undefined" === typeof e ? "Undefined" : "function" === typeof e ||
                "object" === typeof e ? "Object" : "number" === typeof e ? "Number" : "boolean" === typeof e ?
                "Boolean" : "string" === typeof e ? "String" : void 0
        }
    },
    "522d": function (e, t, n) {
        "use strict";
        var o = n("be77"),
            r = n("8926"),
            i = n("f367");
        e.exports = function () {
            o();
            var e = r();
            return i(Promise.prototype, {
                finally: e
            }, {
                finally: function () {
                    return Promise.prototype["finally"] !== e
                }
            }), e
        }
    },
    5270: function (e, t, n) {
        "use strict";
        var o = n("c532"),
            r = n("c401"),
            i = n("2e67"),
            a = n("2444");

        function s(e) {
            e.cancelToken && e.cancelToken.throwIfRequested()
        }
        e.exports = function (e) {
            s(e), e.headers = e.headers || {}, e.data = r.call(e, e.data, e.headers, e.transformRequest), e
                .headers = o.merge(e.headers.common || {}, e.headers[e.method] || {}, e.headers), o.forEach(
                    ["delete", "get", "head", "post", "put", "patch", "common"], (function (t) {
                        delete e.headers[t]
                    }));
            var t = e.adapter || a.adapter;
            return t(e).then((function (t) {
                return s(e), t.data = r.call(e, t.data, t.headers, e.transformResponse), t
            }), (function (t) {
                return i(t) || (s(e), t && t.response && (t.response.data = r.call(e, t.response
                    .data, t.response.headers, e.transformResponse))), Promise.reject(t)
            }))
        }
    },
    "545e": function (e, t, n) {
        "use strict";
        var o = n("00ce"),
            r = n("3eb1"),
            i = r(o("String.prototype.indexOf"));
        e.exports = function (e, t) {
            var n = o(e, !!t);
            return "function" === typeof n && i(e, ".prototype.") > -1 ? r(n) : n
        }
    },
    5692: function (e, t, n) {
        var o = n("c430"),
            r = n("c6cd");
        (e.exports = function (e, t) {
            return r[e] || (r[e] = void 0 !== t ? t : {})
        })("versions", []).push({
            version: "3.20.2",
            mode: o ? "pure" : "global",
            copyright: "© 2022 Denis Pushkarev (zloirock.ru)"
        })
    },
    "56ef": function (e, t, n) {
        var o = n("d066"),
            r = n("e330"),
            i = n("241c"),
            a = n("7418"),
            s = n("825a"),
            c = r([].concat);
        e.exports = o("Reflect", "ownKeys") || function (e) {
            var t = i.f(s(e)),
                n = a.f;
            return n ? c(t, n(e)) : t
        }
    },
    "577e": function (e, t, n) {
        var o = n("da84"),
            r = n("f5df"),
            i = o.String;
        e.exports = function (e) {
            if ("Symbol" === r(e)) throw TypeError("Cannot convert a Symbol value to a string");
            return i(e)
        }
    },
    5926: function (e, t) {
        var n = Math.ceil,
            o = Math.floor;
        e.exports = function (e) {
            var t = +e;
            return t !== t || 0 === t ? 0 : (t > 0 ? o : n)(t)
        }
    },
    "59ed": function (e, t, n) {
        var o = n("da84"),
            r = n("1626"),
            i = n("0d51"),
            a = o.TypeError;
        e.exports = function (e) {
            if (r(e)) return e;
            throw a(i(e) + " is not a function")
        }
    },
    "5a74": function (e, t, n) {
        "use strict";
        if (n.r(t), "undefined" !== typeof window) {
            var o = window.document.currentScript;
            if (Object({
                    NODE_ENV: "production",
                    BASE_URL: "/"
                }).NEED_CURRENTSCRIPT_POLYFILL) {
                var r = n("8875");
                o = r(), "currentScript" in document || Object.defineProperty(document, "currentScript", {
                    get: r
                })
            }
            var i = o && o.src.match(/(.+\/)[^/]+\.js(\?.*)?$/);
            i && (n.p = i[1])
        }
        var a = n("8bbf"),
            s = n.n(a);
        const c = /-(\w)/g,
            l = e => e.replace(c, (e, t) => t ? t.toUpperCase() : ""),
            u = /\B([A-Z])/g,
            m = e => e.replace(u, "-$1").toLowerCase();

        function p(e) {
            const t = {};
            return e.forEach(e => {
                t[e] = void 0
            }), t
        }

        function d(e, t, n) {
            e[t] = [].concat(e[t] || []), e[t].unshift(n)
        }

        function h(e, t) {
            if (e) {
                const n = e.$options[t] || [];
                n.forEach(t => {
                    t.call(e)
                })
            }
        }

        function f(e, t) {
            return new CustomEvent(e, {
                bubbles: !1,
                cancelable: !1,
                detail: t
            })
        }
        const b = e => /function Boolean/.test(String(e)),
            g = e => /function Number/.test(String(e));

        function y(e, t, {
            type: n
        } = {}) {
            if (b(n)) return "true" === e || "false" === e ? "true" === e : "" === e || e === t || null != e ||
                e;
            if (g(n)) {
                const t = parseFloat(e, 10);
                return isNaN(t) ? e : t
            }
            return e
        }

        function w(e, t) {
            const n = [];
            for (let o = 0, r = t.length; o < r; o++) n.push(v(e, t[o]));
            return n
        }

        function v(e, t) {
            if (3 === t.nodeType) return t.data.trim() ? t.data : null;
            if (1 === t.nodeType) {
                const n = {
                    attrs: x(t),
                    domProps: {
                        innerHTML: t.innerHTML
                    }
                };
                return n.attrs.slot && (n.slot = n.attrs.slot, delete n.attrs.slot), e(t.tagName, n)
            }
            return null
        }

        function x(e) {
            const t = {};
            for (let n = 0, o = e.attributes.length; n < o; n++) {
                const o = e.attributes[n];
                t[o.nodeName] = o.nodeValue
            }
            return t
        }

        function k(e, t) {
            const n = "function" === typeof t && !t.cid;
            let o, r, i, a = !1;

            function s(e) {
                if (a) return;
                const t = "function" === typeof e ? e.options : e,
                    n = Array.isArray(t.props) ? t.props : Object.keys(t.props || {});
                o = n.map(m), r = n.map(l);
                const s = Array.isArray(t.props) ? {} : t.props || {};
                i = r.reduce((e, t, o) => (e[t] = s[n[o]], e), {}), d(t, "beforeCreate", (function () {
                    const e = this.$emit;
                    this.$emit = (t, ...n) => (this.$root.$options.customElement.dispatchEvent(f(t,
                        n)), e.call(this, t, ...n))
                })), d(t, "created", (function () {
                    r.forEach(e => {
                        this.$root.props[e] = this[e]
                    })
                })), r.forEach(e => {
                    Object.defineProperty(u.prototype, e, {
                        get() {
                            return this._wrapper.props[e]
                        },
                        set(t) {
                            this._wrapper.props[e] = t
                        },
                        enumerable: !1,
                        configurable: !0
                    })
                }), a = !0
            }

            function c(e, t) {
                const n = l(t),
                    o = e.hasAttribute(t) ? e.getAttribute(t) : void 0;
                e._wrapper.props[n] = y(o, t, i[n])
            }
            class u extends HTMLElement {
                constructor() {
                    const n = super();
                    n.attachShadow({
                        mode: "open"
                    });
                    const o = n._wrapper = new e({
                            name: "shadow-root",
                            customElement: n,
                            shadowRoot: n.shadowRoot,
                            data() {
                                return {
                                    props: {},
                                    slotChildren: []
                                }
                            },
                            render(e) {
                                return e(t, {
                                    ref: "inner",
                                    props: this.props
                                }, this.slotChildren)
                            }
                        }),
                        r = new MutationObserver(e => {
                            let t = !1;
                            for (let o = 0; o < e.length; o++) {
                                const r = e[o];
                                a && "attributes" === r.type && r.target === n ? c(n, r.attributeName) :
                                    t = !0
                            }
                            t && (o.slotChildren = Object.freeze(w(o.$createElement, n.childNodes)))
                        });
                    r.observe(n, {
                        childList: !0,
                        subtree: !0,
                        characterData: !0,
                        attributes: !0
                    })
                }
                get vueComponent() {
                    return this._wrapper.$refs.inner
                }
                connectedCallback() {
                    const e = this._wrapper;
                    if (e._isMounted) h(this.vueComponent, "activated");
                    else {
                        const n = () => {
                            e.props = p(r), o.forEach(e => {
                                c(this, e)
                            })
                        };
                        a ? n() : t().then(e => {
                                (e.__esModule || "Module" === e[Symbol.toStringTag]) && (e = e.default),
                                s(e), n()
                            }), e.slotChildren = Object.freeze(w(e.$createElement, this.childNodes)), e.$mount(),
                            this.shadowRoot.appendChild(e.$el)
                    }
                }
                disconnectedCallback() {
                    h(this.vueComponent, "deactivated")
                }
            }
            return n || s(t), u
        }
        var j = k,
            S = (n("24fb"), n("35d6"), n("2877")),
            _ = function () {
                var e = this,
                    t = e.$createElement,
                    n = e._self._c || t;
                return n("div", {
                    class: ["halo-comment", {
                        "halo-comment__small": "small" === e.mergedConfigs.size,
                        "halo-comment__admin": !0 === e.isAdmin
                    }],
                    attrs: {
                        id: "halo-comment"
                    }
                }, [e.isReply ? n("comment-editor", {
                    staticClass: "bottom-comment",
                    attrs: {
                        targetId: e.id,
                        target: e.target,
                        options: e.mergedOptions,
                        configs: e.mergedConfigs
                    },
                    on: {
                        checkIsAdmin: e.checkIsAdmin,
                        createdNewRootCommentNode: e.createdNewRootCommentNode
                    }
                }) : e._e(), e.mergedConfigs.autoLoad || e.loaded ? e._e() : n("div", {
                    staticClass: "comment-load-button"
                }, [n("a", {
                    staticClass: "button-load",
                    attrs: {
                        href: "javascript:void(0)",
                        rel: "nofollow noopener"
                    },
                    on: {
                        click: e.loadComments
                    }
                }, [e._v("加载评论")])]), n("comment-loading", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: e.commentLoading,
                        expression: "commentLoading"
                    }],
                    attrs: {
                        configs: e.mergedConfigs
                    }
                }), e.comments.length >= 1 ? n("ul", {
                    staticClass: "commentwrap"
                }, [e._l(e.comments, (function (t, o) {
                    return [n("CommentNode", {
                        key: o,
                        attrs: {
                            targetId: e.id,
                            target: e.target,
                            comment: t,
                            options: e.mergedOptions,
                            configs: e.mergedConfigs,
                            depth: 1
                        },
                        on: {
                            deletedRootCommenNode: e.deletedRootCommenNode,
                            createdNewRootCommentNode: e.createdNewRootCommentNode
                        }
                    })]
                }))], 2) : e._e(), e.loaded && !e.commentLoading && e.comments.length <= 0 ? n(
                    "div", {
                        staticClass: "comment-empty"
                    }, [e._v(" " + e._s(e.mergedConfigs.notComment || "还没有评论哦，快来抢占沙发 ♪(´▽｀)") + " ")]
                ) : e._e(), e.pagination.pages > 1 ? n("div", {
                    staticClass: "comment-page"
                }, [n("pagination", {
                    attrs: {
                        page: e.pagination.page,
                        size: e.pagination.size,
                        total: e.pagination.total
                    },
                    on: {
                        change: e.handlePaginationChange
                    }
                })], 1) : e._e()], 1)
            },
            A = [],
            C = (n("d9e2"), n("2af9"), {
                size: "normal",
                autoLoad: !0,
                showUserAgent: !0,
                gravatarType: "mm",
                gravatarSource: "https://sdn.geekzu.org/avatar",
                gravatarSourceDefault: "https://cn.gravatar.com/avatar",
                avatarError: "https://cdn.jsdelivr.net/gh/qiushaocloud/cdn-static@master/halo-comment/default_avatar.jpg",
                avatarLoading: "",
                loadingStyle: "default",
                aWord: "欢迎您，请点击此处，动动您的小手指，留下您的👣  ...",
                authorPopup: "输入QQ号将自动拉取昵称和头像 ♪(´▽｀)",
                emailPopup: "您的邮箱将收到回复通知 ๑乛◡乛๑",
                urlPopup: "请不要打小广告哦 (^し^)",
                notComment: "还没有评论哦，快来抢占沙发 ♪(´▽｀)",
                isAllowUploadAvatar: !1,
                isGetIpLocation: !0,
                blogAuthorEmail: "mask@176.com",
                blogAdminUserName: "mask"
            }),
            E = {
                blog_logo: "",
                gravatar_source: "",
                comment_gravatar_default: "mm"
            },
            O = n("063c"),
            z = n("0e4d"),
            P = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function (e) {
                return typeof e
            } : function (e) {
                return e && "function" === typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ?
                    "symbol" : typeof e
            },
            T = function (e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            },
            I = function () {
                function e(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var o = t[n];
                        o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !
                            0), Object.defineProperty(e, o.key, o)
                    }
                }
                return function (t, n, o) {
                    return n && e(t.prototype, n), o && e(t, o), t
                }
            }(),
            $ = function (e) {
                return null == e || "function" !== typeof e && "object" !== ("undefined" === typeof e ?
                    "undefined" : P(e))
            },
            R = function (e, t) {
                if (null === e || "undefined" === typeof e) throw new TypeError(
                    "expected first argument to be an object.");
                if ("undefined" === typeof t || "undefined" === typeof Symbol) return e;
                if ("function" !== typeof Object.getOwnPropertySymbols) return e;
                var n = Object.prototype.propertyIsEnumerable,
                    o = Object(e),
                    r = arguments.length,
                    i = 0;
                while (++i < r)
                    for (var a = Object(arguments[i]), s = Object.getOwnPropertySymbols(a), c = 0; c < s.length; c++) {
                        var l = s[c];
                        n.call(a, l) && (o[l] = a[l])
                    }
                return o
            },
            N = Object.prototype.toString,
            q = function (e) {
                var t = "undefined" === typeof e ? "undefined" : P(e);
                return "undefined" === t ? "undefined" : null === e ? "null" : !0 === e || !1 === e || e instanceof Boolean ?
                    "boolean" : "string" === t || e instanceof String ? "string" : "number" === t || e instanceof Number ?
                    "number" : "function" === t || e instanceof Function ? "undefined" !== typeof e.constructor
                    .name && "Generator" === e.constructor.name.slice(0, 9) ? "generatorfunction" : "function" :
                    "undefined" !== typeof Array.isArray && Array.isArray(e) ? "array" : e instanceof RegExp ?
                    "regexp" : e instanceof Date ? "date" : (t = N.call(e), "[object RegExp]" === t ? "regexp" :
                        "[object Date]" === t ? "date" : "[object Arguments]" === t ? "arguments" :
                        "[object Error]" === t ? "error" : "[object Promise]" === t ? "promise" : L(e) ?
                        "buffer" : "[object Set]" === t ? "set" : "[object WeakSet]" === t ? "weakset" :
                        "[object Map]" === t ? "map" : "[object WeakMap]" === t ? "weakmap" : "[object Symbol]" ===
                        t ? "symbol" : "[object Map Iterator]" === t ? "mapiterator" : "[object Set Iterator]" ===
                        t ? "setiterator" : "[object String Iterator]" === t ? "stringiterator" :
                        "[object Array Iterator]" === t ? "arrayiterator" : "[object Int8Array]" === t ?
                        "int8array" : "[object Uint8Array]" === t ? "uint8array" : "[object Uint8ClampedArray]" ===
                        t ? "uint8clampedarray" : "[object Int16Array]" === t ? "int16array" :
                        "[object Uint16Array]" === t ? "uint16array" : "[object Int32Array]" === t ?
                        "int32array" : "[object Uint32Array]" === t ? "uint32array" : "[object Float32Array]" ===
                        t ? "float32array" : "[object Float64Array]" === t ? "float64array" : "object")
            };

        function L(e) {
            return e.constructor && "function" === typeof e.constructor.isBuffer && e.constructor.isBuffer(e)
        }

        function U(e) {
            e = e || {};
            var t = arguments.length,
                n = 0;
            if (1 === t) return e;
            while (++n < t) {
                var o = arguments[n];
                $(e) && (e = o), B(o) && D(e, o)
            }
            return e
        }

        function D(e, t) {
            for (var n in R(e, t), t)
                if ("__proto__" !== n && M(t, n)) {
                    var o = t[n];
                    B(o) ? ("undefined" === q(e[n]) && "function" === q(o) && (e[n] = o), e[n] = U(e[n] || {},
                        o)) : e[n] = o
                } return e
        }

        function B(e) {
            return "object" === q(e) || "function" === q(e)
        }

        function M(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t)
        }
        var F = U,
            Y = "undefined" !== typeof window,
            H = W();

        function W() {
            return !!(Y && "IntersectionObserver" in window && "IntersectionObserverEntry" in window &&
                "intersectionRatio" in window.IntersectionObserverEntry.prototype) && ("isIntersecting" in
                window.IntersectionObserverEntry.prototype || Object.defineProperty(window.IntersectionObserverEntry
                    .prototype, "isIntersecting", {
                        get: function () {
                            return this.intersectionRatio > 0
                        }
                    }), !0)
        }
        var V = {
                event: "event",
                observer: "observer"
            },
            G = function () {
                if (Y) return "function" === typeof window.CustomEvent ? window.CustomEvent : (e.prototype =
                    window.Event.prototype, e);

                function e(e, t) {
                    t = t || {
                        bubbles: !1,
                        cancelable: !1,
                        detail: void 0
                    };
                    var n = document.createEvent("CustomEvent");
                    return n.initCustomEvent(e, t.bubbles, t.cancelable, t.detail), n
                }
            }();

        function Q(e, t) {
            if (e.length) {
                var n = e.indexOf(t);
                return n > -1 ? e.splice(n, 1) : void 0
            }
        }

        function J(e, t) {
            for (var n = !1, o = 0, r = e.length; o < r; o++)
                if (t(e[o])) {
                    n = !0;
                    break
                } return n
        }

        function Z(e, t) {
            if ("IMG" === e.tagName && e.getAttribute("data-srcset")) {
                var n = e.getAttribute("data-srcset"),
                    o = [],
                    r = e.parentNode,
                    i = r.offsetWidth * t,
                    a = void 0,
                    s = void 0,
                    c = void 0;
                n = n.trim().split(","), n.map((function (e) {
                    e = e.trim(), a = e.lastIndexOf(" "), -1 === a ? (s = e, c = 999998) : (s = e.substr(
                        0, a), c = parseInt(e.substr(a + 1, e.length - a - 2), 10)), o.push([c,
                        s])
                })), o.sort((function (e, t) {
                    if (e[0] < t[0]) return 1;
                    if (e[0] > t[0]) return -1;
                    if (e[0] === t[0]) {
                        if (-1 !== t[1].indexOf(".webp", t[1].length - 5)) return 1;
                        if (-1 !== e[1].indexOf(".webp", e[1].length - 5)) return -1
                    }
                    return 0
                }));
                for (var l = "", u = void 0, m = 0; m < o.length; m++) {
                    u = o[m], l = u[1];
                    var p = o[m + 1];
                    if (p && p[0] < i) {
                        l = u[1];
                        break
                    }
                    if (!p) {
                        l = u[1];
                        break
                    }
                }
                return l
            }
        }

        function X(e, t) {
            for (var n = void 0, o = 0, r = e.length; o < r; o++)
                if (t(e[o])) {
                    n = e[o];
                    break
                } return n
        }
        var K = function () {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
            return Y && window.devicePixelRatio || e
        };

        function ee() {
            if (!Y) return !1;
            var e = !0,
                t = document;
            try {
                var n = t.createElement("object");
                n.type = "image/webp", n.style.visibility = "hidden", n.innerHTML = "!", t.body.appendChild(n),
                    e = !n.offsetWidth, t.body.removeChild(n)
            } catch (o) {
                e = !1
            }
            return e
        }

        function te(e, t) {
            var n = null,
                o = 0;
            return function () {
                if (!n) {
                    var r = Date.now() - o,
                        i = this,
                        a = arguments,
                        s = function () {
                            o = Date.now(), n = !1, e.apply(i, a)
                        };
                    r >= t ? s() : n = setTimeout(s, t)
                }
            }
        }

        function ne() {
            if (Y) {
                var e = !1;
                try {
                    var t = Object.defineProperty({}, "passive", {
                        get: function () {
                            e = !0
                        }
                    });
                    window.addEventListener("test", null, t)
                } catch (n) {}
                return e
            }
        }
        var oe = ne(),
            re = {
                on: function (e, t, n) {
                    var o = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
                    oe ? e.addEventListener(t, n, {
                        capture: o,
                        passive: !0
                    }) : e.addEventListener(t, n, o)
                },
                off: function (e, t, n) {
                    var o = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
                    e.removeEventListener(t, n, o)
                }
            },
            ie = function (e, t, n) {
                var o = new Image;
                if (!e || !e.src) {
                    var r = new Error("image src is required");
                    return n(r)
                }
                o.src = e.src, o.onload = function () {
                    t({
                        naturalHeight: o.naturalHeight,
                        naturalWidth: o.naturalWidth,
                        src: o.src
                    })
                }, o.onerror = function (e) {
                    n(e)
                }
            },
            ae = function (e, t) {
                return "undefined" !== typeof getComputedStyle ? getComputedStyle(e, null).getPropertyValue(t) :
                    e.style[t]
            },
            se = function (e) {
                return ae(e, "overflow") + ae(e, "overflow-y") + ae(e, "overflow-x")
            },
            ce = function (e) {
                if (Y) {
                    if (!(e instanceof HTMLElement)) return window;
                    var t = e;
                    while (t) {
                        if (t === document.body || t === document.documentElement) break;
                        if (!t.parentNode) break;
                        if (/(scroll|auto)/.test(se(t))) return t;
                        t = t.parentNode
                    }
                    return window
                }
            };

        function le(e) {
            return null !== e && "object" === ("undefined" === typeof e ? "undefined" : P(e))
        }

        function ue(e) {
            if (!(e instanceof Object)) return [];
            if (Object.keys) return Object.keys(e);
            var t = [];
            for (var n in e) e.hasOwnProperty(n) && t.push(n);
            return t
        }

        function me(e) {
            for (var t = e.length, n = [], o = 0; o < t; o++) n.push(e[o]);
            return n
        }

        function pe() {}
        var de = function () {
                function e(t) {
                    var n = t.max;
                    T(this, e), this.options = {
                        max: n || 100
                    }, this._caches = []
                }
                return I(e, [{
                    key: "has",
                    value: function (e) {
                        return this._caches.indexOf(e) > -1
                    }
                }, {
                    key: "add",
                    value: function (e) {
                        this.has(e) || (this._caches.push(e), this._caches.length > this.options
                            .max && this.free())
                    }
                }, {
                    key: "free",
                    value: function () {
                        this._caches.shift()
                    }
                }]), e
            }(),
            he = function () {
                function e(t) {
                    var n = t.el,
                        o = t.src,
                        r = t.error,
                        i = t.loading,
                        a = t.bindType,
                        s = t.$parent,
                        c = t.options,
                        l = t.elRenderer,
                        u = t.imageCache;
                    T(this, e), this.el = n, this.src = o, this.error = r, this.loading = i, this.bindType = a,
                        this.attempt = 0, this.naturalHeight = 0, this.naturalWidth = 0, this.options = c, this
                        .rect = null, this.$parent = s, this.elRenderer = l, this._imageCache = u, this.performanceData = {
                            init: Date.now(),
                            loadStart: 0,
                            loadEnd: 0
                        }, this.filter(), this.initState(), this.render("loading", !1)
                }
                return I(e, [{
                    key: "initState",
                    value: function () {
                        "dataset" in this.el ? this.el.dataset.src = this.src : this.el.setAttribute(
                            "data-src", this.src), this.state = {
                            loading: !1,
                            error: !1,
                            loaded: !1,
                            rendered: !1
                        }
                    }
                }, {
                    key: "record",
                    value: function (e) {
                        this.performanceData[e] = Date.now()
                    }
                }, {
                    key: "update",
                    value: function (e) {
                        var t = e.src,
                            n = e.loading,
                            o = e.error,
                            r = this.src;
                        this.src = t, this.loading = n, this.error = o, this.filter(), r !==
                            this.src && (this.attempt = 0, this.initState())
                    }
                }, {
                    key: "getRect",
                    value: function () {
                        this.rect = this.el.getBoundingClientRect()
                    }
                }, {
                    key: "checkInView",
                    value: function () {
                        return this.getRect(), this.rect.top < window.innerHeight * this.options
                            .preLoad && this.rect.bottom > this.options.preLoadTop && this.rect
                            .left < window.innerWidth * this.options.preLoad && this.rect.right >
                            0
                    }
                }, {
                    key: "filter",
                    value: function () {
                        var e = this;
                        ue(this.options.filter).map((function (t) {
                            e.options.filter[t](e, e.options)
                        }))
                    }
                }, {
                    key: "renderLoading",
                    value: function (e) {
                        var t = this;
                        this.state.loading = !0, ie({
                            src: this.loading
                        }, (function (n) {
                            t.render("loading", !1), t.state.loading = !1, e()
                        }), (function () {
                            e(), t.state.loading = !1, t.options.silent || console.warn(
                                "VueLazyload log: load failed with loading image(" +
                                t.loading + ")")
                        }))
                    }
                }, {
                    key: "load",
                    value: function () {
                        var e = this,
                            t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] :
                            pe;
                        return this.attempt > this.options.attempt - 1 && this.state.error ? (
                                this.options.silent || console.log("VueLazyload log: " + this.src +
                                    " tried too more than " + this.options.attempt + " times"),
                                void t()) : this.state.rendered && this.state.loaded ? void 0 :
                            this._imageCache.has(this.src) ? (this.state.loaded = !0, this.render(
                                "loaded", !0), this.state.rendered = !0, t()) : void this.renderLoading(
                                (function () {
                                    e.attempt++, e.options.adapter["beforeLoad"] && e.options
                                        .adapter["beforeLoad"](e, e.options), e.record(
                                            "loadStart"), ie({
                                            src: e.src
                                        }, (function (n) {
                                            e.naturalHeight = n.naturalHeight, e.naturalWidth =
                                                n.naturalWidth, e.state.loaded = !0,
                                                e.state.error = !1, e.record(
                                                    "loadEnd"), e.render("loaded",
                                                    !1), e.state.rendered = !0, e._imageCache
                                                .add(e.src), t()
                                        }), (function (t) {
                                            !e.options.silent && console.error(t),
                                                e.state.error = !0, e.state.loaded = !
                                                1, e.render("error", !1)
                                        }))
                                }))
                    }
                }, {
                    key: "render",
                    value: function (e, t) {
                        this.elRenderer(this, e, t)
                    }
                }, {
                    key: "performance",
                    value: function () {
                        var e = "loading",
                            t = 0;
                        return this.state.loaded && (e = "loaded", t = (this.performanceData.loadEnd -
                            this.performanceData.loadStart) / 1e3), this.state.error && (e =
                            "error"), {
                            src: this.src,
                            state: e,
                            time: t
                        }
                    }
                }, {
                    key: "$destroy",
                    value: function () {
                        this.el = null, this.src = null, this.error = null, this.loading = null,
                            this.bindType = null, this.attempt = 0
                    }
                }]), e
            }(),
            fe = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7",
            be = ["scroll", "wheel", "mousewheel", "resize", "animationend", "transitionend", "touchmove"],
            ge = {
                rootMargin: "0px",
                threshold: 0
            },
            ye = function (e) {
                return function () {
                    function t(e) {
                        var n = e.preLoad,
                            o = e.error,
                            r = e.throttleWait,
                            i = e.preLoadTop,
                            a = e.dispatchEvent,
                            s = e.loading,
                            c = e.attempt,
                            l = e.silent,
                            u = void 0 === l || l,
                            m = e.scale,
                            p = e.listenEvents,
                            d = (e.hasbind, e.filter),
                            h = e.adapter,
                            f = e.observer,
                            b = e.observerOptions;
                        T(this, t), this.version = "1.3.3", this.mode = V.event, this.ListenerQueue = [],
                            this.TargetIndex = 0, this.TargetQueue = [], this.options = {
                                silent: u,
                                dispatchEvent: !!a,
                                throttleWait: r || 200,
                                preLoad: n || 1.3,
                                preLoadTop: i || 0,
                                error: o || fe,
                                loading: s || fe,
                                attempt: c || 3,
                                scale: m || K(m),
                                ListenEvents: p || be,
                                hasbind: !1,
                                supportWebp: ee(),
                                filter: d || {},
                                adapter: h || {},
                                observer: !!f,
                                observerOptions: b || ge
                            }, this._initEvent(), this._imageCache = new de({
                                max: 200
                            }), this.lazyLoadHandler = te(this._lazyLoadHandler.bind(this), this.options.throttleWait),
                            this.setMode(this.options.observer ? V.observer : V.event)
                    }
                    return I(t, [{
                        key: "config",
                        value: function () {
                            var e = arguments.length > 0 && void 0 !== arguments[0] ?
                                arguments[0] : {};
                            F(this.options, e)
                        }
                    }, {
                        key: "performance",
                        value: function () {
                            var e = [];
                            return this.ListenerQueue.map((function (t) {
                                e.push(t.performance())
                            })), e
                        }
                    }, {
                        key: "addLazyBox",
                        value: function (e) {
                            this.ListenerQueue.push(e), Y && (this._addListenerTarget(
                                window), this._observer && this._observer.observe(e
                                .el), e.$el && e.$el.parentNode && this._addListenerTarget(
                                e.$el.parentNode))
                        }
                    }, {
                        key: "add",
                        value: function (t, n, o) {
                            var r = this;
                            if (J(this.ListenerQueue, (function (e) {
                                    return e.el === t
                                }))) return this.update(t, n), e.nextTick(this.lazyLoadHandler);
                            var i = this._valueFormatter(n.value),
                                a = i.src,
                                s = i.loading,
                                c = i.error;
                            e.nextTick((function () {
                                a = Z(t, r.options.scale) || a, r._observer &&
                                    r._observer.observe(t);
                                var i = Object.keys(n.modifiers)[0],
                                    l = void 0;
                                i && (l = o.context.$refs[i], l = l ? l.$el ||
                                    l : document.getElementById(i)), l || (
                                    l = ce(t));
                                var u = new he({
                                    bindType: n.arg,
                                    $parent: l,
                                    el: t,
                                    loading: s,
                                    error: c,
                                    src: a,
                                    elRenderer: r._elRenderer.bind(r),
                                    options: r.options,
                                    imageCache: r._imageCache
                                });
                                r.ListenerQueue.push(u), Y && (r._addListenerTarget(
                                        window), r._addListenerTarget(l)), r.lazyLoadHandler(),
                                    e.nextTick((function () {
                                        return r.lazyLoadHandler()
                                    }))
                            }))
                        }
                    }, {
                        key: "update",
                        value: function (t, n, o) {
                            var r = this,
                                i = this._valueFormatter(n.value),
                                a = i.src,
                                s = i.loading,
                                c = i.error;
                            a = Z(t, this.options.scale) || a;
                            var l = X(this.ListenerQueue, (function (e) {
                                return e.el === t
                            }));
                            l ? l.update({
                                    src: a,
                                    loading: s,
                                    error: c
                                }) : this.add(t, n, o), this._observer && (this._observer.unobserve(
                                    t), this._observer.observe(t)), this.lazyLoadHandler(),
                                e.nextTick((function () {
                                    return r.lazyLoadHandler()
                                }))
                        }
                    }, {
                        key: "remove",
                        value: function (e) {
                            if (e) {
                                this._observer && this._observer.unobserve(e);
                                var t = X(this.ListenerQueue, (function (t) {
                                    return t.el === e
                                }));
                                t && (this._removeListenerTarget(t.$parent), this._removeListenerTarget(
                                    window), Q(this.ListenerQueue, t), t.$destroy())
                            }
                        }
                    }, {
                        key: "removeComponent",
                        value: function (e) {
                            e && (Q(this.ListenerQueue, e), this._observer && this._observer
                                .unobserve(e.el), e.$parent && e.$el.parentNode && this
                                ._removeListenerTarget(e.$el.parentNode), this._removeListenerTarget(
                                    window))
                        }
                    }, {
                        key: "setMode",
                        value: function (e) {
                            var t = this;
                            H || e !== V.observer || (e = V.event), this.mode = e, e === V.event ?
                                (this._observer && (this.ListenerQueue.forEach((function (e) {
                                    t._observer.unobserve(e.el)
                                })), this._observer = null), this.TargetQueue.forEach((
                                    function (e) {
                                        t._initListen(e.el, !0)
                                    }))) : (this.TargetQueue.forEach((function (e) {
                                    t._initListen(e.el, !1)
                                })), this._initIntersectionObserver())
                        }
                    }, {
                        key: "_addListenerTarget",
                        value: function (e) {
                            if (e) {
                                var t = X(this.TargetQueue, (function (t) {
                                    return t.el === e
                                }));
                                return t ? t.childrenCount++ : (t = {
                                    el: e,
                                    id: ++this.TargetIndex,
                                    childrenCount: 1,
                                    listened: !0
                                }, this.mode === V.event && this._initListen(t.el,
                                    !0), this.TargetQueue.push(t)), this.TargetIndex
                            }
                        }
                    }, {
                        key: "_removeListenerTarget",
                        value: function (e) {
                            var t = this;
                            this.TargetQueue.forEach((function (n, o) {
                                n.el === e && (n.childrenCount--, n.childrenCount ||
                                    (t._initListen(n.el, !1), t.TargetQueue
                                        .splice(o, 1), n = null))
                            }))
                        }
                    }, {
                        key: "_initListen",
                        value: function (e, t) {
                            var n = this;
                            this.options.ListenEvents.forEach((function (o) {
                                return re[t ? "on" : "off"](e, o, n.lazyLoadHandler)
                            }))
                        }
                    }, {
                        key: "_initEvent",
                        value: function () {
                            var e = this;
                            this.Event = {
                                listeners: {
                                    loading: [],
                                    loaded: [],
                                    error: []
                                }
                            }, this.$on = function (t, n) {
                                e.Event.listeners[t] || (e.Event.listeners[t] = []), e.Event
                                    .listeners[t].push(n)
                            }, this.$once = function (t, n) {
                                var o = e;

                                function r() {
                                    o.$off(t, r), n.apply(o, arguments)
                                }
                                e.$on(t, r)
                            }, this.$off = function (t, n) {
                                if (n) Q(e.Event.listeners[t], n);
                                else {
                                    if (!e.Event.listeners[t]) return;
                                    e.Event.listeners[t].length = 0
                                }
                            }, this.$emit = function (t, n, o) {
                                e.Event.listeners[t] && e.Event.listeners[t].forEach((
                                    function (e) {
                                        return e(n, o)
                                    }))
                            }
                        }
                    }, {
                        key: "_lazyLoadHandler",
                        value: function () {
                            var e = this,
                                t = [];
                            this.ListenerQueue.forEach((function (e, n) {
                                e.el && e.el.parentNode || t.push(e);
                                var o = e.checkInView();
                                o && e.load()
                            })), t.forEach((function (t) {
                                Q(e.ListenerQueue, t), t.$destroy()
                            }))
                        }
                    }, {
                        key: "_initIntersectionObserver",
                        value: function () {
                            var e = this;
                            H && (this._observer = new IntersectionObserver(this._observerHandler
                                    .bind(this), this.options.observerOptions), this.ListenerQueue
                                .length && this.ListenerQueue.forEach((function (t) {
                                    e._observer.observe(t.el)
                                })))
                        }
                    }, {
                        key: "_observerHandler",
                        value: function (e, t) {
                            var n = this;
                            e.forEach((function (e) {
                                e.isIntersecting && n.ListenerQueue.forEach((
                                    function (t) {
                                        if (t.el === e.target) {
                                            if (t.state.loaded) return n
                                                ._observer.unobserve(
                                                    t.el);
                                            t.load()
                                        }
                                    }))
                            }))
                        }
                    }, {
                        key: "_elRenderer",
                        value: function (e, t, n) {
                            if (e.el) {
                                var o = e.el,
                                    r = e.bindType,
                                    i = void 0;
                                switch (t) {
                                    case "loading":
                                        i = e.loading;
                                        break;
                                    case "error":
                                        i = e.error;
                                        break;
                                    default:
                                        i = e.src;
                                        break
                                }
                                if (r ? o.style[r] = 'url("' + i + '")' : o.getAttribute(
                                        "src") !== i && o.setAttribute("src", i), o.setAttribute(
                                        "lazy", t), this.$emit(t, e, n), this.options.adapter[
                                        t] && this.options.adapter[t](e, this.options),
                                    this.options.dispatchEvent) {
                                    var a = new G(t, {
                                        detail: e
                                    });
                                    o.dispatchEvent(a)
                                }
                            }
                        }
                    }, {
                        key: "_valueFormatter",
                        value: function (e) {
                            var t = e,
                                n = this.options.loading,
                                o = this.options.error;
                            return le(e) && (e.src || this.options.silent || console.error(
                                    "Vue Lazyload warning: miss src with " + e), t = e.src,
                                n = e.loading || this.options.loading, o = e.error ||
                                this.options.error), {
                                src: t,
                                loading: n,
                                error: o
                            }
                        }
                    }]), t
                }()
            },
            we = function (e) {
                return {
                    props: {
                        tag: {
                            type: String,
                            default: "div"
                        }
                    },
                    render: function (e) {
                        return !1 === this.show ? e(this.tag) : e(this.tag, null, this.$slots.default)
                    },
                    data: function () {
                        return {
                            el: null,
                            state: {
                                loaded: !1
                            },
                            rect: {},
                            show: !1
                        }
                    },
                    mounted: function () {
                        this.el = this.$el, e.addLazyBox(this), e.lazyLoadHandler()
                    },
                    beforeDestroy: function () {
                        e.removeComponent(this)
                    },
                    methods: {
                        getRect: function () {
                            this.rect = this.$el.getBoundingClientRect()
                        },
                        checkInView: function () {
                            return this.getRect(), Y && this.rect.top < window.innerHeight * e.options.preLoad &&
                                this.rect.bottom > 0 && this.rect.left < window.innerWidth * e.options.preLoad &&
                                this.rect.right > 0
                        },
                        load: function () {
                            this.show = !0, this.state.loaded = !0, this.$emit("show", this)
                        },
                        destroy: function () {
                            return this.$destroy
                        }
                    }
                }
            },
            ve = function () {
                function e(t) {
                    var n = t.lazy;
                    T(this, e), this.lazy = n, n.lazyContainerMananger = this, this._queue = []
                }
                return I(e, [{
                    key: "bind",
                    value: function (e, t, n) {
                        var o = new ke({
                            el: e,
                            binding: t,
                            vnode: n,
                            lazy: this.lazy
                        });
                        this._queue.push(o)
                    }
                }, {
                    key: "update",
                    value: function (e, t, n) {
                        var o = X(this._queue, (function (t) {
                            return t.el === e
                        }));
                        o && o.update({
                            el: e,
                            binding: t,
                            vnode: n
                        })
                    }
                }, {
                    key: "unbind",
                    value: function (e, t, n) {
                        var o = X(this._queue, (function (t) {
                            return t.el === e
                        }));
                        o && (o.clear(), Q(this._queue, o))
                    }
                }]), e
            }(),
            xe = {
                selector: "img"
            },
            ke = function () {
                function e(t) {
                    var n = t.el,
                        o = t.binding,
                        r = t.vnode,
                        i = t.lazy;
                    T(this, e), this.el = null, this.vnode = r, this.binding = o, this.options = {}, this.lazy =
                        i, this._queue = [], this.update({
                            el: n,
                            binding: o
                        })
                }
                return I(e, [{
                    key: "update",
                    value: function (e) {
                        var t = this,
                            n = e.el,
                            o = e.binding;
                        this.el = n, this.options = F({}, xe, o.value);
                        var r = this.getImgs();
                        r.forEach((function (e) {
                            t.lazy.add(e, F({}, t.binding, {
                                value: {
                                    src: "dataset" in e ? e.dataset.src :
                                        e.getAttribute("data-src"),
                                    error: ("dataset" in e ? e.dataset.error :
                                        e.getAttribute("data-error")
                                    ) || t.options.error,
                                    loading: ("dataset" in e ? e.dataset
                                            .loading : e.getAttribute(
                                                "data-loading")) || t.options
                                        .loading
                                }
                            }), t.vnode)
                        }))
                    }
                }, {
                    key: "getImgs",
                    value: function () {
                        return me(this.el.querySelectorAll(this.options.selector))
                    }
                }, {
                    key: "clear",
                    value: function () {
                        var e = this,
                            t = this.getImgs();
                        t.forEach((function (t) {
                            return e.lazy.remove(t)
                        })), this.vnode = null, this.binding = null, this.lazy = null
                    }
                }]), e
            }(),
            je = function (e) {
                return {
                    props: {
                        src: [String, Object],
                        tag: {
                            type: String,
                            default: "img"
                        }
                    },
                    render: function (e) {
                        return e(this.tag, {
                            attrs: {
                                src: this.renderSrc
                            }
                        }, this.$slots.default)
                    },
                    data: function () {
                        return {
                            el: null,
                            options: {
                                src: "",
                                error: "",
                                loading: "",
                                attempt: e.options.attempt
                            },
                            state: {
                                loaded: !1,
                                error: !1,
                                attempt: 0
                            },
                            rect: {},
                            renderSrc: ""
                        }
                    },
                    watch: {
                        src: function () {
                            this.init(), e.addLazyBox(this), e.lazyLoadHandler()
                        }
                    },
                    created: function () {
                        this.init(), this.renderSrc = this.options.loading
                    },
                    mounted: function () {
                        this.el = this.$el, e.addLazyBox(this), e.lazyLoadHandler()
                    },
                    beforeDestroy: function () {
                        e.removeComponent(this)
                    },
                    methods: {
                        init: function () {
                            var t = e._valueFormatter(this.src),
                                n = t.src,
                                o = t.loading,
                                r = t.error;
                            this.state.loaded = !1, this.options.src = n, this.options.error = r, this.options
                                .loading = o, this.renderSrc = this.options.loading
                        },
                        getRect: function () {
                            this.rect = this.$el.getBoundingClientRect()
                        },
                        checkInView: function () {
                            return this.getRect(), Y && this.rect.top < window.innerHeight * e.options.preLoad &&
                                this.rect.bottom > 0 && this.rect.left < window.innerWidth * e.options.preLoad &&
                                this.rect.right > 0
                        },
                        load: function () {
                            var t = this,
                                n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : pe;
                            if (this.state.attempt > this.options.attempt - 1 && this.state.error) return e
                                .options.silent || console.log("VueLazyload log: " + this.options.src +
                                    " tried too more than " + this.options.attempt + " times"), void n();
                            var o = this.options.src;
                            ie({
                                src: o
                            }, (function (e) {
                                var n = e.src;
                                t.renderSrc = n, t.state.loaded = !0
                            }), (function (e) {
                                t.state.attempt++, t.renderSrc = t.options.error, t.state.error = !
                                    0
                            }))
                        }
                    }
                }
            },
            Se = {
                install: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        n = ye(e),
                        o = new n(t),
                        r = new ve({
                            lazy: o
                        }),
                        i = "2" === e.version.split(".")[0];
                    e.prototype.$Lazyload = o, t.lazyComponent && e.component("lazy-component", we(o)), t.lazyImage &&
                        e.component("lazy-image", je(o)), i ? (e.directive("lazy", {
                            bind: o.add.bind(o),
                            update: o.update.bind(o),
                            componentUpdated: o.lazyLoadHandler.bind(o),
                            unbind: o.remove.bind(o)
                        }), e.directive("lazy-container", {
                            bind: r.bind.bind(r),
                            componentUpdated: r.update.bind(r),
                            unbind: r.unbind.bind(r)
                        })) : (e.directive("lazy", {
                            bind: o.lazyLoadHandler.bind(o),
                            update: function (e, t) {
                                F(this.vm.$refs, this.vm.$els), o.add(this.el, {
                                    modifiers: this.modifiers || {},
                                    arg: this.arg,
                                    value: e,
                                    oldValue: t
                                }, {
                                    context: this.vm
                                })
                            },
                            unbind: function () {
                                o.remove(this.el)
                            }
                        }), e.directive("lazy-container", {
                            update: function (e, t) {
                                r.update(this.el, {
                                    modifiers: this.modifiers || {},
                                    arg: this.arg,
                                    value: e,
                                    oldValue: t
                                }, {
                                    context: this.vm
                                })
                            },
                            unbind: function () {
                                r.unbind(this.el)
                            }
                        }))
                }
            },
            _e = Se,
            Ae = function () {
                var e = this,
                    t = e.$createElement,
                    n = e._self._c || t;
                return n("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: e.show,
                        expression: "show"
                    }],
                    staticClass: "butterBar butterBar-center"
                }, [n("p", {
                    staticClass: "butterBar-message",
                    domProps: {
                        innerHTML: e._s(e.message)
                    }
                })])
            },
            Ce = [],
            Ee = {
                name: "tips",
                props: {
                    message: {
                        type: String,
                        default: ""
                    }
                },
                data() {
                    return {
                        show: !1
                    }
                }
            },
            Oe = Ee,
            ze = Object(S["a"])(Oe, Ae, Ce, !1, null, null, null, !0),
            Pe = ze.exports;
        let Te, Ie = s.a.extend(Pe),
            $e = null;
        const Re = (e, t = 6e3, n) => {
                if (!Te) {
                    Te = new Ie, Te.vm = Te.$mount();
                    var o = n.$root.$el;
                    o.appendChild(Te.vm.$el)
                }
                $e && (clearTimeout($e), $e = null, Te.show = !1, Te.message = ""), Te.time = 3e3, "string" ===
                    typeof e && (Te.message = e, "number" === typeof t && (Te.time = t), Te.show = !0, $e =
                        setTimeout(() => {
                            Te.show = !1, clearTimeout($e), $e = null, Te.message = ""
                        }, Te.time))
            },
            Ne = e => {
                if (!Te) {
                    Te = new Ie, Te.vm = Te.$mount();
                    var t = e.$root.$el;
                    t.appendChild(Te.vm.$el)
                }
            };
        Re.install = e => {
            e.prototype.$tips = Re, e.prototype.$tipsInitInstance = Ne
        };
        var qe = Re,
            Le = n("ca00");
        s.a.use(qe);
        var Ue = {
                name: "Comment",
                props: {
                    id: {
                        type: Number,
                        required: !1,
                        default: 0
                    },
                    type: {
                        type: String,
                        required: !1,
                        default: "post",
                        validator: function (e) {
                            return -1 !== ["post", "sheet", "journal", "links"].indexOf(e)
                        }
                    },
                    configs: {
                        type: Object,
                        required: !1,
                        default: () => C
                    },
                    options: {
                        type: Object,
                        required: !1,
                        default: () => E
                    }
                },
                data() {
                    return {
                        comments: [],
                        pagination: {
                            pages: 0,
                            page: 0,
                            sort: "",
                            size: 5,
                            total: 0
                        },
                        commentLoading: !1,
                        loaded: !1,
                        repliedSuccess: null,
                        replyingComment: null,
                        globalData: z["a"],
                        showImgPreviewer: !1,
                        previewImgUrl: "",
                        isAdmin: !1
                    }
                },
                computed: {
                    target() {
                        return this.type + "s"
                    },
                    mergedConfigs() {
                        var e;
                        if ("string" === typeof this.configs) {
                            const t = JSON.parse(this.configs),
                                n = {};
                            for (const e in t) {
                                const o = t[e];
                                n[e] = /^(true|false)$/.test(o) ? JSON.parse(o) : o
                            }
                            e = n
                        } else {
                            if ("object" !== typeof this.configs) throw new TypeError("config参数类型错误");
                            e = this.configs
                        }
                        return Object(Le["g"])(e), Object.assign(C, e)
                    },
                    mergedOptions() {
                        var e;
                        if ("string" === typeof this.options) {
                            const t = JSON.parse(this.options),
                                n = {};
                            for (const e in t) {
                                const o = t[e];
                                n[e] = /^(true|false)$/.test(o) ? JSON.parse(o) : o
                            }
                            e = n
                        } else {
                            if ("object" !== typeof this.options) throw new TypeError("options参数类型错误");
                            e = this.options
                        }
                        return Object(Le["g"])(e), Object.assign(E, e)
                    },
                    isReply() {
                        return 0 == this.globalData.replyId
                    }
                },
                beforeMount() {
                    this.$nextTick(() => {
                        s.a.use(_e, {
                            error: this.mergedConfigs.avatarError ||
                                "https://cdn.jsdelivr.net/gh/qiushaocloud/cdn-static@master/halo-comment/default_avatar.jpg",
                            loading: this.mergedConfigs.avatarLoading ||
                                "https://cdn.jsdelivr.net/gh/qiushaocloud/cdn-static@master/halo-comment/spinner-preloader.svg",
                            attempt: 1
                        })
                    }), this.mergedConfigs.autoLoad && this.loadComments(), this.checkIsAdmin()
                },
                methods: {
                    loadComments() {
                        this.comments = [], this.commentLoading = !0, O["a"].listComments(this.target, this.id,
                            "tree_view", this.pagination).then(e => {
                            this.comments = e.data.data.content, this.pagination.size = e.data.data.rpp,
                                this.pagination.total = e.data.data.total, this.pagination.pages = e.data
                                .data.pages
                        }).finally(() => {
                            this.commentLoading = !1, this.loaded = !0
                        })
                    },
                    async handlePaginationChange(e) {
                        this.pagination.page = e, await Object(Le["i"])(300), this.loadComments()
                    },
                    checkIsAdmin() {
                        if (!this.mergedConfigs.blogAuthorEmail) return;
                        const e = this.isAdmin,
                            t = localStorage.getItem("qiushaocloud-halo-comment-email"),
                            n = this.mergedConfigs.blogAuthorEmail === t;
                        e !== n && (this.isAdmin = n)
                    },
                    deletedRootCommenNode(e) {
                        console.log("deletedRootCommenNode commentId:", e);
                        for (let t = this.comments.length - 1; t >= 0; t--) {
                            const n = this.comments[t];
                            if (n.id === e) {
                                this.comments.splice(t, 1);
                                break
                            }
                        }
                    },
                    createdNewRootCommentNode(e) {
                        console.log("createdNewRootCommentNode createdComment:", e), 0 === e.parentId && this.comments
                            .unshift(e)
                    },
                    _findCommentById(e) {
                        for (const t of this.comments) {
                            const n = this._findCommentByIdStep(t, e);
                            if (n) return n
                        }
                    },
                    _findCommentByIdStep(e, t) {
                        if (e.id === t) return e;
                        if (e.children)
                            for (const n of e.children) {
                                const e = this._findCommentByIdStep(n, t);
                                if (e) return e
                            }
                    }
                }
            },
            De = Ue;

        function Be(e) {
            var t = n("a85a");
            t.__inject__ && t.__inject__(e)
        }
        var Me = Object(S["a"])(De, _, A, !1, Be, null, null, !0),
            Fe = Me.exports;
        window.customElements.define("halo-comment", j(s.a, Fe))
    },
    "5c6c": function (e, t) {
        e.exports = function (e, t) {
            return {
                enumerable: !(1 & e),
                configurable: !(2 & e),
                writable: !(4 & e),
                value: t
            }
        }
    },
    "5e77": function (e, t, n) {
        var o = n("83ab"),
            r = n("1a2d"),
            i = Function.prototype,
            a = o && Object.getOwnPropertyDescriptor,
            s = r(i, "name"),
            c = s && "something" === function () {}.name,
            l = s && (!o || o && a(i, "name").configurable);
        e.exports = {
            EXISTS: s,
            PROPER: c,
            CONFIGURABLE: l
        }
    },
    "5f02": function (e, t, n) {
        "use strict";
        e.exports = function (e) {
            return "object" === typeof e && !0 === e.isAxiosError
        }
    },
    6715: function (e, t, n) {
        "use strict";
        var o = n("a0d3"),
            r = n("c46d"),
            i = n("b398");
        e.exports = function (e) {
            return "undefined" !== typeof e && (r(i, "Property Descriptor", "Desc", e), !(!o(e, "[[Get]]") &&
                !o(e, "[[Set]]")))
        }
    },
    6821: function (e, t, n) {
        (function () {
            var t = n("00d8"),
                o = n("9a63").utf8,
                r = n("044b"),
                i = n("9a63").bin,
                a = function (e, n) {
                    e.constructor == String ? e = n && "binary" === n.encoding ? i.stringToBytes(e) : o.stringToBytes(
                            e) : r(e) ? e = Array.prototype.slice.call(e, 0) : Array.isArray(e) || e.constructor ===
                        Uint8Array || (e = e.toString());
                    for (var s = t.bytesToWords(e), c = 8 * e.length, l = 1732584193, u = -271733879, m = -
                            1732584194, p = 271733878, d = 0; d < s.length; d++) s[d] = 16711935 & (s[d] <<
                        8 | s[d] >>> 24) | 4278255360 & (s[d] << 24 | s[d] >>> 8);
                    s[c >>> 5] |= 128 << c % 32, s[14 + (c + 64 >>> 9 << 4)] = c;
                    var h = a._ff,
                        f = a._gg,
                        b = a._hh,
                        g = a._ii;
                    for (d = 0; d < s.length; d += 16) {
                        var y = l,
                            w = u,
                            v = m,
                            x = p;
                        l = h(l, u, m, p, s[d + 0], 7, -680876936), p = h(p, l, u, m, s[d + 1], 12, -
                                389564586), m = h(m, p, l, u, s[d + 2], 17, 606105819), u = h(u, m, p, l, s[
                                d + 3], 22, -1044525330), l = h(l, u, m, p, s[d + 4], 7, -176418897), p = h(
                                p, l, u, m, s[d + 5], 12, 1200080426), m = h(m, p, l, u, s[d + 6], 17, -
                                1473231341), u = h(u, m, p, l, s[d + 7], 22, -45705983), l = h(l, u, m, p,
                                s[d + 8], 7, 1770035416), p = h(p, l, u, m, s[d + 9], 12, -1958414417), m =
                            h(m, p, l, u, s[d + 10], 17, -42063), u = h(u, m, p, l, s[d + 11], 22, -
                                1990404162), l = h(l, u, m, p, s[d + 12], 7, 1804603682), p = h(p, l, u, m,
                                s[d + 13], 12, -40341101), m = h(m, p, l, u, s[d + 14], 17, -1502002290), u =
                            h(u, m, p, l, s[d + 15], 22, 1236535329), l = f(l, u, m, p, s[d + 1], 5, -
                                165796510), p = f(p, l, u, m, s[d + 6], 9, -1069501632), m = f(m, p, l, u,
                                s[d + 11], 14, 643717713), u = f(u, m, p, l, s[d + 0], 20, -373897302), l =
                            f(l, u, m, p, s[d + 5], 5, -701558691), p = f(p, l, u, m, s[d + 10], 9,
                                38016083), m = f(m, p, l, u, s[d + 15], 14, -660478335), u = f(u, m, p, l,
                                s[d + 4], 20, -405537848), l = f(l, u, m, p, s[d + 9], 5, 568446438), p = f(
                                p, l, u, m, s[d + 14], 9, -1019803690), m = f(m, p, l, u, s[d + 3], 14, -
                                187363961), u = f(u, m, p, l, s[d + 8], 20, 1163531501), l = f(l, u, m, p,
                                s[d + 13], 5, -1444681467), p = f(p, l, u, m, s[d + 2], 9, -51403784), m =
                            f(m, p, l, u, s[d + 7], 14, 1735328473), u = f(u, m, p, l, s[d + 12], 20, -
                                1926607734), l = b(l, u, m, p, s[d + 5], 4, -378558), p = b(p, l, u, m, s[d +
                                8], 11, -2022574463), m = b(m, p, l, u, s[d + 11], 16, 1839030562), u = b(u,
                                m, p, l, s[d + 14], 23, -35309556), l = b(l, u, m, p, s[d + 1], 4, -
                                1530992060), p = b(p, l, u, m, s[d + 4], 11, 1272893353), m = b(m, p, l, u,
                                s[d + 7], 16, -155497632), u = b(u, m, p, l, s[d + 10], 23, -1094730640), l =
                            b(l, u, m, p, s[d + 13], 4, 681279174), p = b(p, l, u, m, s[d + 0], 11, -
                                358537222), m = b(m, p, l, u, s[d + 3], 16, -722521979), u = b(u, m, p, l,
                                s[d + 6], 23, 76029189), l = b(l, u, m, p, s[d + 9], 4, -640364487), p = b(
                                p, l, u, m, s[d + 12], 11, -421815835), m = b(m, p, l, u, s[d + 15], 16,
                                530742520), u = b(u, m, p, l, s[d + 2], 23, -995338651), l = g(l, u, m, p,
                                s[d + 0], 6, -198630844), p = g(p, l, u, m, s[d + 7], 10, 1126891415), m =
                            g(m, p, l, u, s[d + 14], 15, -1416354905), u = g(u, m, p, l, s[d + 5], 21, -
                                57434055), l = g(l, u, m, p, s[d + 12], 6, 1700485571), p = g(p, l, u, m, s[
                                d + 3], 10, -1894986606), m = g(m, p, l, u, s[d + 10], 15, -1051523), u = g(
                                u, m, p, l, s[d + 1], 21, -2054922799), l = g(l, u, m, p, s[d + 8], 6,
                                1873313359), p = g(p, l, u, m, s[d + 15], 10, -30611744), m = g(m, p, l, u,
                                s[d + 6], 15, -1560198380), u = g(u, m, p, l, s[d + 13], 21, 1309151649), l =
                            g(l, u, m, p, s[d + 4], 6, -145523070), p = g(p, l, u, m, s[d + 11], 10, -
                                1120210379), m = g(m, p, l, u, s[d + 2], 15, 718787259), u = g(u, m, p, l,
                                s[d + 9], 21, -343485551), l = l + y >>> 0, u = u + w >>> 0, m = m + v >>>
                            0, p = p + x >>> 0
                    }
                    return t.endian([l, u, m, p])
                };
            a._ff = function (e, t, n, o, r, i, a) {
                var s = e + (t & n | ~t & o) + (r >>> 0) + a;
                return (s << i | s >>> 32 - i) + t
            }, a._gg = function (e, t, n, o, r, i, a) {
                var s = e + (t & o | n & ~o) + (r >>> 0) + a;
                return (s << i | s >>> 32 - i) + t
            }, a._hh = function (e, t, n, o, r, i, a) {
                var s = e + (t ^ n ^ o) + (r >>> 0) + a;
                return (s << i | s >>> 32 - i) + t
            }, a._ii = function (e, t, n, o, r, i, a) {
                var s = e + (n ^ (t | ~o)) + (r >>> 0) + a;
                return (s << i | s >>> 32 - i) + t
            }, a._blocksize = 16, a._digestsize = 16, e.exports = function (e, n) {
                if (void 0 === e || null === e) throw new Error("Illegal argument " + e);
                var o = t.wordsToBytes(a(e, n));
                return n && n.asBytes ? o : n && n.asString ? i.bytesToString(o) : t.bytesToHex(o)
            }
        })()
    },
    "688e": function (e, t, n) {
        "use strict";
        var o = "Function.prototype.bind called on incompatible ",
            r = Array.prototype.slice,
            i = Object.prototype.toString,
            a = "[object Function]";
        e.exports = function (e) {
            var t = this;
            if ("function" !== typeof t || i.call(t) !== a) throw new TypeError(o + t);
            for (var n, s = r.call(arguments, 1), c = function () {
                    if (this instanceof n) {
                        var o = t.apply(this, s.concat(r.call(arguments)));
                        return Object(o) === o ? o : this
                    }
                    return t.apply(e, s.concat(r.call(arguments)))
                }, l = Math.max(0, t.length - s.length), u = [], m = 0; m < l; m++) u.push("$" + m);
            if (n = Function("binder", "return function (" + u.join(",") +
                    "){ return binder.apply(this,arguments); }")(c), t.prototype) {
                var p = function () {};
                p.prototype = t.prototype, n.prototype = new p, p.prototype = null
            }
            return n
        }
    },
    "69f3": function (e, t, n) {
        var o, r, i, a = n("7f9a"),
            s = n("da84"),
            c = n("e330"),
            l = n("861d"),
            u = n("9112"),
            m = n("1a2d"),
            p = n("c6cd"),
            d = n("f772"),
            h = n("d012"),
            f = "Object already initialized",
            b = s.TypeError,
            g = s.WeakMap,
            y = function (e) {
                return i(e) ? r(e) : o(e, {})
            },
            w = function (e) {
                return function (t) {
                    var n;
                    if (!l(t) || (n = r(t)).type !== e) throw b("Incompatible receiver, " + e + " required");
                    return n
                }
            };
        if (a || p.state) {
            var v = p.state || (p.state = new g),
                x = c(v.get),
                k = c(v.has),
                j = c(v.set);
            o = function (e, t) {
                if (k(v, e)) throw new b(f);
                return t.facade = e, j(v, e, t), t
            }, r = function (e) {
                return x(v, e) || {}
            }, i = function (e) {
                return k(v, e)
            }
        } else {
            var S = d("state");
            h[S] = !0, o = function (e, t) {
                if (m(e, S)) throw new b(f);
                return t.facade = e, u(e, S, t), t
            }, r = function (e) {
                return m(e, S) ? e[S] : {}
            }, i = function (e) {
                return m(e, S)
            }
        }
        e.exports = {
            set: o,
            get: r,
            has: i,
            enforce: y,
            getterFor: w
        }
    },
    "6eeb": function (e, t, n) {
        var o = n("da84"),
            r = n("1626"),
            i = n("1a2d"),
            a = n("9112"),
            s = n("ce4e"),
            c = n("8925"),
            l = n("69f3"),
            u = n("5e77").CONFIGURABLE,
            m = l.get,
            p = l.enforce,
            d = String(String).split("String");
        (e.exports = function (e, t, n, c) {
            var l, m = !!c && !!c.unsafe,
                h = !!c && !!c.enumerable,
                f = !!c && !!c.noTargetGet,
                b = c && void 0 !== c.name ? c.name : t;
            r(n) && ("Symbol(" === String(b).slice(0, 7) && (b = "[" + String(b).replace(
                    /^Symbol\(([^)]*)\)/, "$1") + "]"), (!i(n, "name") || u && n.name !== b) && a(n,
                    "name", b), l = p(n), l.source || (l.source = d.join("string" == typeof b ? b : ""))),
                e !== o ? (m ? !f && e[t] && (h = !0) : delete e[t], h ? e[t] = n : a(e, t, n)) : h ? e[t] =
                n : s(t, n)
        })(Function.prototype, "toString", (function () {
            return r(this) && m(this).source || c(this)
        }))
    },
    7049: function (e, t, n) {
        "use strict";
        var o = n("c46d"),
            r = n("b398");
        e.exports = function (e) {
            if ("undefined" === typeof e) return e;
            o(r, "Property Descriptor", "Desc", e);
            var t = {};
            return "[[Value]]" in e && (t.value = e["[[Value]]"]), "[[Writable]]" in e && (t.writable = e[
                    "[[Writable]]"]), "[[Get]]" in e && (t.get = e["[[Get]]"]), "[[Set]]" in e && (t.set =
                    e["[[Set]]"]), "[[Enumerable]]" in e && (t.enumerable = e["[[Enumerable]]"]),
                "[[Configurable]]" in e && (t.configurable = e["[[Configurable]]"]), t
        }
    },
    "706f": function (e, t, n) {
        "use strict";
        e.exports = function (e) {
            return "string" === typeof e || "symbol" === typeof e
        }
    },
    7156: function (e, t, n) {
        var o = n("1626"),
            r = n("861d"),
            i = n("d2bb");
        e.exports = function (e, t, n) {
            var a, s;
            return i && o(a = t.constructor) && a !== n && r(s = a.prototype) && s !== n.prototype && i(e,
                s), e
        }
    },
    7418: function (e, t) {
        t.f = Object.getOwnPropertySymbols
    },
    7839: function (e, t) {
        e.exports = ["constructor", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "toLocaleString",
            "toString", "valueOf"]
    },
    "791b": function (e, t, n) {
        var o = n("e64f");
        o.__esModule && (o = o.default), "string" === typeof o && (o = [[e.i, o, ""]]), o.locals && (e.exports =
            o.locals);
        var r = n("35d6").default;
        e.exports.__inject__ = function (e) {
            r("52c8283e", o, e)
        }
    },
    "7a77": function (e, t, n) {
        "use strict";

        function o(e) {
            this.message = e
        }
        o.prototype.toString = function () {
            return "Cancel" + (this.message ? ": " + this.message : "")
        }, o.prototype.__CANCEL__ = !0, e.exports = o
    },
    "7aac": function (e, t, n) {
        "use strict";
        var o = n("c532");
        e.exports = o.isStandardBrowserEnv() ? function () {
            return {
                write: function (e, t, n, r, i, a) {
                    var s = [];
                    s.push(e + "=" + encodeURIComponent(t)), o.isNumber(n) && s.push("expires=" + new Date(
                            n).toGMTString()), o.isString(r) && s.push("path=" + r), o.isString(i) && s
                        .push("domain=" + i), !0 === a && s.push("secure"), document.cookie = s.join(
                            "; ")
                },
                read: function (e) {
                    var t = document.cookie.match(new RegExp("(^|;\\s*)(" + e + ")=([^;]*)"));
                    return t ? decodeURIComponent(t[3]) : null
                },
                remove: function (e) {
                    this.write(e, "", Date.now() - 864e5)
                }
            }
        }() : function () {
            return {
                write: function () {},
                read: function () {
                    return null
                },
                remove: function () {}
            }
        }()
    },
    "7b0b": function (e, t, n) {
        var o = n("da84"),
            r = n("1d80"),
            i = o.Object;
        e.exports = function (e) {
            return i(r(e))
        }
    },
    "7b13": function (e, t, n) {
        "use strict";
        var o = n("be77");
        o();
        var r = n("2054"),
            i = n("95a0"),
            a = n("b398"),
            s = function (e, t) {
                return new e((function (e) {
                    e(t)
                }))
            },
            c = Promise,
            l = function (e, t) {
                return function (n) {
                    var o = t(),
                        r = s(e, o),
                        i = function () {
                            return n
                        };
                    return r.then(i)
                }
            },
            u = function (e, t) {
                return function (n) {
                    var o = t(),
                        r = s(e, o),
                        i = function () {
                            throw n
                        };
                    return r.then(i)
                }
            },
            m = function (e) {
                var t = this;
                if ("Object" !== a(t)) throw new TypeError("receiver is not an Object");
                var n = i(t, c),
                    o = e,
                    s = e;
                return r(e) && (o = l(n, e), s = u(n, e)), t.then(o, s)
            };
        if (Object.getOwnPropertyDescriptor) {
            var p = Object.getOwnPropertyDescriptor(m, "name");
            p && p.configurable && Object.defineProperty(m, "name", {
                configurable: !0,
                value: "finally"
            })
        }
        e.exports = m
    },
    "7d36": function (e, t, n) {
        "use strict";
        var o = n("2057");
        e.exports = function (e, t) {
            return e === t ? 0 !== e || 1 / e === 1 / t : o(e) && o(t)
        }
    },
    "7f9a": function (e, t, n) {
        var o = n("da84"),
            r = n("1626"),
            i = n("8925"),
            a = o.WeakMap;
        e.exports = r(a) && /native code/.test(i(a))
    },
    "825a": function (e, t, n) {
        var o = n("da84"),
            r = n("861d"),
            i = o.String,
            a = o.TypeError;
        e.exports = function (e) {
            if (r(e)) return e;
            throw a(i(e) + " is not an object")
        }
    },
    "83ab": function (e, t, n) {
        var o = n("d039");
        e.exports = !o((function () {
            return 7 != Object.defineProperty({}, 1, {
                get: function () {
                    return 7
                }
            })[1]
        }))
    },
    "83b9": function (e, t, n) {
        "use strict";
        var o = n("d925"),
            r = n("e683");
        e.exports = function (e, t) {
            return e && !o(t) ? r(e, t) : t
        }
    },
    "848b": function (e, t, n) {
        "use strict";
        var o = n("4a0c"),
            r = {};
        ["object", "boolean", "number", "function", "string", "symbol"].forEach((function (e, t) {
            r[e] = function (n) {
                return typeof n === e || "a" + (t < 1 ? "n " : " ") + e
            }
        }));
        var i = {},
            a = o.version.split(".");

        function s(e, t) {
            for (var n = t ? t.split(".") : a, o = e.split("."), r = 0; r < 3; r++) {
                if (n[r] > o[r]) return !0;
                if (n[r] < o[r]) return !1
            }
            return !1
        }

        function c(e, t, n) {
            if ("object" !== typeof e) throw new TypeError("options must be an object");
            var o = Object.keys(e),
                r = o.length;
            while (r-- > 0) {
                var i = o[r],
                    a = t[i];
                if (a) {
                    var s = e[i],
                        c = void 0 === s || a(s, i, e);
                    if (!0 !== c) throw new TypeError("option " + i + " must be " + c)
                } else if (!0 !== n) throw Error("Unknown option " + i)
            }
        }
        r.transitional = function (e, t, n) {
            var r = t && s(t);

            function a(e, t) {
                return "[Axios v" + o.version + "] Transitional option '" + e + "'" + t + (n ? ". " + n :
                    "")
            }
            return function (n, o, s) {
                if (!1 === e) throw new Error(a(o, " has been removed in " + t));
                return r && !i[o] && (i[o] = !0, console.warn(a(o, " has been deprecated since v" + t +
                    " and will be removed in the near future"))), !e || e(n, o, s)
            }
        }, e.exports = {
            isOlderVersion: s,
            assertOptions: c,
            validators: r
        }
    },
    "861d": function (e, t, n) {
        var o = n("1626");
        e.exports = function (e) {
            return "object" == typeof e ? null !== e : o(e)
        }
    },
    8875: function (e, t, n) {
        var o, r, i;
        (function (n, a) {
            r = [], o = a, i = "function" === typeof o ? o.apply(t, r) : o, void 0 === i || (e.exports = i)
        })("undefined" !== typeof self && self, (function () {
            function e() {
                var t = Object.getOwnPropertyDescriptor(document, "currentScript");
                if (!t && "currentScript" in document && document.currentScript) return document.currentScript;
                if (t && t.get !== e && document.currentScript) return document.currentScript;
                try {
                    throw new Error
                } catch (d) {
                    var n, o, r, i = /.*at [^(]*\((.*):(.+):(.+)\)$/gi,
                        a = /@([^@]*):(\d+):(\d+)\s*$/gi,
                        s = i.exec(d.stack) || a.exec(d.stack),
                        c = s && s[1] || !1,
                        l = s && s[2] || !1,
                        u = document.location.href.replace(document.location.hash, ""),
                        m = document.getElementsByTagName("script");
                    c === u && (n = document.documentElement.outerHTML, o = new RegExp(
                        "(?:[^\\n]+?\\n){0," + (l - 2) +
                        "}[^<]*<script>([\\d\\D]*?)<\\/script>[\\d\\D]*", "i"), r = n.replace(o,
                        "$1").trim());
                    for (var p = 0; p < m.length; p++) {
                        if ("interactive" === m[p].readyState) return m[p];
                        if (m[p].src === c) return m[p];
                        if (c === u && m[p].innerHTML && m[p].innerHTML.trim() === r) return m[p]
                    }
                    return null
                }
            }
            return e
        }))
    },
    8925: function (e, t, n) {
        var o = n("e330"),
            r = n("1626"),
            i = n("c6cd"),
            a = o(Function.toString);
        r(i.inspectSource) || (i.inspectSource = function (e) {
            return a(e)
        }), e.exports = i.inspectSource
    },
    8926: function (e, t, n) {
        "use strict";
        var o = n("be77"),
            r = n("7b13");
        e.exports = function () {
            return o(), "function" === typeof Promise.prototype["finally"] ? Promise.prototype["finally"] :
                r
        }
    },
    "8bbf": function (e, t) {
        e.exports = Vue
    },
    "8df4": function (e, t, n) {
        "use strict";
        var o = n("7a77");

        function r(e) {
            if ("function" !== typeof e) throw new TypeError("executor must be a function.");
            var t;
            this.promise = new Promise((function (e) {
                t = e
            }));
            var n = this;
            e((function (e) {
                n.reason || (n.reason = new o(e), t(n.reason))
            }))
        }
        r.prototype.throwIfRequested = function () {
            if (this.reason) throw this.reason
        }, r.source = function () {
            var e, t = new r((function (t) {
                e = t
            }));
            return {
                token: t,
                cancel: e
            }
        }, e.exports = r
    },
    "90e3": function (e, t, n) {
        var o = n("e330"),
            r = 0,
            i = Math.random(),
            a = o(1..toString);
        e.exports = function (e) {
            return "Symbol(" + (void 0 === e ? "" : e) + ")_" + a(++r + i, 36)
        }
    },
    9112: function (e, t, n) {
        var o = n("83ab"),
            r = n("9bf2"),
            i = n("5c6c");
        e.exports = o ? function (e, t, n) {
            return r.f(e, t, i(1, n))
        } : function (e, t, n) {
            return e[t] = n, e
        }
    },
    "94ca": function (e, t, n) {
        var o = n("d039"),
            r = n("1626"),
            i = /#|\.prototype\./,
            a = function (e, t) {
                var n = c[s(e)];
                return n == u || n != l && (r(t) ? o(t) : !!t)
            },
            s = a.normalize = function (e) {
                return String(e).replace(i, ".").toLowerCase()
            },
            c = a.data = {},
            l = a.NATIVE = "N",
            u = a.POLYFILL = "P";
        e.exports = a
    },
    "95a0": function (e, t, n) {
        "use strict";
        var o = n("00ce"),
            r = o("%Symbol.species%", !0),
            i = o("%TypeError%"),
            a = n("5018"),
            s = n("b398");
        e.exports = function (e, t) {
            if ("Object" !== s(e)) throw new i("Assertion failed: Type(O) is not Object");
            var n = e.constructor;
            if ("undefined" === typeof n) return t;
            if ("Object" !== s(n)) throw new i("O.constructor is not an Object");
            var o = r ? n[r] : void 0;
            if (null == o) return t;
            if (a(o)) return o;
            throw new i("no constructor found")
        }
    },
    "9a63": function (e, t) {
        var n = {
            utf8: {
                stringToBytes: function (e) {
                    return n.bin.stringToBytes(unescape(encodeURIComponent(e)))
                },
                bytesToString: function (e) {
                    return decodeURIComponent(escape(n.bin.bytesToString(e)))
                }
            },
            bin: {
                stringToBytes: function (e) {
                    for (var t = [], n = 0; n < e.length; n++) t.push(255 & e.charCodeAt(n));
                    return t
                },
                bytesToString: function (e) {
                    for (var t = [], n = 0; n < e.length; n++) t.push(String.fromCharCode(e[n]));
                    return t.join("")
                }
            }
        };
        e.exports = n
    },
    "9bf2": function (e, t, n) {
        var o = n("da84"),
            r = n("83ab"),
            i = n("0cfb"),
            a = n("aed9"),
            s = n("825a"),
            c = n("a04b"),
            l = o.TypeError,
            u = Object.defineProperty,
            m = Object.getOwnPropertyDescriptor,
            p = "enumerable",
            d = "configurable",
            h = "writable";
        t.f = r ? a ? function (e, t, n) {
            if (s(e), t = c(t), s(n), "function" === typeof e && "prototype" === t && "value" in n && h in
                n && !n[h]) {
                var o = m(e, t);
                o && o[h] && (e[t] = n.value, n = {
                    configurable: d in n ? n[d] : o[d],
                    enumerable: p in n ? n[p] : o[p],
                    writable: !1
                })
            }
            return u(e, t, n)
        } : u : function (e, t, n) {
            if (s(e), t = c(t), s(n), i) try {
                return u(e, t, n)
            } catch (o) {}
            if ("get" in n || "set" in n) throw l("Accessors not supported");
            return "value" in n && (e[t] = n.value), e
        }
    },
    a04b: function (e, t, n) {
        var o = n("c04e"),
            r = n("d9b5");
        e.exports = function (e) {
            var t = o(e, "string");
            return r(t) ? t : t + ""
        }
    },
    a0d3: function (e, t, n) {
        "use strict";
        var o = n("0f7c");
        e.exports = o.call(Function.call, Object.prototype.hasOwnProperty)
    },
    a85a: function (e, t, n) {
        "use strict";
        n.r(t);
        var o = n("791b");
        for (var r in o)["default"].indexOf(r) < 0 && function (e) {
            n.d(t, e, (function () {
                return o[e]
            }))
        }(r)
    },
    ab36: function (e, t, n) {
        var o = n("861d"),
            r = n("9112");
        e.exports = function (e, t) {
            o(t) && "cause" in t && r(e, "cause", t.cause)
        }
    },
    ae57: function (e, t, n) {
        "use strict";
        var o = n("00ce"),
            r = o("%TypeError%"),
            i = n("fffd"),
            a = n("2a6d"),
            s = n("7049"),
            c = n("6715"),
            l = n("4600"),
            u = n("706f"),
            m = n("7d36"),
            p = n("2c10"),
            d = n("b398");
        e.exports = function (e, t, n) {
            if ("Object" !== d(e)) throw new r("Assertion failed: Type(O) is not Object");
            if (!u(t)) throw new r("Assertion failed: IsPropertyKey(P) is not true");
            var o = i({
                Type: d,
                IsDataDescriptor: l,
                IsAccessorDescriptor: c
            }, n) ? n : p(n);
            if (!i({
                    Type: d,
                    IsDataDescriptor: l,
                    IsAccessorDescriptor: c
                }, o)) throw new r("Assertion failed: Desc is not a valid Property Descriptor");
            return a(l, m, s, e, t, o)
        }
    },
    aed9: function (e, t, n) {
        var o = n("83ab"),
            r = n("d039");
        e.exports = o && r((function () {
            return 42 != Object.defineProperty((function () {}), "prototype", {
                value: 42,
                writable: !1
            }).prototype
        }))
    },
    b189: function (e, t, n) {
        "use strict";
        var o;
        if (!Object.keys) {
            var r = Object.prototype.hasOwnProperty,
                i = Object.prototype.toString,
                a = n("d4ab"),
                s = Object.prototype.propertyIsEnumerable,
                c = !s.call({
                    toString: null
                }, "toString"),
                l = s.call((function () {}), "prototype"),
                u = ["toString", "toLocaleString", "valueOf", "hasOwnProperty", "isPrototypeOf",
                    "propertyIsEnumerable", "constructor"],
                m = function (e) {
                    var t = e.constructor;
                    return t && t.prototype === e
                },
                p = {
                    $applicationCache: !0,
                    $console: !0,
                    $external: !0,
                    $frame: !0,
                    $frameElement: !0,
                    $frames: !0,
                    $innerHeight: !0,
                    $innerWidth: !0,
                    $onmozfullscreenchange: !0,
                    $onmozfullscreenerror: !0,
                    $outerHeight: !0,
                    $outerWidth: !0,
                    $pageXOffset: !0,
                    $pageYOffset: !0,
                    $parent: !0,
                    $scrollLeft: !0,
                    $scrollTop: !0,
                    $scrollX: !0,
                    $scrollY: !0,
                    $self: !0,
                    $webkitIndexedDB: !0,
                    $webkitStorageInfo: !0,
                    $window: !0
                },
                d = function () {
                    if ("undefined" === typeof window) return !1;
                    for (var e in window) try {
                        if (!p["$" + e] && r.call(window, e) && null !== window[e] && "object" === typeof window[
                                e]) try {
                            m(window[e])
                        } catch (t) {
                            return !0
                        }
                    } catch (t) {
                        return !0
                    }
                    return !1
                }(),
                h = function (e) {
                    if ("undefined" === typeof window || !d) return m(e);
                    try {
                        return m(e)
                    } catch (t) {
                        return !1
                    }
                };
            o = function (e) {
                var t = null !== e && "object" === typeof e,
                    n = "[object Function]" === i.call(e),
                    o = a(e),
                    s = t && "[object String]" === i.call(e),
                    m = [];
                if (!t && !n && !o) throw new TypeError("Object.keys called on a non-object");
                var p = l && n;
                if (s && e.length > 0 && !r.call(e, 0))
                    for (var d = 0; d < e.length; ++d) m.push(String(d));
                if (o && e.length > 0)
                    for (var f = 0; f < e.length; ++f) m.push(String(f));
                else
                    for (var b in e) p && "prototype" === b || !r.call(e, b) || m.push(String(b));
                if (c)
                    for (var g = h(e), y = 0; y < u.length; ++y) g && "constructor" === u[y] || !r.call(e,
                        u[y]) || m.push(u[y]);
                return m
            }
        }
        e.exports = o
    },
    b398: function (e, t, n) {
        "use strict";
        var o = n("5183");
        e.exports = function (e) {
            return "symbol" === typeof e ? "Symbol" : "bigint" === typeof e ? "BigInt" : o(e)
        }
    },
    b50d: function (e, t, n) {
        "use strict";
        var o = n("c532"),
            r = n("467f"),
            i = n("7aac"),
            a = n("30b5"),
            s = n("83b9"),
            c = n("c345"),
            l = n("3934"),
            u = n("2d83");
        e.exports = function (e) {
            return new Promise((function (t, n) {
                var m = e.data,
                    p = e.headers,
                    d = e.responseType;
                o.isFormData(m) && delete p["Content-Type"];
                var h = new XMLHttpRequest;
                if (e.auth) {
                    var f = e.auth.username || "",
                        b = e.auth.password ? unescape(encodeURIComponent(e.auth.password)) :
                        "";
                    p.Authorization = "Basic " + btoa(f + ":" + b)
                }
                var g = s(e.baseURL, e.url);

                function y() {
                    if (h) {
                        var o = "getAllResponseHeaders" in h ? c(h.getAllResponseHeaders()) :
                            null,
                            i = d && "text" !== d && "json" !== d ? h.response : h.responseText,
                            a = {
                                data: i,
                                status: h.status,
                                statusText: h.statusText,
                                headers: o,
                                config: e,
                                request: h
                            };
                        r(t, n, a), h = null
                    }
                }
                if (h.open(e.method.toUpperCase(), a(g, e.params, e.paramsSerializer), !0), h.timeout =
                    e.timeout, "onloadend" in h ? h.onloadend = y : h.onreadystatechange =
                    function () {
                        h && 4 === h.readyState && (0 !== h.status || h.responseURL && 0 === h.responseURL
                            .indexOf("file:")) && setTimeout(y)
                    }, h.onabort = function () {
                        h && (n(u("Request aborted", e, "ECONNABORTED", h)), h = null)
                    }, h.onerror = function () {
                        n(u("Network Error", e, null, h)), h = null
                    }, h.ontimeout = function () {
                        var t = "timeout of " + e.timeout + "ms exceeded";
                        e.timeoutErrorMessage && (t = e.timeoutErrorMessage), n(u(t, e, e.transitional &&
                            e.transitional.clarifyTimeoutError ? "ETIMEDOUT" :
                            "ECONNABORTED", h)), h = null
                    }, o.isStandardBrowserEnv()) {
                    var w = (e.withCredentials || l(g)) && e.xsrfCookieName ? i.read(e.xsrfCookieName) :
                        void 0;
                    w && (p[e.xsrfHeaderName] = w)
                }
                "setRequestHeader" in h && o.forEach(p, (function (e, t) {
                        "undefined" === typeof m && "content-type" === t.toLowerCase() ?
                            delete p[t] : h.setRequestHeader(t, e)
                    })), o.isUndefined(e.withCredentials) || (h.withCredentials = !!e.withCredentials),
                    d && "json" !== d && (h.responseType = e.responseType), "function" ===
                    typeof e.onDownloadProgress && h.addEventListener("progress", e.onDownloadProgress),
                    "function" === typeof e.onUploadProgress && h.upload && h.upload.addEventListener(
                        "progress", e.onUploadProgress), e.cancelToken && e.cancelToken.promise
                    .then((function (e) {
                        h && (h.abort(), n(e), h = null)
                    })), m || (m = null), h.send(m)
            }))
        }
    },
    b622: function (e, t, n) {
        var o = n("da84"),
            r = n("5692"),
            i = n("1a2d"),
            a = n("90e3"),
            s = n("4930"),
            c = n("fdbf"),
            l = r("wks"),
            u = o.Symbol,
            m = u && u["for"],
            p = c ? u : u && u.withoutSetter || a;
        e.exports = function (e) {
            if (!i(l, e) || !s && "string" != typeof l[e]) {
                var t = "Symbol." + e;
                s && i(u, e) ? l[e] = u[e] : l[e] = c && m ? m(t) : p(t)
            }
            return l[e]
        }
    },
    b980: function (e, t, n) {
        var o = n("d039"),
            r = n("5c6c");
        e.exports = !o((function () {
            var e = Error("a");
            return !("stack" in e) || (Object.defineProperty(e, "stack", r(1, 7)), 7 !== e.stack)
        }))
    },
    bc3a: function (e, t, n) {
        e.exports = n("cee4")
    },
    be77: function (e, t, n) {
        "use strict";
        e.exports = function () {
            if ("function" !== typeof Promise) throw new TypeError(
                "`Promise.prototype.finally` requires a global `Promise` be available.")
        }
    },
    c04e: function (e, t, n) {
        var o = n("da84"),
            r = n("c65b"),
            i = n("861d"),
            a = n("d9b5"),
            s = n("dc4a"),
            c = n("485a"),
            l = n("b622"),
            u = o.TypeError,
            m = l("toPrimitive");
        e.exports = function (e, t) {
            if (!i(e) || a(e)) return e;
            var n, o = s(e, m);
            if (o) {
                if (void 0 === t && (t = "default"), n = r(o, e, t), !i(n) || a(n)) return n;
                throw u("Can't convert object to primitive value")
            }
            return void 0 === t && (t = "number"), c(e, t)
        }
    },
    c345: function (e, t, n) {
        "use strict";
        var o = n("c532"),
            r = ["age", "authorization", "content-length", "content-type", "etag", "expires", "from", "host",
                "if-modified-since", "if-unmodified-since", "last-modified", "location", "max-forwards",
                "proxy-authorization", "referer", "retry-after", "user-agent"];
        e.exports = function (e) {
            var t, n, i, a = {};
            return e ? (o.forEach(e.split("\n"), (function (e) {
                if (i = e.indexOf(":"), t = o.trim(e.substr(0, i)).toLowerCase(), n = o.trim(
                        e.substr(i + 1)), t) {
                    if (a[t] && r.indexOf(t) >= 0) return;
                    a[t] = "set-cookie" === t ? (a[t] ? a[t] : []).concat([n]) : a[t] ? a[t] +
                        ", " + n : n
                }
            })), a) : a
        }
    },
    c401: function (e, t, n) {
        "use strict";
        var o = n("c532"),
            r = n("2444");
        e.exports = function (e, t, n) {
            var i = this || r;
            return o.forEach(n, (function (n) {
                e = n.call(i, e, t)
            })), e
        }
    },
    c430: function (e, t) {
        e.exports = !1
    },
    c46d: function (e, t, n) {
        "use strict";
        var o = n("00ce"),
            r = o("%TypeError%"),
            i = o("%SyntaxError%"),
            a = n("a0d3"),
            s = {
                "Property Descriptor": function (e, t) {
                    if ("Object" !== e(t)) return !1;
                    var n = {
                        "[[Configurable]]": !0,
                        "[[Enumerable]]": !0,
                        "[[Get]]": !0,
                        "[[Set]]": !0,
                        "[[Value]]": !0,
                        "[[Writable]]": !0
                    };
                    for (var o in t)
                        if (a(t, o) && !n[o]) return !1;
                    var i = a(t, "[[Value]]"),
                        s = a(t, "[[Get]]") || a(t, "[[Set]]");
                    if (i && s) throw new r(
                        "Property Descriptors may not be both accessor and data descriptors");
                    return !0
                }
            };
        e.exports = function (e, t, n, o) {
            var a = s[t];
            if ("function" !== typeof a) throw new i("unknown record type: " + t);
            if (!a(e, o)) throw new r(n + " must be a " + t)
        }
    },
    c532: function (e, t, n) {
        "use strict";
        var o = n("1d2b"),
            r = Object.prototype.toString;

        function i(e) {
            return "[object Array]" === r.call(e)
        }

        function a(e) {
            return "undefined" === typeof e
        }

        function s(e) {
            return null !== e && !a(e) && null !== e.constructor && !a(e.constructor) && "function" === typeof e
                .constructor.isBuffer && e.constructor.isBuffer(e)
        }

        function c(e) {
            return "[object ArrayBuffer]" === r.call(e)
        }

        function l(e) {
            return "undefined" !== typeof FormData && e instanceof FormData
        }

        function u(e) {
            var t;
            return t = "undefined" !== typeof ArrayBuffer && ArrayBuffer.isView ? ArrayBuffer.isView(e) : e &&
                e.buffer && e.buffer instanceof ArrayBuffer, t
        }

        function m(e) {
            return "string" === typeof e
        }

        function p(e) {
            return "number" === typeof e
        }

        function d(e) {
            return null !== e && "object" === typeof e
        }

        function h(e) {
            if ("[object Object]" !== r.call(e)) return !1;
            var t = Object.getPrototypeOf(e);
            return null === t || t === Object.prototype
        }

        function f(e) {
            return "[object Date]" === r.call(e)
        }

        function b(e) {
            return "[object File]" === r.call(e)
        }

        function g(e) {
            return "[object Blob]" === r.call(e)
        }

        function y(e) {
            return "[object Function]" === r.call(e)
        }

        function w(e) {
            return d(e) && y(e.pipe)
        }

        function v(e) {
            return "undefined" !== typeof URLSearchParams && e instanceof URLSearchParams
        }

        function x(e) {
            return e.trim ? e.trim() : e.replace(/^\s+|\s+$/g, "")
        }

        function k() {
            return ("undefined" === typeof navigator || "ReactNative" !== navigator.product && "NativeScript" !==
                navigator.product && "NS" !== navigator.product) && ("undefined" !== typeof window &&
                "undefined" !== typeof document)
        }

        function j(e, t) {
            if (null !== e && "undefined" !== typeof e)
                if ("object" !== typeof e && (e = [e]), i(e))
                    for (var n = 0, o = e.length; n < o; n++) t.call(null, e[n], n, e);
                else
                    for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.call(null, e[r], r, e)
        }

        function S() {
            var e = {};

            function t(t, n) {
                h(e[n]) && h(t) ? e[n] = S(e[n], t) : h(t) ? e[n] = S({}, t) : i(t) ? e[n] = t.slice() : e[n] =
                    t
            }
            for (var n = 0, o = arguments.length; n < o; n++) j(arguments[n], t);
            return e
        }

        function _(e, t, n) {
            return j(t, (function (t, r) {
                e[r] = n && "function" === typeof t ? o(t, n) : t
            })), e
        }

        function A(e) {
            return 65279 === e.charCodeAt(0) && (e = e.slice(1)), e
        }
        e.exports = {
            isArray: i,
            isArrayBuffer: c,
            isBuffer: s,
            isFormData: l,
            isArrayBufferView: u,
            isString: m,
            isNumber: p,
            isObject: d,
            isPlainObject: h,
            isUndefined: a,
            isDate: f,
            isFile: b,
            isBlob: g,
            isFunction: y,
            isStream: w,
            isURLSearchParams: v,
            isStandardBrowserEnv: k,
            forEach: j,
            merge: S,
            extend: _,
            trim: x,
            stripBOM: A
        }
    },
    c65b: function (e, t) {
        var n = Function.prototype.call;
        e.exports = n.bind ? n.bind(n) : function () {
            return n.apply(n, arguments)
        }
    },
    c6b6: function (e, t, n) {
        var o = n("e330"),
            r = o({}.toString),
            i = o("".slice);
        e.exports = function (e) {
            return i(r(e), 8, -1)
        }
    },
    c6cd: function (e, t, n) {
        var o = n("da84"),
            r = n("ce4e"),
            i = "__core-js_shared__",
            a = o[i] || r(i, {});
        e.exports = a
    },
    c770: function (e, t, n) {
        var o = n("e330"),
            r = o("".replace),
            i = function (e) {
                return String(Error(e).stack)
            }("zxcasd"),
            a = /\n\s*at [^:]*:[^\n]*/,
            s = a.test(i);
        e.exports = function (e, t) {
            if (s && "string" == typeof e)
                while (t--) e = r(e, a, "");
            return e
        }
    },
    c8af: function (e, t, n) {
        "use strict";
        var o = n("c532");
        e.exports = function (e, t) {
            o.forEach(e, (function (n, o) {
                o !== t && o.toUpperCase() === t.toUpperCase() && (e[t] = n, delete e[o])
            }))
        }
    },
    c8ba: function (e, t) {
        var n;
        n = function () {
            return this
        }();
        try {
            n = n || new Function("return this")()
        } catch (o) {
            "object" === typeof window && (n = window)
        }
        e.exports = n
    },
    ca00: function (e, t, n) {
        "use strict";

        function o(e) {
            var t = (new Date).getTime(),
                n = t - e,
                o = Math.floor(n / 864e5);
            if (0 === o) {
                var i = n % 864e5,
                    a = Math.floor(i / 36e5);
                if (0 === a) {
                    var s = i % 36e5,
                        c = Math.floor(s / 6e4);
                    if (0 === c) {
                        var l = s % 6e4,
                            u = Math.round(l / 1e3);
                        return u < 1 ? "刚刚" : u + " 秒前"
                    }
                    return c + " 分钟前"
                }
                return a + " 小时前"
            }
            return o < 0 ? "刚刚" : o < 1 ? o + " 天前" : r(e, "yyyy/MM/dd hh:mm")
        }

        function r(e, t) {
            e = new Date(e), /(y+)/.test(t) && (t = t.replace(RegExp.$1, (e.getFullYear() + "").substr(4 -
                RegExp.$1.length)));
            let n = {
                "M+": e.getMonth() + 1,
                "d+": e.getDate(),
                "h+": e.getHours(),
                "m+": e.getMinutes(),
                "s+": e.getSeconds()
            };
            for (let o in n)
                if (new RegExp(`(${o})`).test(t)) {
                    let e = n[o] + "";
                    t = t.replace(RegExp.$1, 1 === RegExp.$1.length ? e : i(e))
                } return t
        }

        function i(e) {
            return ("00" + e).substr(e.length)
        }

        function a(e) {
            return !e
        }

        function s(e) {
            return e && "object" === typeof e && e.constructor === Object
        }

        function c(e) {
            var t = /^[1-9][0-9]{4,9}$/gim;
            return t.test(e)
        }
        n.d(t, "j", (function () {
            return o
        })), n.d(t, "b", (function () {
            return a
        })), n.d(t, "d", (function () {
            return s
        })), n.d(t, "e", (function () {
            return c
        })), n.d(t, "f", (function () {
            return l
        })), n.d(t, "a", (function () {
            return u
        })), n.d(t, "h", (function () {
            return h
        })), n.d(t, "c", (function () {
            return f
        })), n.d(t, "g", (function () {
            return b
        })), n.d(t, "i", (function () {
            return g
        }));
        const l = e => {
            const t = Object.keys(e).map(t => `${t}=${encodeURIComponent(e[t]||"")}`).join("&");
            return t
        };

        function u(e) {
            return decodeURIComponent((new RegExp("[?|&]" + e + "=([^&;]+?)(&|#|;|$)").exec(location.href) ||
                "")[1].replace(/\+/g, "%20")) || null
        }

        function m(e) {
            return e.replace(/((\s|&nbsp;)*\r?\n)+$/g, "")
        }

        function p(e) {
            return e.replace(/((\s|&nbsp;)*\r?\n){3,}/g, "")
        }

        function d(e) {
            return e.replace(/^((\s|&nbsp;)*\r?\n)+/g, "")
        }

        function h(e) {
            return e = d(e), e = m(e), e = p(e), e
        }

        function f(e, t) {
            if (!e || !e.getBoundingClientRect) return !1;
            var n = window.innerHeight,
                o = document.documentElement.scrollTop || document.body.scrollTop,
                r = t.offsetTop,
                i = e.offsetTop + r,
                a = e.offsetHeight;
            return i + a < o + n && i + a > o
        }

        function b(e) {
            for (let t in e) {
                let n = e[t];
                "" === n ? delete e[t] : n.constructor == Object && b(n)
            }
        }

        function g(e) {
            return new Promise(t => setTimeout(t, e))
        }
    },
    ca84: function (e, t, n) {
        var o = n("e330"),
            r = n("1a2d"),
            i = n("fc6a"),
            a = n("4d64").indexOf,
            s = n("d012"),
            c = o([].push);
        e.exports = function (e, t) {
            var n, o = i(e),
                l = 0,
                u = [];
            for (n in o) !r(s, n) && r(o, n) && c(u, n);
            while (t.length > l) r(o, n = t[l++]) && (~a(u, n) || c(u, n));
            return u
        }
    },
    cc12: function (e, t, n) {
        var o = n("da84"),
            r = n("861d"),
            i = o.document,
            a = r(i) && r(i.createElement);
        e.exports = function (e) {
            return a ? i.createElement(e) : {}
        }
    },
    ce4e: function (e, t, n) {
        var o = n("da84"),
            r = Object.defineProperty;
        e.exports = function (e, t) {
            try {
                r(o, e, {
                    value: t,
                    configurable: !0,
                    writable: !0
                })
            } catch (n) {
                o[e] = t
            }
            return t
        }
    },
    cee4: function (e, t, n) {
        "use strict";
        var o = n("c532"),
            r = n("1d2b"),
            i = n("0a06"),
            a = n("4a7b"),
            s = n("2444");

        function c(e) {
            var t = new i(e),
                n = r(i.prototype.request, t);
            return o.extend(n, i.prototype, t), o.extend(n, t), n
        }
        var l = c(s);
        l.Axios = i, l.create = function (e) {
            return c(a(l.defaults, e))
        }, l.Cancel = n("7a77"), l.CancelToken = n("8df4"), l.isCancel = n("2e67"), l.all = function (e) {
            return Promise.all(e)
        }, l.spread = n("0df6"), l.isAxiosError = n("5f02"), e.exports = l, e.exports.default = l
    },
    d012: function (e, t) {
        e.exports = {}
    },
    d039: function (e, t) {
        e.exports = function (e) {
            try {
                return !!e()
            } catch (t) {
                return !0
            }
        }
    },
    d066: function (e, t, n) {
        var o = n("da84"),
            r = n("1626"),
            i = function (e) {
                return r(e) ? e : void 0
            };
        e.exports = function (e, t) {
            return arguments.length < 2 ? i(o[e]) : o[e] && o[e][t]
        }
    },
    d1e7: function (e, t, n) {
        "use strict";
        var o = {}.propertyIsEnumerable,
            r = Object.getOwnPropertyDescriptor,
            i = r && !o.call({
                1: 2
            }, 1);
        t.f = i ? function (e) {
            var t = r(this, e);
            return !!t && t.enumerable
        } : o
    },
    d2bb: function (e, t, n) {
        var o = n("e330"),
            r = n("825a"),
            i = n("3bbe");
        e.exports = Object.setPrototypeOf || ("__proto__" in {} ? function () {
            var e, t = !1,
                n = {};
            try {
                e = o(Object.getOwnPropertyDescriptor(Object.prototype, "__proto__").set), e(n, []), t =
                    n instanceof Array
            } catch (a) {}
            return function (n, o) {
                return r(n), i(o), t ? e(n, o) : n.__proto__ = o, n
            }
        }() : void 0)
    },
    d4ab: function (e, t, n) {
        "use strict";
        var o = Object.prototype.toString;
        e.exports = function (e) {
            var t = o.call(e),
                n = "[object Arguments]" === t;
            return n || (n = "[object Array]" !== t && null !== e && "object" === typeof e && "number" ===
                typeof e.length && e.length >= 0 && "[object Function]" === o.call(e.callee)), n
        }
    },
    d6c7: function (e, t, n) {
        "use strict";
        var o = Array.prototype.slice,
            r = n("d4ab"),
            i = Object.keys,
            a = i ? function (e) {
                return i(e)
            } : n("b189"),
            s = Object.keys;
        a.shim = function () {
            if (Object.keys) {
                var e = function () {
                    var e = Object.keys(arguments);
                    return e && e.length === arguments.length
                }(1, 2);
                e || (Object.keys = function (e) {
                    return r(e) ? s(o.call(e)) : s(e)
                })
            } else Object.keys = a;
            return Object.keys || a
        }, e.exports = a
    },
    d925: function (e, t, n) {
        "use strict";
        e.exports = function (e) {
            return /^([a-z][a-z\d\+\-\.]*:)?\/\//i.test(e)
        }
    },
    d9b5: function (e, t, n) {
        var o = n("da84"),
            r = n("d066"),
            i = n("1626"),
            a = n("3a9b"),
            s = n("fdbf"),
            c = o.Object;
        e.exports = s ? function (e) {
            return "symbol" == typeof e
        } : function (e) {
            var t = r("Symbol");
            return i(t) && a(t.prototype, c(e))
        }
    },
    d9e2: function (e, t, n) {
        var o = n("23e7"),
            r = n("da84"),
            i = n("2ba4"),
            a = n("e5cb"),
            s = "WebAssembly",
            c = r[s],
            l = 7 !== Error("e", {
                cause: 7
            }).cause,
            u = function (e, t) {
                var n = {};
                n[e] = a(e, t, l), o({
                    global: !0,
                    forced: l
                }, n)
            },
            m = function (e, t) {
                if (c && c[e]) {
                    var n = {};
                    n[e] = a(s + "." + e, t, l), o({
                        target: s,
                        stat: !0,
                        forced: l
                    }, n)
                }
            };
        u("Error", (function (e) {
            return function (t) {
                return i(e, this, arguments)
            }
        })), u("EvalError", (function (e) {
            return function (t) {
                return i(e, this, arguments)
            }
        })), u("RangeError", (function (e) {
            return function (t) {
                return i(e, this, arguments)
            }
        })), u("ReferenceError", (function (e) {
            return function (t) {
                return i(e, this, arguments)
            }
        })), u("SyntaxError", (function (e) {
            return function (t) {
                return i(e, this, arguments)
            }
        })), u("TypeError", (function (e) {
            return function (t) {
                return i(e, this, arguments)
            }
        })), u("URIError", (function (e) {
            return function (t) {
                return i(e, this, arguments)
            }
        })), m("CompileError", (function (e) {
            return function (t) {
                return i(e, this, arguments)
            }
        })), m("LinkError", (function (e) {
            return function (t) {
                return i(e, this, arguments)
            }
        })), m("RuntimeError", (function (e) {
            return function (t) {
                return i(e, this, arguments)
            }
        }))
    },
    da84: function (e, t, n) {
        (function (t) {
            var n = function (e) {
                return e && e.Math == Math && e
            };
            e.exports = n("object" == typeof globalThis && globalThis) || n("object" == typeof window &&
                    window) || n("object" == typeof self && self) || n("object" == typeof t && t) ||
                function () {
                    return this
                }() || Function("return this")()
        }).call(this, n("c8ba"))
    },
    dc4a: function (e, t, n) {
        var o = n("59ed");
        e.exports = function (e, t) {
            var n = e[t];
            return null == n ? void 0 : o(n)
        }
    },
    df7c: function (e, t, n) {
        (function (e) {
            function n(e, t) {
                for (var n = 0, o = e.length - 1; o >= 0; o--) {
                    var r = e[o];
                    "." === r ? e.splice(o, 1) : ".." === r ? (e.splice(o, 1), n++) : n && (e.splice(o, 1),
                        n--)
                }
                if (t)
                    for (; n--; n) e.unshift("..");
                return e
            }

            function o(e) {
                "string" !== typeof e && (e += "");
                var t, n = 0,
                    o = -1,
                    r = !0;
                for (t = e.length - 1; t >= 0; --t)
                    if (47 === e.charCodeAt(t)) {
                        if (!r) {
                            n = t + 1;
                            break
                        }
                    } else -1 === o && (r = !1, o = t + 1);
                return -1 === o ? "" : e.slice(n, o)
            }

            function r(e, t) {
                if (e.filter) return e.filter(t);
                for (var n = [], o = 0; o < e.length; o++) t(e[o], o, e) && n.push(e[o]);
                return n
            }
            t.resolve = function () {
                for (var t = "", o = !1, i = arguments.length - 1; i >= -1 && !o; i--) {
                    var a = i >= 0 ? arguments[i] : e.cwd();
                    if ("string" !== typeof a) throw new TypeError(
                        "Arguments to path.resolve must be strings");
                    a && (t = a + "/" + t, o = "/" === a.charAt(0))
                }
                return t = n(r(t.split("/"), (function (e) {
                    return !!e
                })), !o).join("/"), (o ? "/" : "") + t || "."
            }, t.normalize = function (e) {
                var o = t.isAbsolute(e),
                    a = "/" === i(e, -1);
                return e = n(r(e.split("/"), (function (e) {
                    return !!e
                })), !o).join("/"), e || o || (e = "."), e && a && (e += "/"), (o ? "/" : "") + e
            }, t.isAbsolute = function (e) {
                return "/" === e.charAt(0)
            }, t.join = function () {
                var e = Array.prototype.slice.call(arguments, 0);
                return t.normalize(r(e, (function (e, t) {
                    if ("string" !== typeof e) throw new TypeError(
                        "Arguments to path.join must be strings");
                    return e
                })).join("/"))
            }, t.relative = function (e, n) {
                function o(e) {
                    for (var t = 0; t < e.length; t++)
                        if ("" !== e[t]) break;
                    for (var n = e.length - 1; n >= 0; n--)
                        if ("" !== e[n]) break;
                    return t > n ? [] : e.slice(t, n - t + 1)
                }
                e = t.resolve(e).substr(1), n = t.resolve(n).substr(1);
                for (var r = o(e.split("/")), i = o(n.split("/")), a = Math.min(r.length, i.length), s =
                        a, c = 0; c < a; c++)
                    if (r[c] !== i[c]) {
                        s = c;
                        break
                    } var l = [];
                for (c = s; c < r.length; c++) l.push("..");
                return l = l.concat(i.slice(s)), l.join("/")
            }, t.sep = "/", t.delimiter = ":", t.dirname = function (e) {
                if ("string" !== typeof e && (e += ""), 0 === e.length) return ".";
                for (var t = e.charCodeAt(0), n = 47 === t, o = -1, r = !0, i = e.length - 1; i >= 1; --
                    i)
                    if (t = e.charCodeAt(i), 47 === t) {
                        if (!r) {
                            o = i;
                            break
                        }
                    } else r = !1;
                return -1 === o ? n ? "/" : "." : n && 1 === o ? "/" : e.slice(0, o)
            }, t.basename = function (e, t) {
                var n = o(e);
                return t && n.substr(-1 * t.length) === t && (n = n.substr(0, n.length - t.length)), n
            }, t.extname = function (e) {
                "string" !== typeof e && (e += "");
                for (var t = -1, n = 0, o = -1, r = !0, i = 0, a = e.length - 1; a >= 0; --a) {
                    var s = e.charCodeAt(a);
                    if (47 !== s) - 1 === o && (r = !1, o = a + 1), 46 === s ? -1 === t ? t = a : 1 !==
                        i && (i = 1) : -1 !== t && (i = -1);
                    else if (!r) {
                        n = a + 1;
                        break
                    }
                }
                return -1 === t || -1 === o || 0 === i || 1 === i && t === o - 1 && t === n + 1 ? "" :
                    e.slice(t, o)
            };
            var i = "b" === "ab".substr(-1) ? function (e, t, n) {
                return e.substr(t, n)
            } : function (e, t, n) {
                return t < 0 && (t = e.length + t), e.substr(t, n)
            }
        }).call(this, n("4362"))
    },
    e330: function (e, t) {
        var n = Function.prototype,
            o = n.bind,
            r = n.call,
            i = o && o.bind(r, r);
        e.exports = o ? function (e) {
            return e && i(e)
        } : function (e) {
            return e && function () {
                return r.apply(e, arguments)
            }
        }
    },
    e391: function (e, t, n) {
        var o = n("577e");
        e.exports = function (e, t) {
            return void 0 === e ? arguments.length < 2 ? "" : t : o(e)
        }
    },
    e5cb: function (e, t, n) {
        "use strict";
        var o = n("d066"),
            r = n("1a2d"),
            i = n("9112"),
            a = n("3a9b"),
            s = n("d2bb"),
            c = n("e893"),
            l = n("7156"),
            u = n("e391"),
            m = n("ab36"),
            p = n("c770"),
            d = n("b980"),
            h = n("c430");
        e.exports = function (e, t, n, f) {
            var b = f ? 2 : 1,
                g = e.split("."),
                y = g[g.length - 1],
                w = o.apply(null, g);
            if (w) {
                var v = w.prototype;
                if (!h && r(v, "cause") && delete v.cause, !n) return w;
                var x = o("Error"),
                    k = t((function (e, t) {
                        var n = u(f ? t : e, void 0),
                            o = f ? new w(e) : new w;
                        return void 0 !== n && i(o, "message", n), d && i(o, "stack", p(o.stack, 2)),
                            this && a(v, this) && l(o, this, k), arguments.length > b && m(o,
                                arguments[b]), o
                    }));
                if (k.prototype = v, "Error" !== y && (s ? s(k, x) : c(k, x, {
                        name: !0
                    })), c(k, w), !h) try {
                    v.name !== y && i(v, "name", y), v.constructor = k
                } catch (j) {}
                return k
            }
        }
    },
    e64f: function (e, t, n) {
        var o = n("24fb");
        t = o(!1), t.push([e.i,
            '.markdown-body{-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;color:#24292e;line-height:1.5;font-size:14px;word-wrap:break-word}.markdown-body .octicon{display:inline-block;fill:currentColor;vertical-align:text-bottom}.markdown-body .anchor{float:left;line-height:1;margin-left:-20px;padding-right:4px}.markdown-body .anchor:focus{outline:none}.markdown-body details{display:block}.markdown-body details summary{cursor:pointer}.markdown-body summary{display:list-item}.markdown-body a{background-color:transparent;text-decoration:none}.markdown-body a:hover{text-decoration:underline}.markdown-body a:not([href]){color:inherit;text-decoration:none}.markdown-body strong{font-weight:inherit;font-weight:bolder;font-weight:600}.markdown-body h1{margin:.67em 0;font-size:32px;font-size:2em}.markdown-body img{border-style:none;max-width:100%}.markdown-body hr,.markdown-body img{-webkit-box-sizing:content-box;box-sizing:content-box}.markdown-body hr{overflow:visible;background:transparent;border-bottom:1px solid #dfe2e5;height:0;margin:15px 0;overflow:hidden;background-color:#e1e4e8;border:0;height:.25em;margin:24px 0;padding:0;border-bottom-color:#eee}.markdown-body hr:after,.markdown-body hr:before{content:"";display:table}.markdown-body hr:after{clear:both}.markdown-body input{font:inherit;margin:0;overflow:visible;font-family:inherit;font-size:inherit;line-height:inherit}.markdown-body [type=checkbox]{padding:0}.markdown-body *,.markdown-body [type=checkbox]{-webkit-box-sizing:border-box;box-sizing:border-box}.markdown-body table{border-collapse:collapse;border-spacing:0;display:block;overflow:auto;width:100%}.markdown-body table th{font-weight:600}.markdown-body table tr{background-color:#fff;border-top:1px solid #c6cbd1}.markdown-body table tr:nth-child(2n){background-color:#f6f8fa}.markdown-body h2{font-size:24px;font-size:1.5em}.markdown-body h3{font-size:20px;font-size:1.25em}.markdown-body h4{font-size:16px;font-size:1em}.markdown-body h5{font-size:14px}.markdown-body h6{font-size:14px;color:#6a737d;font-size:.85em}.markdown-body p{margin-bottom:10px;margin-top:0;line-height:1.5;font-size:14px}.markdown-body p:last-child{margin-bottom:0}.markdown-body blockquote{margin:0;color:#6a737d;padding:0 1em;border-left:.25em solid #dfe2e5}.markdown-body blockquote>:first-child{margin-top:0}.markdown-body blockquote>:last-child{margin-bottom:0}.markdown-body dd{margin-left:0}.markdown-body .markdown-content pre{margin-top:0;word-wrap:normal;white-space:normal;word-break:break-word}.markdown-body .markdown-content pre>code{border:0;font-size:100%;margin:0;padding:0;white-space:normal;word-break:break-word}.markdown-body .markdown-content pre code{display:inline;line-height:inherit;margin:0;overflow:visible;padding:0;border:0;color:var(--routine);word-wrap:normal;white-space:normal;word-break:break-word;background-color:transparent}.markdown-body li{word-wrap:break-all}.markdown-body li>p{margin-top:12px}.markdown-body li+li{margin-top:.25em}.markdown-body dl{padding:0}.markdown-body dl dt{font-size:1em;font-style:italic;font-weight:600;margin-top:16px;padding:0}.markdown-body dl dd{margin-bottom:16px;padding:0 16px}.markdown-body img[align=right]{padding-left:20px}.markdown-body img[align=left]{padding-right:20px}.markdown-body code{margin:0;padding:.2em .4em;font-size:85%;color:#666;color:var(--routine);background-color:#ebebeb;background-color:var(--classA);border-radius:3px}.markdown-body .highlight{margin-bottom:16px}.markdown-body .highlight pre{margin-bottom:0;word-break:normal}.markdown-body a:active,.markdown-body a:hover{outline-width:0}.markdown-body code,.markdown-content pre{font-family:monospace,monospace;font-size:1em}.markdown-body td,.markdown-body th{padding:0}.markdown-body h1,.markdown-body h2,.markdown-body h3,.markdown-body h4,.markdown-body h5,.markdown-body h6{margin-bottom:10px;margin-top:10px;font-weight:600;color:var(--classF)}.markdown-body h1,.markdown-body h2{font-weight:600;padding-bottom:.3em;line-height:1.25;border-bottom:1px solid var(--classE)}.markdown-body h4,.markdown-body h5,.markdown-body h6{line-height:1.2}.markdown-body ol,.markdown-body ul{margin-bottom:0;margin-top:0;padding-left:0;padding-left:2em;list-style:auto;color:var(--routine)}.markdown-body ol ol,.markdown-body ul ol{list-style-type:lower-roman}.markdown-body ol ol ol,.markdown-body ol ul ol,.markdown-body ul ol ol,.markdown-body ul ul ol{list-style-type:lower-alpha}.markdown-body code,.markdown-content pre{font-family:SFMono-Regular,Consolas,Liberation Mono,Menlo,Courier,monospace;font-size:12px}.markdown-body input::-webkit-inner-spin-button,.markdown-body input::-webkit-outer-spin-button{-webkit-appearance:none;appearance:none;margin:0}.markdown-body blockquote,.markdown-body dl,.markdown-body ol,.markdown-body p,.markdown-body pre,.markdown-body table,.markdown-body ul{margin-bottom:12px;margin-top:0}.markdown-body ul{list-style:disc}.markdown-body ol ol,.markdown-body ol ul,.markdown-body ul ol,.markdown-body ul ul{margin-bottom:0;margin-top:0}.markdown-body table td,.markdown-body table th{border:1px solid #dfe2e5;padding:6px 13px}.markdown-content .highlight pre,.markdown-content pre{font-size:85%;line-height:1.45;overflow:auto;padding:12px;background-color:#ebebeb;background-color:var(--classA);border-radius:3px}html body{--theme:#fb6c28;--scroll-bar:#c0c4cc;--loading-bar:var(--theme);font-family:Joe Font,Helvetica Neue,Helvetica,PingFang SC,Hiragino Sans GB,Microsoft YaHei,微软雅黑,Arial,"sans-serif"}html[data-mode=dark] body{--theme:#99f;--scroll-bar:#666;--loading-bar:var(--theme)}html.disable-scroll{height:100vh;overflow:hidden}::-webkit-scrollbar{width:6px;height:6px}::-webkit-scrollbar,::-webkit-scrollbar-track{background-color:#eee}::-webkit-scrollbar-thumb{background-color:var(--theme)}div{-webkit-transition:top .8s ease;transition:top .8s ease}.no-select{-webkit-touch-callout:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.halo-comment.halo-comment__admin .comment-admin-link{display:block!important}.halo-comment{font-family:Helvetica Neue,Helvetica,PingFang SC,Hiragino Sans GB,Microsoft YaHei,微软雅黑,Arial,sans-serif}.halo-comment a{text-decoration:none;color:var(--theme)}.halo-comment input::-webkit-input-placeholder,.halo-comment textarea::-webkit-input-placeholder{color:#ccc}.halo-comment button,.halo-comment input,.halo-comment textarea{box-sizing:border-box;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;-webkit-appearance:none;outline:none;-webkit-tap-highlight-color:rgba(0,0,0,0)}.halo-comment button:focus,.halo-comment input:focus,.halo-comment textarea:focus{outline:none}.halo-comment ol,.halo-comment ul{list-style:none}.halo-comment{position:relative;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:14px;font-weight:400;line-height:1.5;color:#313131;text-rendering:geometricPrecision;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;-webkit-box-sizing:content-box;box-sizing:content-box;-webkit-animation:main .6s;animation:main .6s}.halo-comment input[type=color],.halo-comment input[type=date],.halo-comment input[type=datetime-local],.halo-comment input[type=datetime],.halo-comment input[type=email],.halo-comment input[type=month],.halo-comment input[type=number],.halo-comment input[type=password],.halo-comment input[type=range],.halo-comment input[type=search],.halo-comment input[type=tel],.halo-comment input[type=text],.halo-comment input[type=time],.halo-comment input[type=url],.halo-comment input[type=week],.halo-comment textarea{color:#666;border:1px solid #ccc;border-radius:3px}.halo-comment .avatar{background-color:#f5f5f5}.halo-comment .comment-load-button{margin:30px 0;text-align:center}.halo-comment .comment-loader-container{-webkit-animation:top20 .5s;animation:top20 .5s;position:relative;text-align:center;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;margin:30px 0}.halo-comment .comment-loader-container .comment-loader-default{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:horizontal;-webkit-box-direction:normal;-ms-flex-flow:row nowrap;flex-flow:row nowrap;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;width:30px}.halo-comment .comment-loader-container .comment-loader-default span{width:4px;height:15px;background-color:#898c7b}.halo-comment .comment-loader-container .comment-loader-default span:first-of-type{-webkit-animation:grow 1s ease-in-out -.45s infinite;animation:grow 1s ease-in-out -.45s infinite}.halo-comment .comment-loader-container .comment-loader-default span:nth-of-type(2){-webkit-animation:grow 1s ease-in-out -.3s infinite;animation:grow 1s ease-in-out -.3s infinite}.halo-comment .comment-loader-container .comment-loader-default span:nth-of-type(3){-webkit-animation:grow 1s ease-in-out -.15s infinite;animation:grow 1s ease-in-out -.15s infinite}.halo-comment .comment-loader-container .comment-loader-default span:nth-of-type(4){-webkit-animation:grow 1s ease-in-out infinite;animation:grow 1s ease-in-out infinite}@-webkit-keyframes grow{0%,to{-webkit-transform:scaleY(1);transform:scaleY(1)}50%{-webkit-transform:scaleY(2);transform:scaleY(2)}}@keyframes grow{0%,to{-webkit-transform:scaleY(1);transform:scaleY(1)}50%{-webkit-transform:scaleY(2);transform:scaleY(2)}}.halo-comment .comment-loader-container .comment-loader-circle{border:3px solid #898c7b;border-top-color:#fff;border-radius:50%;width:2.5em;height:2.5em;-webkit-animation:spin .7s linear infinite;animation:spin .7s linear infinite}@-webkit-keyframes spin{to{-webkit-transform:rotate(1turn);transform:rotate(1turn)}}@keyframes spin{to{-webkit-transform:rotate(1turn);transform:rotate(1turn)}}.halo-comment .comment-loader-container .comment-loader-balls{width:3.5em;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:horizontal;-webkit-box-direction:normal;-ms-flex-flow:row nowrap;flex-flow:row nowrap;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between}.halo-comment .comment-loader-container .comment-loader-balls div{width:.7em;height:.7em;border-radius:50%;background-color:#898c7b;-webkit-transform:translateY(-100%);transform:translateY(-100%);-webkit-animation:wave .7s ease-in-out infinite alternate;animation:wave .7s ease-in-out infinite alternate}.halo-comment .comment-loader-container .comment-loader-balls div:first-of-type{-webkit-animation-delay:-.4s;animation-delay:-.4s}.halo-comment .comment-loader-container .comment-loader-balls div:nth-of-type(2){-webkit-animation-delay:-.2s;animation-delay:-.2s}.halo-comment .commentwrap{width:100%;margin:0 auto 10px;padding:0}.halo-comment .commentwrap .comment-wrp{padding:10px 0 16px 0;border-bottom:1px solid #ddd}.halo-comment .commentwrap .comment-wrp li{clear:both}.halo-comment .commentwrap .comment-wrp:first-child{padding-top:0}.halo-comment .commentwrap .comment-wrp:last-child{padding-bottom:0;border:none}.halo-comment .commentwrap .children{padding-left:40px;margin:0;clear:both}.halo-comment .commentwrap .children .comment-wrp:last-child{border:none}.halo-comment .commentwrap .children main{width:100%}.halo-comment .commentwrap .children .profile{float:left;margin-top:4px}.halo-comment .commentwrap .children .profile img{height:40px;width:40px}.halo-comment .commentwrap .children .children .children .children .children .children{margin:0;padding:0}@media screen and (max-width:500px){.halo-comment .commentwrap .children{padding-left:20px}}.halo-comment .comment{margin:0;padding:0;overflow:hidden;list-style:none}.halo-comment .comment .comment-reply-title{text-align:right}.halo-comment .comment .contents{width:100%;padding-top:10px;float:left}.halo-comment .comment .contents:hover .comment-admin-link,.halo-comment .comment .contents:hover .comment-reply-link{opacity:.9}.halo-comment .comment .main{float:right;width:100%;padding:0}.halo-comment .comment .main.shadow:hover img.avatar{-webkit-transform:rotate(1turn);transform:rotate(1turn)}.halo-comment .comment .main.shadow img.avatar{transform:rotate(0deg);-webkit-transform:rotate(0deg);-moz-transform:rotate(0deg);-o-transform:rotate(0deg);-ms-transform:rotate(0deg);transition:all 1s ease;-webkit-transition:all 1s ease;-moz-transition:all ease 1s;-o-transition:all ease 1s;-webkit-box-shadow:0 1px 10px -6px rgba(0,0,0,.5);box-shadow:0 1px 10px -6px rgba(0,0,0,.5)}.halo-comment .comment .profile{float:left;margin-right:10px;margin-top:6px}.halo-comment .comment .profile img{width:100%;max-width:40px;height:40px;border-radius:100%;-webkit-transition:opacity .15s ease-out;transition:opacity .15s ease-out}.halo-comment .comment .profile img:hover{opacity:.8}@media (max-width:880px){.halo-comment .comment .profile{display:none}}.halo-comment .comment .commeta{font-size:16px;margin-bottom:5px;text-transform:uppercase;color:#9499a8;margin-left:50px}.halo-comment .comment .commeta .bb-comment{position:relative;top:-1px;display:inline-block;min-width:30px;text-align:center;font-size:12px;color:#fb7299;font-weight:400;-webkit-transform:scale(.9);transform:scale(.9);border:1px solid #fb7299;border-radius:4px}.halo-comment .comment .commeta .comment-time{display:inline-block;margin-top:6px;font-size:12px;color:#657786}.halo-comment .comment .commeta .info{margin-top:2px;font-size:12px;letter-spacing:0;text-transform:none;color:rgba(0,0,0,.35)}.halo-comment .comment .commeta .info .useragent-info img{vertical-align:sub;width:14px;height:14px;border:0}@media (max-width:480px){.halo-comment .comment .commeta .info .useragent-info{display:none}}.halo-comment .comment .commeta .info .useragent-info-m{margin-top:2px;font-size:12px;letter-spacing:0;text-transform:none;color:rgba(0,0,0,.35);display:none}.halo-comment .comment .commeta .info .useragent-info-m img{vertical-align:sub;width:14px;height:14px;border:0}@media (max-width:480px){.halo-comment .comment .commeta .info .useragent-info-m{display:inline}}@media (max-width:880px){.halo-comment .comment .commeta{margin-left:0}}.halo-comment .comment .author{font-size:24px;font-weight:400;margin:0;letter-spacing:0;text-transform:none;line-height:20px}.halo-comment .comment .author a{color:var(--theme);font-size:14px;font-weight:600}.halo-comment .comment .author a:hover{color:var(--theme)}.halo-comment .comment .author img{display:none;border-radius:3px;margin-right:5px;vertical-align:-4px}@media (max-width:880px){.halo-comment .comment .author img{display:inline-block}}.halo-comment .comment .comment-admin-link,.halo-comment .comment .comment-reply-link{font-size:14px;display:block;margin-left:10px;float:right;text-transform:uppercase;color:#fff;background-color:var(--theme);line-height:20px;padding:2px 8px;border-radius:5px;opacity:0}.halo-comment .comment .comment-admin-link:hover,.halo-comment .comment .comment-reply-link:hover{opacity:1}.halo-comment .comment .comment-admin-link{display:none}@media (max-width:880px){.halo-comment .comment .comment-admin-link,.halo-comment .comment .comment-reply-link{opacity:1}}.halo-comment .comment .body{color:#63686d;position:relative}.halo-comment .comment .body>:last-child{margin-bottom:0}.halo-comment .comment .body p{font-size:14px;line-height:1.5;color:#63686d}.halo-comment .comment .body p a{position:relative;color:var(--theme)}.halo-comment .comment .body p a:after{content:"";position:absolute;width:100%;-webkit-transform:scaleX(0);transform:scaleX(0);height:2px;bottom:0;left:0;background-color:var(--theme);-webkit-transform-origin:bottom right;transform-origin:bottom right;-webkit-transition:-webkit-transform .25s ease-out;transition:-webkit-transform .25s ease-out;transition:transform .25s ease-out;transition:transform .25s ease-out,-webkit-transform .25s ease-out}.halo-comment .comment .body p a:hover:after{-webkit-transform:scaleX(1);transform:scaleX(1);-webkit-transform-origin:bottom left;transform-origin:bottom left}.halo-comment .comment .body p p{display:inline}@media (max-width:580px){.halo-comment .comment .body p{margin:0;font-size:13px;line-height:1.7}}.halo-comment .comment .body .comment-at{color:#99ce00;text-decoration:none}.halo-comment .comment .body .comment-at:after{bottom:-2px;background-color:#99ce00}.halo-comment .markdown-body{padding-left:50px;line-height:1;white-space:pre-line;word-break:break-all;font-size:14px!important}.halo-comment .markdown-body .markdown-content{padding:10px;white-space:pre-line;word-break:break-all;background:var(--sub-background);border-radius:0 8px 8px}.halo-comment .markdown-body img{max-width:100%}.halo-comment .markdown-body .emoji-item{display:inline-block;padding:0;overflow:hidden;color:#333;background-color:transparent}@media (max-width:860px){.halo-comment .markdown-body .emoji-item{-webkit-transform:scale(.8);transform:scale(.8)}}.halo-comment .markdown-body .emoji-item img{position:relative;top:-3px;display:block;max-width:100%;width:auto;height:26px;margin:2px auto 0;border:0}.halo-comment .markdown-body .emoji-item.text{width:auto;height:auto;padding:2px 6px;font-size:14px}.halo-comment .markdown-body .emoji-animate{position:relative;top:10px;width:32px;height:32px}.halo-comment .markdown-body .emoji-animate .img{width:32px;height:864px;max-width:32px;background:top/32px no-repeat;background-image:none;-webkit-animation:im-emotion-step 1.08s steps(27) infinite;animation:im-emotion-step 1.08s steps(27) infinite}.halo-comment .markdown-body .emoji-img{position:relative;top:4px;height:1.4em;max-height:1.4em}.halo-comment .markdown-body .comment_inline_img{cursor:pointer;display:inline-block;max-height:150px;margin-right:3px;padding:3px;background-color:#fff;border:1px solid var(--classC);border-radius:4px}@media screen and (max-width:880px){.halo-comment .markdown-body{padding-left:0}}.halo-comment .comment-editor{-webkit-box-sizing:border-box;box-sizing:border-box;margin:0 auto;-webkit-animation:top20 .5s;animation:top20 .5s}.halo-comment .comment-editor input:active,.halo-comment .comment-editor input:focus,.halo-comment .comment-editor textarea:active,.halo-comment .comment-editor textarea:focus{outline:0}.halo-comment .comment-editor input::-webkit-input-placeholder,.halo-comment .comment-editor textarea::-webkit-input-placeholder{color:#999}.halo-comment .comment-editor input::-moz-placeholder,.halo-comment .comment-editor textarea::-moz-placeholder{opacity:1;color:#999}.halo-comment .comment-editor input::-ms-input-placeholder,.halo-comment .comment-editor textarea::-ms-input-placeholder{color:#999}.halo-comment .comment-editor .cancel-comment-reply-link{background:#eee;border-radius:3px;padding:12px 25px;font-size:12px;color:#454545}.halo-comment .comment-editor .comment-form{outline:none}.halo-comment .comment-editor .comment-form input,.halo-comment .comment-editor .comment-form textarea{font-size:14px;width:31.3%;margin:0;padding:10px;color:#535a63;background-color:#f9f9f9;border:1px solid #ddd;}.halo-comment .comment-editor .comment-form textarea{resize:vertical;display:block;float:none;width:100%;height:180px;margin-bottom:10px;color:#535a63;background-image:url(https:\/\/cdn.jsdelivr.net/gh/drew233/cdn/20200409110727.webp);background-size:contain;background-repeat:no-repeat;background-position:right;background-color:rgba(255, 255, 255, 0)}.halo-comment .comment-editor .comment-form textarea:focus{border-color:var(--theme)}.halo-comment .comment-editor .comment-form input{width:100%}.halo-comment .comment-editor .comment-form input:last-of-type{margin-right:0}.halo-comment .comment-editor .comment-form input:focus{border-color:#ccc}.halo-comment .comment-editor .comment-form .comment-textarea{position:relative}.halo-comment .comment-editor .comment-form .comment-textarea .commentbody:focus{border-color:var(--theme);-webkit-transition:border-color .25s;transition:border-color .25s}.halo-comment .comment-editor .comment-form .comment-textarea .commentbody:placeholder-shown::-webkit-input-placeholder{color:transparent}.halo-comment .comment-editor .comment-form .comment-textarea .commentbody:placeholder-shown::-moz-placeholder{color:transparent}.halo-comment .comment-editor .comment-form .comment-textarea .commentbody:placeholder-shown:-ms-input-placeholder{color:transparent}.halo-comment .comment-editor .comment-form .comment-textarea .commentbody:placeholder-shown::-ms-input-placeholder{color:transparent}.halo-comment .comment-editor .comment-form .comment-textarea .commentbody:-moz-placeholder-shown::placeholder{color:transparent}.halo-comment .comment-editor .comment-form .comment-textarea .commentbody:-ms-input-placeholder::placeholder{color:transparent}.halo-comment .comment-editor .comment-form .comment-textarea .commentbody:placeholder-shown::placeholder{color:transparent}.halo-comment .comment-editor .comment-form .comment-textarea .commentbody:not(:-moz-placeholder-shown)~.input-label{color:#fff;background-color:var(--theme);transform:scale(.75) translate(-2px,-37px);border-radius:3px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:120%}.halo-comment .comment-editor .comment-form .comment-textarea .commentbody:not(:-ms-input-placeholder)~.input-label{color:#fff;background-color:var(--theme);transform:scale(.75) translate(-2px,-37px);border-radius:3px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:120%}.halo-comment .comment-editor .comment-form .comment-textarea .commentbody:focus~.input-label,.halo-comment .comment-editor .comment-form .comment-textarea .commentbody:not(:placeholder-shown)~.input-label{color:#fff;background-color:var(--theme);-webkit-transform:scale(.75) translate(-2px,-37px);transform:scale(.75) translate(-2px,-37px);border-radius:3px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:120%}.halo-comment .comment-editor .comment-form .comment-textarea .input-label{position:absolute;left:10px;top:10px;color:#666;padding:0 6px;-webkit-transform-origin:0 0;transform-origin:0 0;pointer-events:none;-webkit-transition:all .25s;transition:all .25s}.halo-comment .comment-editor .comment-form .comment-preview{position:relative;-webkit-box-sizing:border-box;box-sizing:border-box;display:block;float:none;width:100%;height:180px;margin:0 0 10px;padding:10px;white-space:pre-line;word-break:break-word;font-size:14px!important;line-height:1.5;overflow-y:auto;-webkit-box-shadow:none;box-shadow:none;color:#535a63;background:#f9f9f9;border:1px solid #ddd;border-radius:3px}.halo-comment .comment-editor .comment-form .comment-preview img{max-width:100%}.halo-comment .comment-editor .comment-form .author-info .commentator{position:absolute;display:inline-block;width:38px;height:38px;pointer-events:none;margin-top:10px}.halo-comment .comment-editor .comment-form .author-info .commentator img{width:100%;height:100%;border-radius:50%}.halo-comment .comment-editor .comment-form .author-info .commentator .socila-check{display:none;width:1.5em;height:1.5em;font-size:1em;line-height:1.5em;text-align:center;color:#fff;border-radius:50%;position:absolute;margin:-28px 0 0 42px}.halo-comment .comment-editor .comment-form .author-info .commentator .gravatar-check{background-color:#1e8cbe;-webkit-transform:rotate(270deg);transform:rotate(270deg)}.halo-comment .comment-editor .comment-form .author-info .commentator .qq-check{background-color:#99ce00}@media (max-width:625px){.halo-comment .comment-editor .comment-form .author-info .commentator{display:none}.halo-comment .comment-editor .comment-form .author-info .commentator .socila-check{width:1.5em;height:1.5em;font-size:.5em;line-height:1.5em;margin:-40% 0 0 77%}}.halo-comment .comment-editor .comment-form .author-info .cmt-popup{margin:0 0 10px 1%;-webkit-box-flex:1;-ms-flex:1;flex:1;--widthB:calc(var(--widthA) - 71px);--widthC:calc(var(--widthB)/3);width:var(--widthC);margin-top:10px}.halo-comment .comment-editor .comment-form .author-info .cmt-popup.cmt-author{margin-left:54px}@media (max-width:625px){.halo-comment .comment-editor .comment-form .author-info .cmt-popup{margin:0;width:100%;margin-top:15px}.halo-comment .comment-editor .comment-form .author-info .cmt-popup.cmt-author{margin-right:8px;margin-left:0}}@media (min-width:625px){.halo-comment .comment-editor .comment-form .author-info{width:100%;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:horizontal;-webkit-box-direction:normal;-ms-flex-flow:row nowrap;flex-flow:row nowrap;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;-webkit-box-align:stretch;-ms-flex-align:stretch;align-items:stretch}}.halo-comment .comment-editor .comment-form .comment-buttons{font-size:14px;text-align:right;margin-top:10px}.halo-comment .comment-editor .comment-form .comment-buttons .middle{display:inline-block;vertical-align:middle}.halo-comment .comment-editor .comment-form .comment-buttons .button-preview-edit,.halo-comment .comment-editor .comment-form .comment-buttons .button-submit{opacity:.9;display:inline-block;color:#fff;font-weight:500;padding:4px 16px;text-transform:uppercase;border:none;background:var(--theme);border-radius:4px;-webkit-animation:bottom20 .5s;animation:bottom20 .5s;-webkit-transition:all .3s ease 0s;transition:all .3s ease 0s}.halo-comment .comment-editor .comment-form .comment-buttons .button-preview-edit:hover,.halo-comment .comment-editor .comment-form .comment-buttons .button-submit:hover{opacity:1;font-weight:700;letter-spacing:3px;-webkit-box-shadow:0 5px 40px -10px rgba(0,0,0,.57);box-shadow:0 5px 40px -10px rgba(0,0,0,.57);-webkit-transition:all .3s ease 0s;transition:all .3s ease 0s}@media (max-width:1080px){.halo-comment .comment-editor input{width:100%;margin-bottom:14px}}.halo-comment .comment-empty{margin:30px 0;text-align:center;color:#999}.halo-comment .comment-page{padding-top:20px;text-align:center;border-top:3px solid var(--classD)}.halo-comment .comment-page .page{display:inline-block;padding:10px 0;margin:0}.halo-comment .comment-page .page li{display:inline;margin:0 3px;color:var(--main)}.halo-comment .comment-page .page button{position:relative;font-size:inherit;font-family:inherit;height:32px;padding:4px 10px;border-radius:4px;cursor:pointer;font-weight:400;color:var(--main);background-color:var(--sub-background);border:1px solid var(--classE)}.halo-comment .comment-page .page button svg{display:none;fill:var(--main)}.halo-comment .comment-page .page button:hover{color:var(--theme);border-color:var(--theme)}.halo-comment .comment-page .page button:hover svg{fill:var(--theme)}.halo-comment .comment-page .page button.prev-button:before{display:block;content:"上一页"}.halo-comment .comment-page .page button.next-button:before{display:block;content:"下一页"}.halo-comment .comment-page .page .active{color:var(--theme);border-color:var(--theme)}@media (max-width:500px){.halo-comment .comment-page .page button{height:32px;padding:4px 8px}.halo-comment .comment-page .page button.prev-button{position:relative;top:4px}.halo-comment .comment-page .page button.prev-button:before{display:none}.halo-comment .comment-page .page button.prev-button svg{display:block}.halo-comment .comment-page .page button.next-button{position:relative;top:4px}.halo-comment .comment-page .page button.next-button:before{display:none}.halo-comment .comment-page .page button.next-button svg{display:block}}.halo-comment.halo-comment__small .comment-wrp{padding:10px 0}.halo-comment.dark .avatar{background-color:#3e3e3e}.halo-comment.dark input::-webkit-input-placeholder,.halo-comment.dark textarea::-webkit-input-placeholder{color:#777}.halo-comment.dark input::-moz-placeholder,.halo-comment.dark textarea::-moz-placeholder{color:#777}.halo-comment.dark input::-ms-input-placeholder,.halo-comment.dark textarea::-ms-input-placeholder{color:#777}.halo-comment.dark .comment-editor .comment-textarea textarea{color:#b3b3b3;background:#2e2e2e;border-color:#555}.halo-comment.dark .comment-editor #emotion-toggle{color:#ccc}.halo-comment.dark .comment-editor .author-info input{color:#b3b3b3;background:#2e2e2e;border-color:#555}.halo-comment.dark .comment-wrp{border-color:#4e4e4e}.halo-comment.dark .comment-wrp .cancel-comment-reply-link{background:#c7c7c7}.halo-comment.dark .comment-wrp .commeta .comment-time,.halo-comment.dark .comment-wrp .commeta .info{color:#848484}.halo-comment.dark .comment-editor .comment-form .comment-preview{color:#b3b3b3;background:#2e2e2e;border-color:#555}.halo-comment.dark .comment-empty{color:#666}.halo-comment.dark .comment .body p{color:#999}#emotion-toggle{cursor:pointer;text-align:center;margin-bottom:5px}#container-emoji{background:var(--sub-background)}.emoji-fade-enter-active,.emoji-fade-leave-active{-webkit-transition:all .8s ease;transition:all .8s ease}.emoji-fade-enter,.emoji-fade-leave-to{opacity:0;-webkit-transform:translateY(-10px);transform:translateY(-10px)}.emotion-box{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:horizontal;-webkit-box-direction:normal;-ms-flex-direction:row;flex-direction:row;-ms-flex-wrap:wrap;flex-wrap:wrap}.emotion-box .category-enter,.emotion-box .category-leave-to{opacity:0}.emotion-box .category-enter-active,.emotion-box .category-leave-active{-webkit-transition:all .2s ease;transition:all .2s ease}.emotion-box .category-enter{-webkit-transform:translateX(10px);transform:translateX(10px)}.emotion-box .category-leave-to{-webkit-transform:translateX(-10px);transform:translateX(-10px)}.emotion-box .motion-switcher-table{border-collapse:collapse;width:100%;margin:0;table-layout:fixed}.emotion-box .motion-switcher-table tr{color:#e2e2e2;color:var(--classF)}.emotion-box .motion-switcher-table td,.emotion-box .motion-switcher-table th{cursor:pointer;padding:8px;text-align:center;border-radius:5px 5px 0 0}.emotion-box .motion-switcher-table th:hover{color:var(--theme)}.emotion-box .motion-switcher-table .on-hover{color:var(--theme);background-color:hsla(0,0%,96.1%,.5);background-color:var(--sub-background)}.emotion-box .motion-container{height:110px;overflow:auto;margin-bottom:5px;padding:6px 6px 0 16px;border-radius:0 0 5px 5px}.emotion-box .motion-container .emoji-item{cursor:pointer;display:inline-block;width:30px;height:30px;padding:3px;margin:3px;overflow:hidden;color:#333;color:var(--main);border-radius:4px}@media (max-width:860px){.emotion-box .motion-container .emoji-item{-webkit-transform:scale(.8);transform:scale(.8);margin-bottom:-10px}}.emotion-box .motion-container .emoji-item img{display:block;max-width:100%;width:auto;height:26px;margin:3px auto 0;border:0}.emotion-box .motion-container .emoji-item:hover{background-color:#e9e9e9;background-color:var(--classB)}.emotion-box .motion-container .emoji-item.text{width:auto;height:auto;padding:2px 6px;font-size:14px}.emotion-box .motion-container .emoji-animate,.emotion-box .motion-container .emotion-secter{width:32px;height:32px}.emotion-box .motion-container .emoji-animate .img,.emotion-box .motion-container .emotion-secter .img{width:32px;height:864px;max-width:32px;background:top/32px no-repeat;background-image:none;-webkit-animation:im-emotion-step 1.08s steps(27) infinite;animation:im-emotion-step 1.08s steps(27) infinite}@media (max-width:860px){.emotion-box .motion-container .emoji-animate,.emotion-box .motion-container .emotion-secter{-webkit-transform:scale(.8);transform:scale(.8);margin-bottom:-10px}}@media (max-width:860px){.emotion-box .motion-container.bilibili-container,.emotion-box .motion-container.haha-container,.emotion-box .motion-container.tieba-container{padding-left:0}}.emotion-box .motion-container.haha-container img{height:24px}.emotion-box .motion-container a{background-color:transparent;text-decoration:none;color:#e67474;outline:none;-webkit-transition:color .2s ease-out,border .2s ease-out,opacity .2s ease-out;transition:color .2s ease-out,border .2s ease-out,opacity .2s ease-out}.emotion-box .motion-container .emotion-select-parent{overflow:hidden;padding:1px 2px;background-size:32px auto;background-repeat:no-repeat;background-position:50%}.emotion-box .motion-container .emotion-select-parent:hover{background-image:none!important}.emotion-box .motion-container .emotion-select-parent:hover .emotion-select-child{display:block}.emotion-box .motion-container .emotion-select-child{display:none}.emotion-box .motion-container .emotion-secter{margin:12px 12px 0 0}@media (max-width:860px){.emotion-box .motion-container .emotion-secter{margin:0}.emotion-box .motion-container .emotion-secter .emotion-select-parent:hover{background-image:none!important;-webkit-transform:scale(.6);transform:scale(.6)}}.popup{position:relative;display:inline-block;cursor:pointer}.popup .popuptext{width:auto;padding:8px 10px;background-color:#555;color:#fff;text-align:center;border-radius:6px;position:absolute;z-index:1;bottom:110%;left:50%;margin-left:-80px}.popup .popuptext:after{content:"";position:absolute;top:100%;left:50%;margin-left:-5px;border-width:5px;border-style:solid;border-color:#555 transparent transparent}.popup .fade-enter-active,.popup .fade-enter-to{-webkit-transition:opacity 1s;transition:opacity 1s}.popup .fade-enter,.popup .fade-leave-to{opacity:0}.butterBar{position:fixed;text-align:center;top:0;left:0;right:0;width:100%;z-index:10000}.butterBar.butterBar-center{margin:auto}.butterBar .butterBar-message{background:#fe9600;color:#fff;border-bottom-left-radius:4px;border-bottom-right-radius:4px;display:inline-block;font-size:14px;margin-bottom:0;padding:12px 25px;z-index:10000;margin-top:-4px}@-webkit-keyframes main{0%{opacity:0;-webkit-transform:translateY(50px);transform:translateY(50px)}to{opacity:1;-webkit-transform:translateY(0);transform:translateY(0)}}@keyframes main{0%{opacity:0;-webkit-transform:translateY(50px);transform:translateY(50px)}to{opacity:1;-webkit-transform:translateY(0);transform:translateY(0)}}@-webkit-keyframes bottom20{0%{opacity:0;-webkit-transform:translateY(20px);transform:translateY(20px)}to{opacity:1;-webkit-transform:translateY(0);transform:translateY(0)}}@keyframes bottom20{0%{opacity:0;-webkit-transform:translateY(20px);transform:translateY(20px)}to{opacity:1;-webkit-transform:translateY(0);transform:translateY(0)}}@-webkit-keyframes wave{0%{-webkit-transform:translateY(-100%);transform:translateY(-100%)}to{-webkit-transform:translateY(100%);transform:translateY(100%)}}@keyframes wave{0%{-webkit-transform:translateY(-100%);transform:translateY(-100%)}to{-webkit-transform:translateY(100%);transform:translateY(100%)}}@-webkit-keyframes im-emotion-step{0%{-webkit-transform:translateY(0);transform:translateY(0)}to{-webkit-transform:translateY(-100%);transform:translateY(-100%)}}@keyframes im-emotion-step{0%{-webkit-transform:translateY(0);transform:translateY(0)}to{-webkit-transform:translateY(-100%);transform:translateY(-100%)}}@-webkit-keyframes top20{0%{opacity:0;-webkit-transform:translateY(-20px);transform:translateY(-20px)}to{opacity:1;-webkit-transform:translateY(0);transform:translateY(0)}}@keyframes top20{0%{opacity:0;-webkit-transform:translateY(-20px);transform:translateY(-20px)}to{opacity:1;-webkit-transform:translateY(0);transform:translateY(0)}}',
            ""]), e.exports = t
    },
    e683: function (e, t, n) {
        "use strict";
        e.exports = function (e, t) {
            return t ? e.replace(/\/+$/, "") + "/" + t.replace(/^\/+/, "") : e
        }
    },
    e7f9: function (e, t, n) {
        (function (t, n) {
            e.exports = n()
        })(0, (function () {
            "use strict";

            function e(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var o = t[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !
                        0), Object.defineProperty(e, o.key, o)
                }
            }

            function t(t, n, o) {
                return n && e(t.prototype, n), o && e(t, o), t
            }

            function n(e, t) {
                if (e) {
                    if ("string" === typeof e) return o(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n ||
                        "Set" === n ? Array.from(e) : "Arguments" === n ||
                        /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? o(e, t) : void 0
                }
            }

            function o(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, o = new Array(t); n < t; n++) o[n] = e[n];
                return o
            }

            function r(e) {
                var t = 0;
                if ("undefined" === typeof Symbol || null == e[Symbol.iterator]) {
                    if (Array.isArray(e) || (e = n(e))) return function () {
                        return t >= e.length ? {
                            done: !0
                        } : {
                            done: !1,
                            value: e[t++]
                        }
                    };
                    throw new TypeError(
                        "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
                    )
                }
                return t = e[Symbol.iterator](), t.next.bind(t)
            }

            function i(e, t) {
                return t = {
                    exports: {}
                }, e(t, t.exports), t.exports
            }
            var a = i((function (e) {
                    function t() {
                        return {
                            baseUrl: null,
                            breaks: !1,
                            gfm: !0,
                            headerIds: !0,
                            headerPrefix: "",
                            highlight: null,
                            langPrefix: "language-",
                            mangle: !0,
                            pedantic: !1,
                            renderer: null,
                            sanitize: !1,
                            sanitizer: null,
                            silent: !1,
                            smartLists: !1,
                            smartypants: !1,
                            tokenizer: null,
                            walkTokens: null,
                            xhtml: !1,
                            bilibiliEmojiUrl: "https://cdn.jsdelivr.net/gh/qinhua/cdn_assets@master/comment/emoji/bili/",
                            tiebaEmojiUrl: "https://cdn.jsdelivr.net/gh/qinhua/cdn_assets@master/comment/emoji/smilies/",
                            hahaEmojiUrl: "https://cdn.jsdelivr.net/gh/qinhua/cdn_assets@master/comment/emoji/haha/"
                        }
                    }

                    function n(t) {
                        e.exports.defaults = t
                    }
                    e.exports = {
                        defaults: t(),
                        getDefaults: t,
                        changeDefaults: n
                    }
                })),
                s = (a.defaults, a.getDefaults, a.changeDefaults, /[&<>"']/),
                c = /[&<>"']/g,
                l = /[<>"']|&(?!#?\w+;)/,
                u = /[<>"']|&(?!#?\w+;)/g,
                m = {
                    "&": "&amp;",
                    "<": "&lt;",
                    ">": "&gt;",
                    '"': "&quot;",
                    "'": "&#39;"
                },
                p = function (e) {
                    return m[e]
                };

            function d(e, t) {
                if (t) {
                    if (s.test(e)) return e.replace(c, p)
                } else if (l.test(e)) return e.replace(u, p);
                return e
            }
            var h = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/gi;

            function f(e) {
                return e.replace(h, (function (e, t) {
                    return t = t.toLowerCase(), "colon" === t ? ":" : "#" === t.charAt(0) ?
                        "x" === t.charAt(1) ? String.fromCharCode(parseInt(t.substring(2),
                            16)) : String.fromCharCode(+t.substring(1)) : ""
                }))
            }
            var b = /(^|[^\[])\^/g;

            function g(e, t) {
                e = e.source || e, t = t || "";
                var n = {
                    replace: function (t, o) {
                        return o = o.source || o, o = o.replace(b, "$1"), e = e.replace(t, o),
                            n
                    },
                    getRegex: function () {
                        return new RegExp(e, t)
                    }
                };
                return n
            }
            var y = /[^\w:]/g,
                w = /^$|^[a-z][a-z0-9+.-]*:|^[?#]/i;

            function v(e, t, n) {
                if (e) {
                    var o;
                    try {
                        o = decodeURIComponent(f(n)).replace(y, "").toLowerCase()
                    } catch (r) {
                        return null
                    }
                    if (0 === o.indexOf("javascript:") || 0 === o.indexOf("vbscript:") || 0 === o.indexOf(
                            "data:")) return null
                }
                t && !w.test(n) && (n = _(t, n));
                try {
                    n = encodeURI(n).replace(/%25/g, "%")
                } catch (r) {
                    return null
                }
                return n
            }
            var x = {},
                k = /^[^:]+:\/*[^/]*$/,
                j = /^([^:]+:)[\s\S]*$/,
                S = /^([^:]+:\/*[^/]*)[\s\S]*$/;

            function _(e, t) {
                x[" " + e] || (k.test(e) ? x[" " + e] = e + "/" : x[" " + e] = O(e, "/", !0)), e = x[
                    " " + e];
                var n = -1 === e.indexOf(":");
                return "//" === t.substring(0, 2) ? n ? t : e.replace(j, "$1") + t : "/" === t.charAt(0) ?
                    n ? t : e.replace(S, "$1") + t : e + t
            }
            var A = {
                exec: function () {}
            };

            function C(e) {
                for (var t, n, o = 1; o < arguments.length; o++)
                    for (n in t = arguments[o], t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] =
                        t[n]);
                return e
            }

            function E(e, t) {
                var n = e.replace(/\|/g, (function (e, t, n) {
                        var o = !1,
                            r = t;
                        while (--r >= 0 && "\\" === n[r]) o = !o;
                        return o ? "|" : " |"
                    })),
                    o = n.split(/ \|/),
                    r = 0;
                if (o.length > t) o.splice(t);
                else
                    while (o.length < t) o.push("");
                for (; r < o.length; r++) o[r] = o[r].trim().replace(/\\\|/g, "|");
                return o
            }

            function O(e, t, n) {
                var o = e.length;
                if (0 === o) return "";
                var r = 0;
                while (r < o) {
                    var i = e.charAt(o - r - 1);
                    if (i !== t || n) {
                        if (i === t || !n) break;
                        r++
                    } else r++
                }
                return e.substr(0, o - r)
            }

            function z(e, t) {
                if (-1 === e.indexOf(t[1])) return -1;
                for (var n = e.length, o = 0, r = 0; r < n; r++)
                    if ("\\" === e[r]) r++;
                    else if (e[r] === t[0]) o++;
                else if (e[r] === t[1] && (o--, o < 0)) return r;
                return -1
            }

            function P(e) {
                e && e.sanitize && !e.silent && console.warn(
                    "marked(): sanitize and sanitizer parameters are deprecated since version 0.7.0, should not be used and will be removed in the future. Read more here: https://marked.js.org/#/USING_ADVANCED.md#options"
                )
            }
            var T = {
                    escape: d,
                    unescape: f,
                    edit: g,
                    cleanUrl: v,
                    resolveUrl: _,
                    noopTest: A,
                    merge: C,
                    splitCells: E,
                    rtrim: O,
                    findClosingBracket: z,
                    checkSanitizeDeprecation: P
                },
                I = a.defaults,
                $ = T.rtrim,
                R = T.splitCells,
                N = T.escape,
                q = T.findClosingBracket;

            function L(e, t, n) {
                var o = t.href,
                    r = t.title ? N(t.title) : null,
                    i = e[1].replace(/\\([\[\]])/g, "$1");
                return "!" !== e[0].charAt(0) ? {
                    type: "link",
                    raw: n,
                    href: o,
                    title: r,
                    text: i
                } : {
                    type: "image",
                    raw: n,
                    href: o,
                    title: r,
                    text: N(i)
                }
            }

            function U(e, t) {
                var n = e.match(/^(\s+)(?:```)/);
                if (null === n) return t;
                var o = n[1];
                return t.split("\n").map((function (e) {
                    var t = e.match(/^\s+/);
                    if (null === t) return e;
                    var n = t[0];
                    return n.length >= o.length ? e.slice(o.length) : e
                })).join("\n")
            }
            var D = function () {
                    function e(e) {
                        this.options = e || I
                    }
                    var t = e.prototype;
                    return t.bilibiliEmoji = function (e) {
                        var t = this.rules.inline.bilibiliEmoji.exec(e);
                        if (t && t[0].length > 1) return {
                            type: "bilibiliEmoji",
                            raw: t[0],
                            text: t[1]
                        }
                    }, t.textEmoji = function (e) {
                        var t = this.rules.inline.textEmoji.exec(e);
                        if (t && t[0].length > 1) return {
                            type: "textEmoji",
                            raw: t[0],
                            text: t[1]
                        }
                    }, t.codeEmoji = function (e) {
                        var t = this.rules.inline.codeEmoji.exec(e);
                        if (t && t[0].length > 1) return {
                            type: "codeEmoji",
                            raw: t[0],
                            text: t[1]
                        }
                    }, t.space = function (e) {
                        var t = this.rules.block.newline.exec(e);
                        if (t) return t[0].length > 1 ? {
                            type: "space",
                            raw: t[0]
                        } : {
                            raw: "\n"
                        }
                    }, t.code = function (e, t) {
                        var n = this.rules.block.code.exec(e);
                        if (n) {
                            var o = t[t.length - 1];
                            if (o && "paragraph" === o.type) return {
                                raw: n[0],
                                text: n[0].trimRight()
                            };
                            var r = n[0].replace(/^ {4}/gm, "");
                            return {
                                type: "code",
                                raw: n[0],
                                codeBlockStyle: "indented",
                                text: this.options.pedantic ? r : $(r, "\n")
                            }
                        }
                    }, t.fences = function (e) {
                        var t = this.rules.block.fences.exec(e);
                        if (t) {
                            var n = t[0],
                                o = U(n, t[3] || "");
                            return {
                                type: "code",
                                raw: n,
                                lang: t[2] ? t[2].trim() : t[2],
                                text: o
                            }
                        }
                    }, t.heading = function (e) {
                        var t = this.rules.block.heading.exec(e);
                        if (t) return {
                            type: "heading",
                            raw: t[0],
                            depth: t[1].length,
                            text: t[2]
                        }
                    }, t.nptable = function (e) {
                        var t = this.rules.block.nptable.exec(e);
                        if (t) {
                            var n = {
                                type: "table",
                                header: R(t[1].replace(/^ *| *\| *$/g, "")),
                                align: t[2].replace(/^ *|\| *$/g, "").split(/ *\| */),
                                cells: t[3] ? t[3].replace(/\n$/, "").split("\n") : [],
                                raw: t[0]
                            };
                            if (n.header.length === n.align.length) {
                                var o, r = n.align.length;
                                for (o = 0; o < r; o++) /^ *-+: *$/.test(n.align[o]) ? n.align[o] =
                                    "right" : /^ *:-+: *$/.test(n.align[o]) ? n.align[o] = "center" :
                                    /^ *:-+ *$/.test(n.align[o]) ? n.align[o] = "left" : n.align[o] =
                                    null;
                                for (r = n.cells.length, o = 0; o < r; o++) n.cells[o] = R(n.cells[
                                    o], n.header.length);
                                return n
                            }
                        }
                    }, t.hr = function (e) {
                        var t = this.rules.block.hr.exec(e);
                        if (t) return {
                            type: "hr",
                            raw: t[0]
                        }
                    }, t.blockquote = function (e) {
                        var t = this.rules.block.blockquote.exec(e);
                        if (t) {
                            var n = t[0].replace(/^ *> ?/gm, "");
                            return {
                                type: "blockquote",
                                raw: t[0],
                                text: n
                            }
                        }
                    }, t.list = function (e) {
                        var t = this.rules.block.list.exec(e);
                        if (t) {
                            for (var n, o, r, i, a, s, c, l = t[0], u = t[2], m = u.length > 1, p =
                                    ")" === u[u.length - 1], d = {
                                        type: "list",
                                        raw: l,
                                        ordered: m,
                                        start: m ? +u.slice(0, -1) : "",
                                        loose: !1,
                                        items: []
                                    }, h = t[0].match(this.rules.block.item), f = !1, b = h.length,
                                    g = 0; g < b; g++) n = h[g], l = n, o = n.length, n = n.replace(
                                /^ *([*+-]|\d+[.)]) */, ""), ~n.indexOf("\n ") && (o -= n.length,
                                n = this.options.pedantic ? n.replace(/^ {1,4}/gm, "") : n.replace(
                                    new RegExp("^ {1," + o + "}", "gm"), "")), g !== b - 1 && (
                                r = this.rules.block.bullet.exec(h[g + 1])[0], (m ? 1 === r.length ||
                                    !p && ")" === r[r.length - 1] : r.length > 1 || this.options
                                    .smartLists && r !== u) && (i = h.slice(g + 1).join("\n"),
                                    d.raw = d.raw.substring(0, d.raw.length - i.length), g = b -
                                    1)), a = f || /\n\n(?!\s*$)/.test(n), g !== b - 1 && (f =
                                "\n" === n.charAt(n.length - 1), a || (a = f)), a && (d.loose = !
                                0), s = /^\[[ xX]\] /.test(n), c = void 0, s && (c = " " !== n[
                                1], n = n.replace(/^\[[ xX]\] +/, "")), d.items.push({
                                type: "list_item",
                                raw: l,
                                task: s,
                                checked: c,
                                loose: a,
                                text: n
                            });
                            return d
                        }
                    }, t.html = function (e) {
                        var t = this.rules.block.html.exec(e);
                        if (t) return {
                            type: this.options.sanitize ? "paragraph" : "html",
                            raw: t[0],
                            pre: !this.options.sanitizer && ("pre" === t[1] || "script" === t[1] ||
                                "style" === t[1]),
                            text: this.options.sanitize ? this.options.sanitizer ? this.options
                                .sanitizer(t[0]) : N(t[0]) : t[0]
                        }
                    }, t.def = function (e) {
                        var t = this.rules.block.def.exec(e);
                        if (t) {
                            t[3] && (t[3] = t[3].substring(1, t[3].length - 1));
                            var n = t[1].toLowerCase().replace(/\s+/g, " ");
                            return {
                                tag: n,
                                raw: t[0],
                                href: t[2],
                                title: t[3]
                            }
                        }
                    }, t.table = function (e) {
                        var t = this.rules.block.table.exec(e);
                        if (t) {
                            var n = {
                                type: "table",
                                header: R(t[1].replace(/^ *| *\| *$/g, "")),
                                align: t[2].replace(/^ *|\| *$/g, "").split(/ *\| */),
                                cells: t[3] ? t[3].replace(/\n$/, "").split("\n") : []
                            };
                            if (n.header.length === n.align.length) {
                                n.raw = t[0];
                                var o, r = n.align.length;
                                for (o = 0; o < r; o++) /^ *-+: *$/.test(n.align[o]) ? n.align[o] =
                                    "right" : /^ *:-+: *$/.test(n.align[o]) ? n.align[o] = "center" :
                                    /^ *:-+ *$/.test(n.align[o]) ? n.align[o] = "left" : n.align[o] =
                                    null;
                                for (r = n.cells.length, o = 0; o < r; o++) n.cells[o] = R(n.cells[
                                    o].replace(/^ *\| *| *\| *$/g, ""), n.header.length);
                                return n
                            }
                        }
                    }, t.lheading = function (e) {
                        var t = this.rules.block.lheading.exec(e);
                        if (t) return {
                            type: "heading",
                            raw: t[0],
                            depth: "=" === t[2].charAt(0) ? 1 : 2,
                            text: t[1]
                        }
                    }, t.paragraph = function (e) {
                        var t = this.rules.block.paragraph.exec(e);
                        if (t) return {
                            type: "paragraph",
                            raw: t[0],
                            text: "\n" === t[1].charAt(t[1].length - 1) ? t[1].slice(0, -1) : t[
                                1]
                        }
                    }, t.text = function (e, t) {
                        var n = this.rules.block.text.exec(e);
                        if (n) {
                            var o = t[t.length - 1];
                            return o && "text" === o.type ? {
                                raw: n[0],
                                text: n[0]
                            } : {
                                type: "text",
                                raw: n[0],
                                text: n[0]
                            }
                        }
                    }, t.escape = function (e) {
                        var t = this.rules.inline.escape.exec(e);
                        if (t) return {
                            type: "escape",
                            raw: t[0],
                            text: N(t[1])
                        }
                    }, t.tag = function (e, t, n) {
                        var o = this.rules.inline.tag.exec(e);
                        if (o) return !t && /^<a /i.test(o[0]) ? t = !0 : t && /^<\/a>/i.test(o[0]) &&
                            (t = !1), !n && /^<(pre|code|kbd|script)(\s|>)/i.test(o[0]) ? n = !
                            0 : n && /^<\/(pre|code|kbd|script)(\s|>)/i.test(o[0]) && (n = !1), {
                                type: this.options.sanitize ? "text" : "html",
                                raw: o[0],
                                inLink: t,
                                inRawBlock: n,
                                text: this.options.sanitize ? this.options.sanitizer ? this.options
                                    .sanitizer(o[0]) : N(o[0]) : o[0]
                            }
                    }, t.link = function (e) {
                        var t = this.rules.inline.link.exec(e);
                        if (t) {
                            var n = q(t[2], "()");
                            if (n > -1) {
                                var o = 0 === t[0].indexOf("!") ? 5 : 4,
                                    r = o + t[1].length + n;
                                t[2] = t[2].substring(0, n), t[0] = t[0].substring(0, r).trim(), t[
                                    3] = ""
                            }
                            var i = t[2],
                                a = "";
                            if (this.options.pedantic) {
                                var s = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(i);
                                s ? (i = s[1], a = s[3]) : a = ""
                            } else a = t[3] ? t[3].slice(1, -1) : "";
                            i = i.trim().replace(/^<([\s\S]*)>$/, "$1");
                            var c = L(t, {
                                href: i ? i.replace(this.rules.inline._escapes, "$1") : i,
                                title: a ? a.replace(this.rules.inline._escapes, "$1") : a
                            }, t[0]);
                            return c
                        }
                    }, t.reflink = function (e, t) {
                        var n;
                        if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink
                                .exec(e))) {
                            var o = (n[2] || n[1]).replace(/\s+/g, " ");
                            if (o = t[o.toLowerCase()], !o || !o.href) {
                                var r = n[0].charAt(0);
                                return {
                                    type: "text",
                                    raw: r,
                                    text: r
                                }
                            }
                            var i = L(n, o, n[0]);
                            return i
                        }
                    }, t.strong = function (e) {
                        var t = this.rules.inline.strong.exec(e);
                        if (t) return {
                            type: "strong",
                            raw: t[0],
                            text: t[4] || t[3] || t[2] || t[1]
                        }
                    }, t.em = function (e) {
                        var t = this.rules.inline.em.exec(e);
                        if (t) return {
                            type: "em",
                            raw: t[0],
                            text: t[6] || t[5] || t[4] || t[3] || t[2] || t[1]
                        }
                    }, t.codespan = function (e) {
                        var t = this.rules.inline.code.exec(e);
                        if (t) {
                            var n = t[2].replace(/\n/g, " "),
                                o = /[^ ]/.test(n),
                                r = n.startsWith(" ") && n.endsWith(" ");
                            return o && r && (n = n.substring(1, n.length - 1)), n = N(n, !0), {
                                type: "codespan",
                                raw: t[0],
                                text: n
                            }
                        }
                    }, t.br = function (e) {
                        var t = this.rules.inline.br.exec(e);
                        if (t) return {
                            type: "br",
                            raw: t[0]
                        }
                    }, t.del = function (e) {
                        var t = this.rules.inline.del.exec(e);
                        if (t) return {
                            type: "del",
                            raw: t[0],
                            text: t[1]
                        }
                    }, t.autolink = function (e, t) {
                        var n, o, r = this.rules.inline.autolink.exec(e);
                        if (r) return "@" === r[2] ? (n = N(this.options.mangle ? t(r[1]) : r[1]),
                            o = "mailto:" + n) : (n = N(r[1]), o = n), {
                            type: "link",
                            raw: r[0],
                            text: n,
                            href: o,
                            tokens: [{
                                type: "text",
                                raw: n,
                                text: n
                            }]
                        }
                    }, t.url = function (e, t) {
                        var n;
                        if (n = this.rules.inline.url.exec(e)) {
                            var o, r;
                            if ("@" === n[2]) o = N(this.options.mangle ? t(n[0]) : n[0]), r =
                                "mailto:" + o;
                            else {
                                var i;
                                do {
                                    i = n[0], n[0] = this.rules.inline._backpedal.exec(n[0])[0]
                                } while (i !== n[0]);
                                o = N(n[0]), r = "www." === n[1] ? "http://" + o : o
                            }
                            return {
                                type: "link",
                                raw: n[0],
                                text: o,
                                href: r,
                                tokens: [{
                                    type: "text",
                                    raw: o,
                                    text: o
                                }]
                            }
                        }
                    }, t.inlineText = function (e, t, n) {
                        var o, r = this.rules.inline.text.exec(e);
                        if (r) return o = t ? this.options.sanitize ? this.options.sanitizer ? this
                            .options.sanitizer(r[0]) : N(r[0]) : r[0] : N(this.options.smartypants ?
                                n(r[0]) : r[0]), {
                                type: "text",
                                raw: r[0],
                                text: o
                            }
                    }, e
                }(),
                B = T.noopTest,
                M = T.edit,
                F = T.merge,
                Y = {
                    newline: /^\n+/,
                    code: /^( {4}[^\n]+\n*)+/,
                    fences: /^ {0,3}(`{3,}(?=[^`\n]*\n)|~{3,})([^\n]*)\n(?:|([\s\S]*?)\n)(?: {0,3}\1[~`]* *(?:\n+|$)|$)/,
                    hr: /^ {0,3}((?:- *){3,}|(?:_ *){3,}|(?:\* *){3,})(?:\n+|$)/,
                    heading: /^ {0,3}(#{1,6}) +([^\n]*?)(?: +#+)? *(?:\n+|$)/,
                    blockquote: /^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/,
                    list: /^( {0,3})(bull) [\s\S]+?(?:hr|def|\n{2,}(?! )(?!\1bull )\n*|\s*$)/,
                    html: "^ {0,3}(?:<(script|pre|style)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?\\?>\\n*|<![A-Z][\\s\\S]*?>\\n*|<!\\[CDATA\\[[\\s\\S]*?\\]\\]>\\n*|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:\\n{2,}|$)|<(?!script|pre|style)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:\\n{2,}|$)|</(?!script|pre|style)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:\\n{2,}|$))",
                    def: /^ {0,3}\[(label)\]: *\n? *<?([^\s>]+)>?(?:(?: +\n? *| *\n *)(title))? *(?:\n+|$)/,
                    nptable: B,
                    table: B,
                    lheading: /^([^\n]+)\n {0,3}(=+|-+) *(?:\n+|$)/,
                    _paragraph: /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html)[^\n]+)*)/,
                    text: /^[^\n]+/,
                    _label: /(?!\s*\])(?:\\[\[\]]|[^\[\]])+/,
                    _title: /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/
                };
            Y.def = M(Y.def).replace("label", Y._label).replace("title", Y._title).getRegex(), Y.bullet =
                /(?:[*+-]|\d{1,9}[.)])/, Y.item = /^( *)(bull) ?[^\n]*(?:\n(?!\1bull ?)[^\n]*)*/, Y.item =
                M(Y.item, "gm").replace(/bull/g, Y.bullet).getRegex(), Y.list = M(Y.list).replace(
                    /bull/g, Y.bullet).replace("hr",
                    "\\n+(?=\\1?(?:(?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$))").replace("def",
                    "\\n+(?=" + Y.def.source + ")").getRegex(), Y._tag =
                "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|section|source|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul",
                Y._comment = /<!--(?!-?>)[\s\S]*?-->/, Y.html = M(Y.html, "i").replace("comment", Y._comment)
                .replace("tag", Y._tag).replace("attribute",
                    / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(),
                Y.paragraph = M(Y._paragraph).replace("hr", Y.hr).replace("heading", " {0,3}#{1,6} ").replace(
                    "|lheading", "").replace("blockquote", " {0,3}>").replace("fences",
                    " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list",
                    " {0,3}(?:[*+-]|1[.)]) ").replace("html",
                    "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|!--)").replace("tag", Y._tag).getRegex(),
                Y.blockquote = M(Y.blockquote).replace("paragraph", Y.paragraph).getRegex(), Y.normal =
                F({}, Y), Y.gfm = F({}, Y.normal, {
                    nptable: "^ *([^|\\n ].*\\|.*)\\n *([-:]+ *\\|[-| :]*)(?:\\n((?:(?!\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)",
                    table: "^ *\\|(.+)\\n *\\|?( *[-:]+[-| :]*)(?:\\n *((?:(?!\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)"
                }), Y.gfm.nptable = M(Y.gfm.nptable).replace("hr", Y.hr).replace("heading",
                    " {0,3}#{1,6} ").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace(
                    "fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list",
                    " {0,3}(?:[*+-]|1[.)]) ").replace("html",
                    "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|!--)").replace("tag", Y._tag).getRegex(),
                Y.gfm.table = M(Y.gfm.table).replace("hr", Y.hr).replace("heading", " {0,3}#{1,6} ").replace(
                    "blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences",
                    " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list",
                    " {0,3}(?:[*+-]|1[.)]) ").replace("html",
                    "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|!--)").replace("tag", Y._tag).getRegex(),
                Y.pedantic = F({}, Y.normal, {
                    html: M(
                        "^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:\"[^\"]*\"|'[^']*'|\\s[^'\"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))"
                    ).replace("comment", Y._comment).replace(/tag/g,
                        "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b"
                    ).getRegex(),
                    def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
                    heading: /^ *(#{1,6}) *([^\n]+?) *(?:#+ *)?(?:\n+|$)/,
                    fences: B,
                    paragraph: M(Y.normal._paragraph).replace("hr", Y.hr).replace("heading",
                        " *#{1,6} *[^\n]").replace("lheading", Y.lheading).replace("blockquote",
                        " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html",
                        "").getRegex()
                });
            var H = {
                bilibiliEmoji: /^f\(x\)=∫\(([^A-Z]\w+?)\)sec²xdx/,
                textEmoji: /^`([^a-zA-Z]+?)`/,
                codeEmoji: /^:([^A-Z]\w+!?):/,
                escape: /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/,
                autolink: /^<(scheme:[^\s\x00-\x1f<>]*|email)>/,
                url: B,
                tag: "^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>",
                link: /^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/,
                reflink: /^!?\[(label)\]\[(?!\s*\])((?:\\[\[\]]?|[^\[\]\\])+)\]/,
                nolink: /^!?\[(?!\s*\])((?:\[[^\[\]]*\]|\\[\[\]]|[^\[\]])*)\](?:\[\])?/,
                strong: /^__([^\s_])__(?!_)|^\*\*([^\s*])\*\*(?!\*)|^__([^\s][\s\S]*?[^\s])__(?!_)|^\*\*([^\s][\s\S]*?[^\s])\*\*(?!\*)/,
                em: /^_([^\s_])_(?!_)|^_([^\s_<][\s\S]*?[^\s_])_(?!_|[^\s,punctuation])|^_([^\s_<][\s\S]*?[^\s])_(?!_|[^\s,punctuation])|^\*([^\s*<\[])\*(?!\*)|^\*([^\s<"][\s\S]*?[^\s\[\*])\*(?![\]`punctuation])|^\*([^\s*"<\[][\s\S]*[^\s])\*(?!\*)/,
                code: /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/,
                br: /^( {2,}|\\)\n(?!\s*$)/,
                del: B,
                text: /^(`+|[^`])(?:[\s\S]*?(?:(?=[\\<!\[`:f*]|\b_|$)|[^ ](?= {2,}\n))|(?= {2,}\n))/,
                _punctuation: "!\"#$%&'()*+\\-./:;<=>?@\\[^_{|}~"
            };
            H.em = M(H.em).replace(/punctuation/g, H._punctuation).getRegex(), H._escapes =
                /\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/g, H._scheme =
                /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/, H._email =
                /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/,
                H.autolink = M(H.autolink).replace("scheme", H._scheme).replace("email", H._email).getRegex(),
                H._attribute =
                /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/, H.tag =
                M(H.tag).replace("comment", Y._comment).replace("attribute", H._attribute).getRegex(),
                H._label = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, H._href =
                /<(?:\\[<>]?|[^\s<>\\])*>|[^\s\x00-\x1f]*/, H._title =
                /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/, H.link = M(H.link).replace(
                    "label", H._label).replace("href", H._href).replace("title", H._title).getRegex(),
                H.reflink = M(H.reflink).replace("label", H._label).getRegex(), H.normal = F({}, H), H.pedantic =
                F({}, H.normal, {
                    strong: /^__(?=\S)([\s\S]*?\S)__(?!_)|^\*\*(?=\S)([\s\S]*?\S)\*\*(?!\*)/,
                    em: /^_(?=\S)([\s\S]*?\S)_(?!_)|^\*(?=\S)([\s\S]*?\S)\*(?!\*)/,
                    link: M(/^!?\[(label)\]\((.*?)\)/).replace("label", H._label).getRegex(),
                    reflink: M(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", H._label).getRegex()
                }), H.gfm = F({}, H.normal, {
                    escape: M(H.escape).replace("])", "~|])").getRegex(),
                    _extended_email: /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/,
                    url: /^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/,
                    _backpedal: /(?:[^?!.,:;*_~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_~)]+(?!$))+/,
                    del: /^~+(?=\S)([\s\S]*?\S)~+/,
                    text: /^(`+|[^`])(?:[\s\S]*?(?:(?=[\\<!\[`:f*~]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@))|(?= {2,}\n|[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@))/
                }), H.gfm.url = M(H.gfm.url, "i").replace("email", H.gfm._extended_email).getRegex(), H
                .breaks = F({}, H.gfm, {
                    br: M(H.br).replace("{2,}", "*").getRegex(),
                    text: M(H.gfm.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
                });
            var W = {
                    block: Y,
                    inline: H
                },
                V = a.defaults,
                G = W.block,
                Q = W.inline;

            function J(e) {
                return e.replace(/---/g, "—").replace(/--/g, "–").replace(/(^|[-\u2014/(\[{"\s])'/g,
                    "$1‘").replace(/'/g, "’").replace(/(^|[-\u2014/(\[{\u2018\s])"/g, "$1“").replace(
                    /"/g, "”").replace(/\.{3}/g, "…")
            }

            function Z(e) {
                var t, n, o = "",
                    r = e.length;
                for (t = 0; t < r; t++) n = e.charCodeAt(t), Math.random() > .5 && (n = "x" + n.toString(
                    16)), o += "&#" + n + ";";
                return o
            }
            var X = function () {
                    function e(e) {
                        this.tokens = [], this.tokens.links = Object.create(null), this.options = e ||
                            V, this.options.tokenizer = this.options.tokenizer || new D, this.tokenizer =
                            this.options.tokenizer, this.tokenizer.options = this.options;
                        var t = {
                            block: G.normal,
                            inline: Q.normal
                        };
                        this.options.pedantic ? (t.block = G.pedantic, t.inline = Q.pedantic) : this.options
                            .gfm && (t.block = G.gfm, this.options.breaks ? t.inline = Q.breaks : t.inline =
                                Q.gfm), this.tokenizer.rules = t
                    }
                    e.lex = function (t, n) {
                        var o = new e(n);
                        return o.lex(t)
                    };
                    var n = e.prototype;
                    return n.lex = function (e) {
                        return e = e.replace(/\r\n|\r/g, "\n").replace(/\t/g, "    "), this.blockTokens(
                            e, this.tokens, !0), this.inline(this.tokens), this.tokens
                    }, n.blockTokens = function (e, t, n) {
                        var o, r, i, a;
                        void 0 === t && (t = []), void 0 === n && (n = !0), e = e.replace(/^ +$/gm,
                            "");
                        while (e)
                            if (o = this.tokenizer.space(e)) e = e.substring(o.raw.length), o.type &&
                                t.push(o);
                            else if (o = this.tokenizer.code(e, t)) e = e.substring(o.raw.length),
                            o.type ? t.push(o) : (a = t[t.length - 1], a.raw += "\n" + o.raw, a.text +=
                                "\n" + o.text);
                        else if (o = this.tokenizer.fences(e)) e = e.substring(o.raw.length), t.push(
                            o);
                        else if (o = this.tokenizer.heading(e)) e = e.substring(o.raw.length), t.push(
                            o);
                        else if (o = this.tokenizer.nptable(e)) e = e.substring(o.raw.length), t.push(
                            o);
                        else if (o = this.tokenizer.hr(e)) e = e.substring(o.raw.length), t.push(o);
                        else if (o = this.tokenizer.blockquote(e)) e = e.substring(o.raw.length), o
                            .tokens = this.blockTokens(o.text, [], n), t.push(o);
                        else if (o = this.tokenizer.list(e)) {
                            for (e = e.substring(o.raw.length), i = o.items.length, r = 0; r < i; r++)
                                o.items[r].tokens = this.blockTokens(o.items[r].text, [], !1);
                            t.push(o)
                        } else if (o = this.tokenizer.html(e)) e = e.substring(o.raw.length), t.push(
                            o);
                        else if (n && (o = this.tokenizer.def(e))) e = e.substring(o.raw.length),
                            this.tokens.links[o.tag] || (this.tokens.links[o.tag] = {
                                href: o.href,
                                title: o.title
                            });
                        else if (o = this.tokenizer.table(e)) e = e.substring(o.raw.length), t.push(
                            o);
                        else if (o = this.tokenizer.lheading(e)) e = e.substring(o.raw.length), t.push(
                            o);
                        else if (n && (o = this.tokenizer.paragraph(e))) e = e.substring(o.raw.length),
                            t.push(o);
                        else if (o = this.tokenizer.text(e, t)) e = e.substring(o.raw.length), o.type ?
                            t.push(o) : (a = t[t.length - 1], a.raw += "\n" + o.raw, a.text += "\n" +
                                o.text);
                        else if (e) {
                            var s = "Infinite loop on byte: " + e.charCodeAt(0);
                            if (this.options.silent) {
                                console.error(s);
                                break
                            }
                            throw new Error(s)
                        }
                        return t
                    }, n.inline = function (e) {
                        var t, n, o, r, i, a, s = e.length;
                        for (t = 0; t < s; t++) switch (a = e[t], a.type) {
                            case "paragraph":
                            case "text":
                            case "heading":
                                a.tokens = [], this.inlineTokens(a.text, a.tokens);
                                break;
                            case "table":
                                for (a.tokens = {
                                        header: [],
                                        cells: []
                                    }, r = a.header.length, n = 0; n < r; n++) a.tokens.header[
                                    n] = [], this.inlineTokens(a.header[n], a.tokens.header[
                                    n]);
                                for (r = a.cells.length, n = 0; n < r; n++)
                                    for (i = a.cells[n], a.tokens.cells[n] = [], o = 0; o < i.length; o++)
                                        a.tokens.cells[n][o] = [], this.inlineTokens(i[o], a.tokens
                                            .cells[n][o]);
                                break;
                            case "blockquote":
                                this.inline(a.tokens);
                                break;
                            case "list":
                                for (r = a.items.length, n = 0; n < r; n++) this.inline(a.items[
                                    n].tokens);
                                break
                        }
                        return e
                    }, n.inlineTokens = function (e, t, n, o) {
                        var r;
                        void 0 === t && (t = []), void 0 === n && (n = !1), void 0 === o && (o = !1);
                        while (e)
                            if (r = this.tokenizer.bilibiliEmoji(e)) e = e.substring(r.raw.length),
                                r.type && t.push(r);
                            else if (r = this.tokenizer.textEmoji(e)) e = e.substring(r.raw.length),
                            r.type && t.push(r);
                        else if (r = this.tokenizer.codeEmoji(e)) e = e.substring(r.raw.length), r.type &&
                            t.push(r);
                        else if (r = this.tokenizer.escape(e)) e = e.substring(r.raw.length), t.push(
                            r);
                        else if (r = this.tokenizer.tag(e, n, o)) e = e.substring(r.raw.length), n =
                            r.inLink, o = r.inRawBlock, t.push(r);
                        else if (r = this.tokenizer.link(e)) e = e.substring(r.raw.length), "link" ===
                            r.type && (r.tokens = this.inlineTokens(r.text, [], !0, o)), t.push(r);
                        else if (r = this.tokenizer.reflink(e, this.tokens.links)) e = e.substring(
                            r.raw.length), "link" === r.type && (r.tokens = this.inlineTokens(r
                            .text, [], !0, o)), t.push(r);
                        else if (r = this.tokenizer.strong(e)) e = e.substring(r.raw.length), r.tokens =
                            this.inlineTokens(r.text, [], n, o), t.push(r);
                        else if (r = this.tokenizer.em(e)) e = e.substring(r.raw.length), r.tokens =
                            this.inlineTokens(r.text, [], n, o), t.push(r);
                        else if (r = this.tokenizer.codespan(e)) e = e.substring(r.raw.length), t.push(
                            r);
                        else if (r = this.tokenizer.br(e)) e = e.substring(r.raw.length), t.push(r);
                        else if (r = this.tokenizer.del(e)) e = e.substring(r.raw.length), r.tokens =
                            this.inlineTokens(r.text, [], n, o), t.push(r);
                        else if (r = this.tokenizer.autolink(e, Z)) e = e.substring(r.raw.length),
                            t.push(r);
                        else if (n || !(r = this.tokenizer.url(e, Z))) {
                            if (r = this.tokenizer.inlineText(e, o, J)) e = e.substring(r.raw.length),
                                t.push(r);
                            else if (e) {
                                var i = "Infinite loop on byte: " + e.charCodeAt(0);
                                if (this.options.silent) {
                                    console.error(i);
                                    break
                                }
                                throw new Error(i)
                            }
                        } else e = e.substring(r.raw.length), t.push(r);
                        return t
                    }, t(e, null, [{
                        key: "rules",
                        get: function () {
                            return {
                                block: G,
                                inline: Q
                            }
                        }
                    }]), e
                }(),
                K = a.defaults,
                ee = T.cleanUrl,
                te = T.escape,
                ne = function () {
                    function e(e) {
                        this.options = e || K
                    }
                    var t = e.prototype;
                    return t.bilibiliEmoji = function (e) {
                        var t = ee(this.options.sanitize, this.options.bilibiliEmojiUrl, e + ".png");
                        return '<span class="emoji-item emoji-animate" data-icon="' + e +
                            '"><img class="img" src="' + t + '" alt=":' + e + ':"></span>'
                    }, t.textEmoji = function (e) {
                        return e
                    }, t.codeEmoji = function (e) {
                        var t = "." + (/.+!$/.test(e) ? "gif" : "png"),
                            n = e.replace(/!$/, ""),
                            o = ee(this.options.sanitize, this.options[(".gif" === t ? "tieba" :
                                "haha") + "EmojiUrl"], "icon_" + n + t);
                        return '<img class="emoji-item emoji-img" data-icon="' + n + '" src="' + o +
                            '" onerror="this.src=\'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==\'" alt=":' +
                            n + ':">'
                    }, t.code = function (e, t, n) {
                        var o = (t || "").match(/\S*/)[0];
                        if (this.options.highlight) {
                            var r = this.options.highlight(e, o);
                            null != r && r !== e && (n = !0, e = r)
                        }
                        return o ? '<pre><code class="' + this.options.langPrefix + te(o, !0) +
                            '">' + (n ? e : te(e, !0)) + "</code></pre>\n" : "<pre><code>" + (n ? e :
                                te(e, !0)) + "</code></pre>\n"
                    }, t.blockquote = function (e) {
                        return "<blockquote>\n" + e + "</blockquote>\n"
                    }, t.html = function (e) {
                        return e
                    }, t.heading = function (e, t, n, o) {
                        return this.options.headerIds ? "<h" + t + ' id="' + this.options.headerPrefix +
                            o.slug(n) + '">' + e + "</h" + t + ">\n" : "<h" + t + ">" + e + "</h" +
                            t + ">\n"
                    }, t.hr = function () {
                        return this.options.xhtml ? "<hr/>\n" : "<hr>\n"
                    }, t.list = function (e, t, n) {
                        var o = t ? "ol" : "ul",
                            r = t && 1 !== n ? ' start="' + n + '"' : "";
                        return "<" + o + r + ">\n" + e + "</" + o + ">\n"
                    }, t.listitem = function (e) {
                        return "<li>" + e + "</li>\n"
                    }, t.checkbox = function (e) {
                        return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox"' +
                            (this.options.xhtml ? " /" : "") + "> "
                    }, t.paragraph = function (e) {
                        return "<p>" + e + "</p>\n"
                    }, t.table = function (e, t) {
                        return t && (t = "<tbody>" + t + "</tbody>"), "<table>\n<thead>\n" + e +
                            "</thead>\n" + t + "</table>\n"
                    }, t.tablerow = function (e) {
                        return "<tr>\n" + e + "</tr>\n"
                    }, t.tablecell = function (e, t) {
                        var n = t.header ? "th" : "td",
                            o = t.align ? "<" + n + ' align="' + t.align + '">' : "<" + n + ">";
                        return o + e + "</" + n + ">\n"
                    }, t.strong = function (e) {
                        return "<strong>" + e + "</strong>"
                    }, t.em = function (e) {
                        return "<em>" + e + "</em>"
                    }, t.codespan = function (e) {
                        return "<code>" + e + "</code>"
                    }, t.br = function () {
                        return this.options.xhtml ? "<br/>" : "<br>"
                    }, t.del = function (e) {
                        return "<del>" + e + "</del>"
                    }, t.link = function (e, t, n) {
                        if (e = ee(this.options.sanitize, this.options.baseUrl, e), null === e)
                            return n;
                        var o = '<a href="' + te(e) + '"';
                        return t && (o += ' title="' + t + '"'), o += ">" + n + "</a>", o
                    }, t.image = function (e, t, n) {
                        if (e = ee(this.options.sanitize, this.options.baseUrl, e), null === e)
                            return n;
                        var o = '<img src="' + e + '" alt="' + n + '"';
                        return t && (o += ' title="' + t + '"'), o += this.options.xhtml ? "/>" :
                            ">", o
                    }, t.text = function (e) {
                        return e
                    }, e
                }(),
                oe = function () {
                    function e() {}
                    var t = e.prototype;
                    return t.strong = function (e) {
                        return e
                    }, t.em = function (e) {
                        return e
                    }, t.codespan = function (e) {
                        return e
                    }, t.del = function (e) {
                        return e
                    }, t.html = function (e) {
                        return e
                    }, t.text = function (e) {
                        return e
                    }, t.link = function (e, t, n) {
                        return "" + n
                    }, t.image = function (e, t, n) {
                        return "" + n
                    }, t.br = function () {
                        return ""
                    }, e
                }(),
                re = function () {
                    function e() {
                        this.seen = {}
                    }
                    var t = e.prototype;
                    return t.slug = function (e) {
                        var t = e.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, "").replace(
                            /[\u2000-\u206F\u2E00-\u2E7F\\'!"#$%&()*+,./:;<=>?@[\]^`{|}~]/g, ""
                        ).replace(/\s/g, "-");
                        if (this.seen.hasOwnProperty(t)) {
                            var n = t;
                            do {
                                this.seen[n]++, t = n + "-" + this.seen[n]
                            } while (this.seen.hasOwnProperty(t))
                        }
                        return this.seen[t] = 0, t
                    }, e
                }(),
                ie = a.defaults,
                ae = T.unescape,
                se = function () {
                    function e(e) {
                        this.options = e || ie, this.options.renderer = this.options.renderer || new ne,
                            this.renderer = this.options.renderer, this.renderer.options = this.options,
                            this.textRenderer = new oe, this.slugger = new re
                    }
                    e.parse = function (t, n) {
                        var o = new e(n);
                        return o.parse(t)
                    };
                    var t = e.prototype;
                    return t.parse = function (e, t) {
                        void 0 === t && (t = !0);
                        var n, o, r, i, a, s, c, l, u, m, p, d, h, f, b, g, y, w, v = "",
                            x = e.length;
                        for (n = 0; n < x; n++) switch (m = e[n], m.type) {
                            case "space":
                                continue;
                            case "hr":
                                v += this.renderer.hr();
                                continue;
                            case "heading":
                                v += this.renderer.heading(this.parseInline(m.tokens), m.depth,
                                    ae(this.parseInline(m.tokens, this.textRenderer)), this
                                    .slugger);
                                continue;
                            case "code":
                                v += this.renderer.code(m.text, m.lang, m.escaped);
                                continue;
                            case "table":
                                for (l = "", c = "", i = m.header.length, o = 0; o < i; o++) c +=
                                    this.renderer.tablecell(this.parseInline(m.tokens.header[o]), {
                                        header: !0,
                                        align: m.align[o]
                                    });
                                for (l += this.renderer.tablerow(c), u = "", i = m.cells.length,
                                    o = 0; o < i; o++) {
                                    for (s = m.tokens.cells[o], c = "", a = s.length, r = 0; r <
                                        a; r++) c += this.renderer.tablecell(this.parseInline(s[
                                        r]), {
                                        header: !1,
                                        align: m.align[r]
                                    });
                                    u += this.renderer.tablerow(c)
                                }
                                v += this.renderer.table(l, u);
                                continue;
                            case "blockquote":
                                u = this.parse(m.tokens), v += this.renderer.blockquote(u);
                                continue;
                            case "list":
                                for (p = m.ordered, d = m.start, h = m.loose, i = m.items.length,
                                    u = "", o = 0; o < i; o++) b = m.items[o], g = b.checked, y =
                                    b.task, f = "", b.task && (w = this.renderer.checkbox(g), h ?
                                        b.tokens.length > 0 && "text" === b.tokens[0].type ? (b
                                            .tokens[0].text = w + " " + b.tokens[0].text, b.tokens[
                                                0].tokens && b.tokens[0].tokens.length > 0 &&
                                            "text" === b.tokens[0].tokens[0].type && (b.tokens[
                                                0].tokens[0].text = w + " " + b.tokens[0].tokens[
                                                0].text)) : b.tokens.unshift({
                                            type: "text",
                                            text: w
                                        }) : f += w), f += this.parse(b.tokens, h), u += this.renderer
                                    .listitem(f, y, g);
                                v += this.renderer.list(u, p, d);
                                continue;
                            case "html":
                                v += this.renderer.html(m.text);
                                continue;
                            case "paragraph":
                                v += this.renderer.paragraph(this.parseInline(m.tokens));
                                continue;
                            case "text":
                                u = m.tokens ? this.parseInline(m.tokens) : m.text;
                                while (n + 1 < x && "text" === e[n + 1].type) m = e[++n], u +=
                                    "\n" + (m.tokens ? this.parseInline(m.tokens) : m.text);
                                v += t ? this.renderer.paragraph(u) : u;
                                continue;
                            default:
                                var k = 'Token with "' + m.type + '" type was not found.';
                                if (this.options.silent) return void console.error(k);
                                throw new Error(k)
                        }
                        return v
                    }, t.parseInline = function (e, t) {
                        t = t || this.renderer;
                        var n, o, r = "",
                            i = e.length;
                        for (n = 0; n < i; n++) switch (o = e[n], o.type) {
                            case "bilibiliEmoji":
                                r += t.bilibiliEmoji ? t.bilibiliEmoji(o.text) : o.text;
                                break;
                            case "textEmoji":
                                r += t.textEmoji(o.text);
                                break;
                            case "codeEmoji":
                                r += t.codeEmoji ? t.codeEmoji(o.text) : o.text;
                                break;
                            case "escape":
                                r += t.text(o.text);
                                break;
                            case "html":
                                r += t.html(o.text);
                                break;
                            case "link":
                                r += t.link(o.href, o.title, this.parseInline(o.tokens, t));
                                break;
                            case "image":
                                r += t.image(o.href, o.title, o.text);
                                break;
                            case "strong":
                                r += t.strong(this.parseInline(o.tokens, t));
                                break;
                            case "em":
                                r += t.em(this.parseInline(o.tokens, t));
                                break;
                            case "codespan":
                                r += t.codespan(o.text);
                                break;
                            case "br":
                                r += t.br();
                                break;
                            case "del":
                                r += t.del(this.parseInline(o.tokens, t));
                                break;
                            case "text":
                                r += t.text(o.text);
                                break;
                            default:
                                var a = 'Token with "' + o.type + '" type was not found.';
                                if (this.options.silent) return void console.error(a);
                                throw new Error(a)
                        }
                        return r
                    }, e
                }(),
                ce = T.merge,
                le = T.checkSanitizeDeprecation,
                ue = T.escape,
                me = a.getDefaults,
                pe = a.changeDefaults,
                de = a.defaults;

            function he(e, t, n) {
                if ("undefined" === typeof e || null === e) throw new Error(
                    "marked(): input parameter is undefined or null");
                if ("string" !== typeof e) throw new Error("marked(): input parameter is of type " +
                    Object.prototype.toString.call(e) + ", string expected");
                if ("function" === typeof t && (n = t, t = null), t = ce({}, he.defaults, t || {}), le(
                        t), n) {
                    var o, r = t.highlight;
                    try {
                        o = X.lex(e, t)
                    } catch (c) {
                        return n(c)
                    }
                    var i = function (e) {
                        var i;
                        if (!e) try {
                            i = se.parse(o, t)
                        } catch (c) {
                            e = c
                        }
                        return t.highlight = r, e ? n(e) : n(null, i)
                    };
                    if (!r || r.length < 3) return i();
                    if (delete t.highlight, !o.length) return i();
                    var a = 0;
                    return he.walkTokens(o, (function (e) {
                        "code" === e.type && (a++, setTimeout((function () {
                            r(e.text, e.lang, (function (t, n) {
                                if (t) return i(t);
                                null != n && n !== e.text && (e
                                    .text = n, e.escaped = !
                                    0), a--, 0 === a && i()
                            }))
                        }), 0))
                    })), void(0 === a && i())
                }
                try {
                    var s = X.lex(e, t);
                    return t.walkTokens && he.walkTokens(s, t.walkTokens), se.parse(s, t)
                } catch (c) {
                    if (c.message += "\nPlease report this to https://github.com/markedjs/marked.", t.silent)
                        return "<p>An error occurred:</p><pre>" + ue(c.message + "", !0) + "</pre>";
                    throw c
                }
            }
            he.options = he.setOptions = function (e) {
                    return ce(he.defaults, e), pe(he.defaults), he
                }, he.getDefaults = me, he.defaults = de, he.use = function (e) {
                    var t = ce({}, e);
                    if (e.renderer && function () {
                            var n = he.defaults.renderer || new ne,
                                o = function (t) {
                                    var o = n[t];
                                    n[t] = function () {
                                        for (var r = arguments.length, i = new Array(r), a = 0; a <
                                            r; a++) i[a] = arguments[a];
                                        var s = e.renderer[t].apply(n, i);
                                        return !1 === s && (s = o.apply(n, i)), s
                                    }
                                };
                            for (var r in e.renderer) o(r);
                            t.renderer = n
                        }(), e.tokenizer && function () {
                            var n = he.defaults.tokenizer || new D,
                                o = function (t) {
                                    var o = n[t];
                                    n[t] = function () {
                                        for (var r = arguments.length, i = new Array(r), a = 0; a <
                                            r; a++) i[a] = arguments[a];
                                        var s = e.tokenizer[t].apply(n, i);
                                        return !1 === s && (s = o.apply(n, i)), s
                                    }
                                };
                            for (var r in e.tokenizer) o(r);
                            t.tokenizer = n
                        }(), e.walkTokens) {
                        var n = he.defaults.walkTokens;
                        t.walkTokens = function (t) {
                            e.walkTokens(t), n && n(t)
                        }
                    }
                    he.setOptions(t)
                }, he.walkTokens = function (e, t) {
                    for (var n, o = r(e); !(n = o()).done;) {
                        var i = n.value;
                        switch (t(i), i.type) {
                            case "table":
                                for (var a, s = r(i.tokens.header); !(a = s()).done;) {
                                    var c = a.value;
                                    he.walkTokens(c, t)
                                }
                                for (var l, u = r(i.tokens.cells); !(l = u()).done;)
                                    for (var m, p = l.value, d = r(p); !(m = d()).done;) {
                                        var h = m.value;
                                        he.walkTokens(h, t)
                                    }
                                break;
                            case "list":
                                he.walkTokens(i.items, t);
                                break;
                            default:
                                i.tokens && he.walkTokens(i.tokens, t)
                        }
                    }
                }, he.Parser = se, he.parser = se.parse, he.Renderer = ne, he.TextRenderer = oe, he.Lexer =
                X, he.lexer = X.lex, he.Tokenizer = D, he.Slugger = re, he.parse = he;
            var fe = he;
            return fe
        }))
    },
    e893: function (e, t, n) {
        var o = n("1a2d"),
            r = n("56ef"),
            i = n("06cf"),
            a = n("9bf2");
        e.exports = function (e, t, n) {
            for (var s = r(t), c = a.f, l = i.f, u = 0; u < s.length; u++) {
                var m = s[u];
                o(e, m) || n && o(n, m) || c(e, m, l(t, m))
            }
        }
    },
    e9ac: function (e, t, n) {
        "use strict";
        e.exports = n("00ce")
    },
    ef10: function (e, t, n) {
        "use strict";
        e.exports = function (e) {
            return !!e
        }
    },
    f058: function (e, t, n) {
        "use strict";
        n.d(t, "a", (function () {
            return r
        }));
        const o = n("fb89");

        function r(e) {
            const t = new DOMParser,
                n = i(t.parseFromString(e, "text/html")),
                r = n.getElementsByClassName("emoji-animate");
            for (let i = 0; i < r.length; i++) {
                const e = r[i].getAttribute("data-icon");
                for (let t = 0; t < o["default"].length; t++) {
                    const n = o["default"][t];
                    if (n.style && n.name === e) {
                        const e = r[i].getElementsByClassName("img")[0];
                        let t = "";
                        Object.keys(n.style).forEach((function (e) {
                            t += e + ":" + n.style[e] + ";"
                        })), e.style.cssText = t;
                        break
                    }
                }
            }
            return n.body.innerHTML
        }

        function i(e) {
            const t = e.getElementsByClassName("emoji-img");
            let n = !0;
            for (let i = 0; i < t.length; i++) {
                const e = t[i].dataset.icon;
                if (!s("tieba", e) && !s("haha", e)) {
                    n = !1;
                    break
                }
            }
            if (n) return e;
            const o = t[0],
                r = o.dataset.icon;
            return s("tieba", r) || s("haha", r) || a(o), i(e)
        }

        function a(e) {
            const t = e.getAttribute("alt"),
                n = document.createTextNode(t);
            e.parentNode.replaceChild(n, e)
        }

        function s(e, t) {
            return o["default"].filter(n => n.category === e && n.name === t).length > 0
        }
    },
    f367: function (e, t, n) {
        "use strict";
        var o = n("d6c7"),
            r = "function" === typeof Symbol && "symbol" === typeof Symbol("foo"),
            i = Object.prototype.toString,
            a = Array.prototype.concat,
            s = Object.defineProperty,
            c = function (e) {
                return "function" === typeof e && "[object Function]" === i.call(e)
            },
            l = function () {
                var e = {};
                try {
                    for (var t in s(e, "x", {
                            enumerable: !1,
                            value: e
                        }), e) return !1;
                    return e.x === e
                } catch (n) {
                    return !1
                }
            },
            u = s && l(),
            m = function (e, t, n, o) {
                (!(t in e) || c(o) && o()) && (u ? s(e, t, {
                    configurable: !0,
                    enumerable: !1,
                    value: n,
                    writable: !0
                }) : e[t] = n)
            },
            p = function (e, t) {
                var n = arguments.length > 2 ? arguments[2] : {},
                    i = o(t);
                r && (i = a.call(i, Object.getOwnPropertySymbols(t)));
                for (var s = 0; s < i.length; s += 1) m(e, i[s], t[i[s]], n[i[s]])
            };
        p.supportsDescriptors = !!u, e.exports = p
    },
    f5df: function (e, t, n) {
        var o = n("da84"),
            r = n("00ee"),
            i = n("1626"),
            a = n("c6b6"),
            s = n("b622"),
            c = s("toStringTag"),
            l = o.Object,
            u = "Arguments" == a(function () {
                return arguments
            }()),
            m = function (e, t) {
                try {
                    return e[t]
                } catch (n) {}
            };
        e.exports = r ? a : function (e) {
            var t, n, o;
            return void 0 === e ? "Undefined" : null === e ? "Null" : "string" == typeof (n = m(t = l(e), c)) ?
                n : u ? a(t) : "Object" == (o = a(t)) && i(t.callee) ? "Arguments" : o
        }
    },
    f6b4: function (e, t, n) {
        "use strict";
        var o = n("c532");

        function r() {
            this.handlers = []
        }
        r.prototype.use = function (e, t, n) {
            return this.handlers.push({
                fulfilled: e,
                rejected: t,
                synchronous: !!n && n.synchronous,
                runWhen: n ? n.runWhen : null
            }), this.handlers.length - 1
        }, r.prototype.eject = function (e) {
            this.handlers[e] && (this.handlers[e] = null)
        }, r.prototype.forEach = function (e) {
            o.forEach(this.handlers, (function (t) {
                null !== t && e(t)
            }))
        }, e.exports = r
    },
    f772: function (e, t, n) {
        var o = n("5692"),
            r = n("90e3"),
            i = o("keys");
        e.exports = function (e) {
            return i[e] || (i[e] = r(e))
        }
    },
    f9af: function (e, t, n) {
        "use strict";
        n.r(t);
        var o = function () {
                var e = this,
                    t = e.$createElement,
                    n = e._self._c || t;
                return n("div", {
                    staticClass: "comment-wrp"
                }, [n("li", {
                    staticClass: "comment",
                    class: e.commentClass,
                    attrs: {
                        id: "comment-" + e.comment.id,
                        itemtype: "http://schema.org/Comment",
                        itemprop: "comment"
                    }
                }, [n("div", {
                    staticClass: "contents"
                }, [n("div", {
                    staticClass: "main shadow"
                }, [n("div", {
                    staticClass: "profile"
                }, [n("a", {
                    attrs: {
                        href: e.comment.authorUrl,
                        rel: "nofollow noopener noreferrer",
                        target: "_blank"
                    }
                }, [n("img", {
                    directives: [{
                        name: "lazy",
                        rawName: "v-lazy",
                        value: e.comment.isAdmin ?
                            e.options.blog_logo :
                            e.avatar,
                        expression: "comment.isAdmin ? options.blog_logo : avatar"
                    }],
                    staticClass: "avatar",
                    attrs: {
                        alt: e.comment.author,
                        height: "80",
                        width: "80"
                    },
                    on: {
                        error: e.handleAvatarError
                    }
                })])]), n("div", {
                    staticClass: "commentinfo"
                }, [n("section", {
                    staticClass: "commeta"
                }, [n("div", {
                        staticClass: "left"
                    }, [n("h4", {
                        staticClass: "author"
                    }, [n("a", {
                        attrs: {
                            href: e.comment
                                .authorUrl,
                            rel: "nofollow noopener noreferrer",
                            target: "_blank"
                        }
                    }, [n("img", {
                            directives: [{
                                name: "lazy",
                                rawName: "v-lazy",
                                value: e
                                    .comment
                                    .isAdmin ?
                                    e
                                    .options
                                    .blog_logo :
                                    e
                                    .avatar,
                                expression: "comment.isAdmin ? options.blog_logo : avatar"
                            }],
                            staticClass: "avatar",
                            attrs: {
                                alt: e.comment
                                    .author,
                                height: "24",
                                width: "24"
                            },
                            on: {
                                error: e
                                    .handleAvatarError
                            }
                        }), e.comment.isAdmin ?
                        n("span", {
                            staticClass: "bb-comment isauthor",
                            attrs: {
                                title: "博主"
                            }
                        }, [e._v("博主")]) :
                        e._e(), e._v(" " +
                            e._s(e.comment.author) +
                            " ")])])]) /*,n("a",{staticClass:"comment-admin-link delete-btn",attrs:{href:"javascript:;"},on:{click:e.handleDeleteClick}},[e._v("删除")])*/ ,
                    n("a", {
                        staticClass: "comment-reply-link",
                        style: e.editing ? "display:block;" :
                            "",
                        attrs: {
                            href: "javascript:;"
                        },
                        on: {
                            click: e.handleReplyClick
                        }
                    }, [e._v("回复")]), n("div", {
                        staticClass: "right"
                    }, [n("div", {
                        staticClass: "info"
                    }, [n("time", {
                            staticClass: "comment-time",
                            attrs: {
                                itemprop: "datePublished",
                                datetime: e.comment
                                    .createTime
                            }
                        }, [e._v("发布于 " + e._s(
                            e.createTimeAgo
                        ) + " ")]), e.configs.showUserAgent ?
                        n("span", {
                            staticClass: "useragent-info",
                            domProps: {
                                innerHTML: e._s(
                                    e.compileUserAgent
                                )
                            }
                        }) : e._e()])])])]), n("div", {
                    staticClass: "body markdown-body"
                }, [n("div", {
                    staticClass: "markdown-content",
                    domProps: {
                        innerHTML: e._s(e.compileContent)
                    }
                })])])]), e.comment.children ? n("ul", {
                    staticClass: "children"
                }, [e._l(e.comment.children, (function (t, o) {
                    return [n("CommentNode", {
                        key: o,
                        attrs: {
                            isChild: !0,
                            targetId: e.targetId,
                            target: e.target,
                            comment: t,
                            options: e.options,
                            configs: e.configs,
                            depth: e.selfAddDepth,
                            parent: e.comment
                        }
                    })]
                }))], 2) : e._e()]), n("CommentEditor", {
                    attrs: {
                        targetId: e.targetId,
                        target: e.target,
                        replyComment: e.comment,
                        options: e.options,
                        configs: e.configs
                    },
                    on: {
                        checkIsAdmin: e.checkIsAdmin
                    }
                })], 1)
            },
            r = [],
            i = (n("2af9"), n("ca00")),
            a = n("2b80"),
            s = n.n(a),
            c = n("e7f9"),
            l = n.n(c),
            u = n("f058"),
            m = n("3f17"),
            p = n("0e4d"),
            d = n("063c"),
            h = {
                name: "CommentNode",
                components: {
                    CommentEditor: m["a"]
                },
                props: {
                    parent: {
                        type: Object,
                        required: !1,
                        default: void 0
                    },
                    depth: {
                        type: Number,
                        required: !1,
                        default: 1
                    },
                    isChild: {
                        type: Boolean,
                        required: !1,
                        default: !1
                    },
                    targetId: {
                        type: Number,
                        required: !1,
                        default: 0
                    },
                    target: {
                        type: String,
                        required: !1,
                        default: "posts",
                        validator: function (e) {
                            return ["posts", "journals", "sheets"].includes(e)
                        }
                    },
                    comment: {
                        type: Object,
                        required: !1,
                        default: () => {}
                    },
                    options: {
                        type: Object,
                        required: !1,
                        default: () => {}
                    },
                    configs: {
                        type: Object,
                        required: !0
                    }
                },
                data() {
                    return {
                        editing: !1,
                        globalData: p["a"]
                    }
                },
                created() {
                    const e = {
                        image(e, t) {
                            return `<a data-fancybox target="_blank" rel="noopener noreferrer nofollow" href="${e}"><img src="${e}" class="lazyload comment_inline_img" onerror="this.src='https://cdn.jsdelivr.net/gh/qiushaocloud/cdn-static@master/halo-comment/img_error.svg'"></a>`
                        },
                        link(e, t, n) {
                            return `<a href="${e}" title="${n}" target="_blank" rel="noopener noreferrer nofollow">${n}</a>`
                        }
                    };
                    l.a.use({
                        renderer: e
                    })
                },
                computed: {
                    avatar() {
                        if (this.comment.avatarFromContent) return this.comment.avatarFromContent; {
                            const e = this.configs.gravatarSource || this.options.gravatar_source || this.configs
                                .gravatarSourceDefault;
                            return `${e}/${this.comment.gravatarMd5}?s=256&d=${this.options.comment_gravatar_default}`
                        }
                    },
                    compileContent() {
                        var e = "";
                        void 0 != this.parent && (e = '<a href="' + this.parent.authorUrl +
                            '" class="comment-at" rel="noopener noreferrer nofollow"> @' + this.parent.author +
                            " </a>");
                        const t = l()(e + this.comment.content),
                            n = Object(u["a"])(t);
                        return Object(i["h"])(n)
                    },
                    createTimeAgo() {
                        return Object(i["j"])(this.comment.createTime)
                    },
                    compileUserAgent() {
                        if (!this.comment.userAgent) return "";
                        var e = new s.a;
                        e.setUA(this.comment.userAgent);
                        var t = e.getResult();
                        if (!t.browser.name) return "";
                        var n =
                            "https://cdn.jsdelivr.net/gh/qiushaocloud/cdn-static@master/halo-comment/ua/svg/" +
                            t.browser.name.toLowerCase() + ".svg",
                            o = "";
                        switch (t.os.name) {
                            case "Windows":
                                switch (t.os.version) {
                                    case "7":
                                    case "8":
                                    case "10":
                                        o =
                                            "https://cdn.jsdelivr.net/gh/qiushaocloud/cdn-static@master/halo-comment/ua/svg/windows_win" +
                                            t.os.version + ".svg";
                                        break;
                                    case "":
                                        o =
                                            "https://cdn.jsdelivr.net/gh/qiushaocloud/cdn-static@master/halo-comment/ua/svg/windows_" +
                                            t.os.version + ".svg";
                                        break;
                                    default:
                                        o =
                                            "https://cdn.jsdelivr.net/gh/qiushaocloud/cdn-static@master/halo-comment/ua/svg/windows.svg";
                                        break
                                }
                                break;
                            default:
                                o =
                                    "https://cdn.jsdelivr.net/gh/qiushaocloud/cdn-static@master/halo-comment/ua/svg/" +
                                    t.os.name.replace(/\s+/g, "").toLowerCase() + ".svg";
                                break
                        }
                        let r =
                            `（<img src="${n}" onerror="this.src='https://cdn.jsdelivr.net/gh/qiushaocloud/cdn-static@master/halo-comment/ua/svg/unknow.svg'" alt="ua-browser"/>  ${t.browser.name} ${t.browser.version} <img src="${o}" onerror="this.src='https://cdn.jsdelivr.net/gh/qiushaocloud/cdn-static@master/halo-comment/ua/svg/unknow.svg'" alt="ua-os"/> ${t.os.name} ${t.os.version}）`;
                        return this.configs.isGetIpLocation && this.comment.ipLocation && (r +=
                            `「${this.comment.ipLocation}」`), r
                    },
                    selfAddDepth() {
                        return this.depth + 1
                    },
                    commentClass() {
                        return "depth-" + this.depth + " comment-" + this.comment.id
                    }
                },
                methods: {
                    handleReplyClick(e) {
                        e.stopPropagation(), this.globalData.replyId = this.comment.id
                    },
                    handleDeleteClick(e) {
                        e.stopPropagation();
                        const {
                            id: t,
                            parentId: n
                        } = this.comment;
                        d["a"].deleteComment(this.target, t, this.configs).then(e => {
                            console.log("deleteComment response:", e.data, " ,commentId:", t), this.$tips(
                                "删除评论成功", 5e3, this);
                            const o = document.getElementById("comment-" + t),
                                r = o && o.querySelector("ul.children");
                            if (o && r && o.removeChild(r), 0 === n) this.$emit("deletedRootCommenNode",
                                t);
                            else {
                                const e = o.parentNode;
                                e.removeChild(o), "comment-wrp" === e.className && e.parentNode.removeChild(
                                    e)
                            }
                        }).catch(e => {
                            console.error("deleteComment err:", e.response, " ,commentId:", t), e.response &&
                                e.response.data && e.response.data.message && this.$tips("删除评论失败, " + e
                                    .response.data.message, 5e3, this)
                        })
                    },
                    handleTopClick(e) {
                        e.stopPropagation(), console.error("置顶功能等待开发")
                    },
                    handleAvatarError(e) {
                        const t = e.target || e.srcElement;
                        t.src = this.configs.avatarError, t.onerror = null
                    },
                    checkIsAdmin(...e) {
                        this.$emit("checkIsAdmin", ...e)
                    }
                }
            },
            f = h,
            b = n("2877"),
            g = Object(b["a"])(f, o, r, !1, null, null, null, !0);
        t["default"] = g.exports
    },
    fb89: function (e, t, n) {
        "use strict";
        n.r(t);
        class o {
            constructor(e, t, n, o) {
                this.name = e, this.description = t, this.category = n, this.style = o, this.extension = [
                    "tieba"].includes(n) ? "gif" : "png"
            }
        }
        const r = [new o("kuxiao", "哭笑", "haha"), new o("heng", "哼", "haha"), new o("guzhang", "鼓掌", "haha"),
                new o("haha", "哈哈", "haha"), new o("aini", "爱你", "haha"), new o("bazhang", "巴掌", "haha"), new o(
                    "beishang", "悲伤", "haha"), new o("han", "汗", "haha"), new o("deyi", "得意", "haha"), new o(
                    "ok", "ok", "haha"), new o("touxiao", "偷笑", "haha"), new o("wabikong", "挖鼻孔", "haha"), new o(
                    "weiqu", "委屈", "haha"), new o("weixiao", "微笑", "haha"), new o("huaixiao", "坏笑", "haha"),
                new o("woshou", "握手", "haha"), new o("wulian", "捂脸", "haha"), new o("xiaku", "吓哭", "haha"), new o(
                    "xiaoku", "笑哭", "haha"), new o("xixi", "嘻嘻", "haha"), new o("qinqin", "亲亲", "haha"), new o(
                    "qiwang", "期望", "haha"), new o("chanzui", "馋嘴", "haha"), new o("huaxin", "花心", "haha"), new o(
                    "hufen", "互粉", "haha"), new o("keai", "可爱", "haha"), new o("kelian", "可怜", "haha"), new o(
                    "bishi", "鄙视", "haha"), new o("bizui", "闭嘴", "haha"), new o("yep", "耶", "haha"), new o(
                    "zan", "赞", "haha"), new o("yihuo", "疑惑", "haha"), new o("yinxiao", "阴笑", "haha"), new o(
                    "yiwen", "疑问", "haha"), new o("bujiandan", "不简单", "haha"), new o("bye", "拜拜", "haha"), new o(
                    "chigua", "吃瓜", "haha"), new o("chijing", "吃惊", "haha"), new o("chuitou", "锤头", "haha"),
                new o("dahaqian", "打哈欠", "haha"), new o("fahuo", "发火", "haha"), new o("bang", "棒", "haha"), new o(
                    "gou", "狗", "haha"), new o("guolai", "过来", "haha"), new o("haixiu", "害羞", "haha"), new o(
                    "hashiiqi", "哈士奇", "haha"), new o("heixian", "黑线", "haha"), new o("kouzhao", "口罩", "haha"),
                new o("kulou", "骷髅", "haha"), new o("kun", "困", "haha"), new o("landelini", "懒得理你", "haha"),
                new o("mao", "猫", "haha"), new o("outu", "呕吐", "haha"), new o("qian", "钱", "haha"), new o(
                    "quantou", "拳头", "haha"), new o("shaoerbuyi", "少儿不宜", "haha"), new o("shayan", "傻眼", "haha"),
                new o("shengbing", "生病", "haha"), new o("tushetou", "吐舌头", "haha"), new o("shuijiao", "睡觉",
                    "haha"), new o("sikao", "思考", "haha"), new o("shiwang", "失望", "haha"), new o("taikaixin",
                    "太开心", "haha"), new o("tear", "流泪", "haha"), new o("tianping", "舔屏", "haha"), new o("xu",
                    "嘘", "haha"), new o("youhengheng", "右哼哼", "haha"), new o("yun", "晕", "haha"), new o(
                    "zhouma", "咒骂", "haha"), new o("zhuakuang", "抓狂", "haha"), new o("zuohengheng", "左哼哼",
                    "haha"), new o("zuoyi", "作揖", "haha")],
            i = [new o("baiyan", "白眼", "bilibili", {
                "animation-duration": "1800ms",
                "animation-timing-function": "steps(45)",
                transform: "translateY(-1408px)",
                height: "1440px"
            }), new o("fadai", "发呆", "bilibili", {
                "animation-duration": "1080ms",
                "animation-timing-function": "steps(27)",
                transform: "translateY(-832px)",
                height: "864px"
            }), new o("koubi", "抠鼻", "bilibili", {
                "animation-duration": "1200ms",
                "animation-timing-function": "steps(30)",
                transform: "translateY(-928px)",
                height: "960px"
            }), new o("qinqin", "亲亲", "bilibili", {
                "animation-duration": "280ms",
                "animation-timing-function": "steps(7)",
                transform: "translateY(-192px)",
                height: "224px"
            }), new o("weiqu", "委屈", "bilibili", {
                "animation-duration": "800ms",
                "animation-timing-function": "steps(20)",
                transform: "translateY(-608px)",
                height: "640px"
            }), new o("bishi", "鄙视", "bilibili", {
                "animation-duration": "360ms",
                "animation-timing-function": "steps(9)",
                transform: "translateY(-256px)",
                height: "288px"
            }), new o("fanu", "发怒", "bilibili", {
                "animation-duration": "1320ms",
                "animation-timing-function": "steps(33)",
                transform: "translateY(-1024px)",
                height: "1056px"
            }), new o("kun", "困", "bilibili", {
                "animation-duration": "1760ms",
                "animation-timing-function": "steps(44)",
                transform: "translateY(-1376px)",
                height: "1408px"
            }), new o("se", "色", "bilibili", {
                "animation-duration": "400ms",
                "animation-timing-function": "steps(10)",
                transform: "translateY(-288px)",
                height: "320px"
            }), new o("weixiao", "微笑", "bilibili", {
                "animation-duration": "800ms",
                "animation-timing-function": "steps(20)",
                transform: "translateY(-608px)",
                height: "640px"
            }), new o("bizui", "闭嘴", "bilibili", {
                "animation-duration": "1240ms",
                "animation-timing-function": "steps(31)",
                transform: "translateY(-960px)",
                height: "992px"
            }), new o("ganga", "尴尬", "bilibili", {
                "animation-duration": "1520ms",
                "animation-timing-function": "steps(38)",
                transform: "translateY(-1184px)",
                height: "1216px"
            }), new o("lengmo", "冷漠", "bilibili", {
                "animation-duration": "40ms",
                "animation-timing-function": "steps(1)",
                transform: "translateY(-0px)",
                height: "32px"
            }), new o("shengbing", "生病", "bilibili", {
                "animation-duration": "1400ms",
                "animation-timing-function": "steps(35)",
                transform: "translateY(-1088px)",
                height: "1120px"
            }), new o("wunai", "无奈", "bilibili", {
                "animation-duration": "920ms",
                "animation-timing-function": "steps(23)",
                transform: "translateY(-704px)",
                height: "736px"
            }), new o("chan", "馋", "bilibili", {
                "animation-duration": "1600ms",
                "animation-timing-function": "steps(40)",
                transform: "translateY(-1248px)",
                height: "1280px"
            }), new o("guilian", "鬼脸", "bilibili", {
                "animation-duration": "40ms",
                "animation-timing-function": "steps(1)",
                transform: "translateY(-0px)",
                height: "32px"
            }), new o("liubixue", "流鼻血", "bilibili", {
                "animation-duration": "1400ms",
                "animation-timing-function": "steps(35)",
                transform: "translateY(-1088px)",
                height: "1120px"
            }), new o("shengqi", "生气", "bilibili", {
                "animation-duration": "440ms",
                "animation-timing-function": "steps(11)",
                transform: "translateY(-320px)",
                height: "352px"
            }), new o("xiaoku", "笑哭", "bilibili", {
                "animation-duration": "600ms",
                "animation-timing-function": "steps(15)",
                transform: "translateY(-448px)",
                height: "480px"
            }), new o("daku", "大哭", "bilibili", {
                "animation-duration": "320ms",
                "animation-timing-function": "steps(8)",
                transform: "translateY(-224px)",
                height: "256px"
            }), new o("guzhang", "鼓掌", "bilibili", {
                "animation-duration": "680ms",
                "animation-timing-function": "steps(17)",
                transform: "translateY(-512px)",
                height: "544px"
            }), new o("liuhan", "流汗", "bilibili", {
                "animation-duration": "1080ms",
                "animation-timing-function": "steps(27)",
                transform: "translateY(-832px)",
                height: "864px"
            }), new o("shuizhao", "睡着", "bilibili", {
                "animation-duration": "960ms",
                "animation-timing-function": "steps(24)",
                transform: "translateY(-736px)",
                height: "768px"
            }), new o("xieyanxiao", "斜眼笑", "bilibili", {
                "animation-duration": "320ms",
                "animation-timing-function": "steps(8)",
                transform: "translateY(-224px)",
                height: "256px"
            }), new o("dalao", "大佬", "bilibili", {
                "animation-duration": "1320ms",
                "animation-timing-function": "steps(33)",
                transform: "translateY(-1024px)",
                height: "1056px"
            }), new o("haixiu", "害羞", "bilibili", {
                "animation-duration": "1240ms",
                "animation-timing-function": "steps(31)",
                transform: "translateY(-960px))",
                height: "992px"
            }), new o("liulei", "流泪", "bilibili", {
                "animation-duration": "40ms",
                "animation-timing-function": "steps(1)",
                transform: "translateY(-0px)",
                height: "32px"
            }), new o("sikao", "思考", "bilibili", {
                "animation-duration": "1440ms",
                "animation-timing-function": "steps(36)",
                transform: "translateY(-1120px)",
                height: "1152px"
            }), new o("yiwen", "疑问", "bilibili", {
                "animation-duration": "840ms",
                "animation-timing-function": "steps(21)",
                transform: "translateY(-640px)",
                height: "672px"
            }), new o("dalian", "打脸", "bilibili", {
                "animation-duration": "1480ms",
                "animation-timing-function": "steps(37)",
                transform: "translateY(-1152px)",
                height: "1184px"
            }), new o("heirenwenhao", "黑人问号", "bilibili", {
                "animation-duration": "1040ms",
                "animation-timing-function": "steps(26)",
                transform: "translateY(-800px)",
                height: "832px"
            }), new o("miantian", "腼腆", "bilibili", {
                "animation-duration": "1120ms",
                "animation-timing-function": "steps(28)",
                transform: "translateY(-864px)",
                height: "896px"
            }), new o("tiaokan", "调侃", "bilibili", {
                "animation-duration": "40ms",
                "animation-timing-function": "steps(1)",
                transform: "translateY(-0px)",
                height: "32px"
            }), new o("yun", "晕", "bilibili", {
                "animation-duration": "480ms",
                "animation-timing-function": "steps(12)",
                transform: "translateY(-352px)",
                height: "384px"
            }), new o("dianzan", "点赞", "bilibili", {
                "animation-duration": "800ms",
                "animation-timing-function": "steps(20)",
                transform: "translateY(-608px)",
                height: "640px"
            }), new o("huaixiao", "坏笑", "bilibili", {
                "animation-duration": "1240ms",
                "animation-timing-function": "steps(31)",
                transform: "translateY(-960px)",
                height: "992px"
            }), new o("mudengkoudai", "目瞪口呆", "bilibili", {
                "animation-duration": "40ms",
                "animation-timing-function": "steps(1)",
                transform: "translateY(-0px)",
                height: "32px"
            }), new o("tiaopi", "调皮", "bilibili", {
                "animation-duration": "2000ms",
                "animation-timing-function": "steps(50)",
                transform: "translateY(-1568px)",
                height: "1600px"
            }), new o("zaijian", "再见", "bilibili", {
                "animation-duration": "960ms",
                "animation-timing-function": "steps(24)",
                transform: "translateY(-736px)",
                height: "768px"
            }), new o("doge", "狗头", "bilibili", {
                "animation-duration": "800ms",
                "animation-timing-function": "steps(20)",
                transform: "translateY(-608px)",
                height: "640px"
            }), new o("jingxia", "惊吓", "bilibili", {
                "animation-duration": "1280ms",
                "animation-timing-function": "steps(32)",
                transform: "translateY(-992px)",
                height: "1024px"
            }), new o("nanguo", "难过", "bilibili", {
                "animation-duration": "1120ms",
                "animation-timing-function": "steps(28)",
                transform: "translateY(-864px)",
                height: "896px"
            }), new o("touxiao", "偷笑", "bilibili", {
                "animation-duration": "240ms",
                "animation-timing-function": "steps(6)",
                transform: "translateY(-160px)",
                height: "192px"
            }), new o("zhoumei", "皱眉", "bilibili", {
                "animation-duration": "40ms",
                "animation-timing-function": "steps(1)",
                transform: "translateY(-0px)",
                height: "32px"
            }), new o("facai", "发财", "bilibili", {
                "animation-duration": "1200ms",
                "animation-timing-function": "steps(30)",
                transform: "translateY(-928px)",
                height: "960px"
            }), new o("keai", "可爱", "bilibili", {
                "animation-duration": "680ms",
                "animation-timing-function": "steps(17)",
                transform: "translateY(-512px)",
                height: "544px"
            }), new o("outu", "呕吐", "bilibili", {
                "animation-duration": "1680ms",
                "animation-timing-function": "steps(42)",
                transform: "translateY(-1312px)",
                height: "1344px"
            }), new o("tuxue", "吐血", "bilibili", {
                "animation-duration": "320ms",
                "animation-timing-function": "steps(8)",
                transform: "translateY(-224px)",
                height: "256px"
            }), new o("zhuakuang", "抓狂", "bilibili", {
                "animation-duration": "760ms",
                "animation-timing-function": "steps(19)",
                transform: "translateY(-576px)",
                height: "608px"
            })],
            a = [new o("tongue", "吐舌", "tieba"), new o("theblackline", "尴尬", "tieba"), new o("tear", "大哭",
                    "tieba"), new o("surprised", "惊哭", "tieba"), new o("surprised2", "惊讶", "tieba"), new o(
                    "spray", "喷", "tieba"), new o("spit", "呕吐", "tieba"), new o("smilingeyes", "笑眼", "tieba"),
                new o("shui", "睡觉", "tieba"), new o("shame", "羞辱", "tieba"), new o("se", "色", "tieba"), new o(
                    "rmb", "钱", "tieba"), new o("reluctantly", "勉强", "tieba"), new o("rbq", "观望", "tieba"), new o(
                    "niconiconi", "爱你", "tieba"), new o("naive", "天真", "tieba"), new o("ku", "酷", "tieba"), new o(
                    "huaji", "滑稽", "tieba"), new o("hu", "呼", "tieba"), new o("han", "汗", "tieba"), new o(
                    "haha", "哈哈", "tieba"), new o("good", "棒", "tieba"), new o("doubt", "疑惑", "tieba"), new o(
                    "britan", "茶", "tieba"), new o("bbd", "棒棒哒", "tieba"), new o("awesome", "强", "tieba"), new o(
                    "anger", "愤怒", "tieba"), new o("aa", "啊啊", "tieba"), new o("happy", "高兴", "tieba"), new o(
                    "grievance", "郁闷", "tieba")],
            s = [new o("(⌒▽⌒)", "(⌒▽⌒)", "menhera"), new o("(￣▽￣)", "(￣▽￣)", "menhera"), new o("(=・ω・=)",
                    "(=・ω・=)", "menhera"), new o("(｀・ω・´)", "(｀・ω・´)", "menhera"), new o("(〜￣△￣)〜", "(〜￣△￣)〜",
                    "menhera"), new o("(･∀･)", "(･∀･)", "menhera"), new o("(°∀°)ﾉ", "(°∀°)ﾉ", "menhera"), new o(
                    "(￣3￣)", "(￣3￣)", "menhera"), new o("╮(￣▽￣)╭", "╮(￣▽￣)╭", "menhera"), new o("(´_ゝ｀)",
                    "(´_ゝ｀)", "menhera"), new o("←_←", "←_←", "menhera"), new o("→_→", "→_→", "menhera"), new o(
                    "(<_<)", "(<_<)", "menhera"), new o("(>_>)", "(>_>)", "menhera"), new o("(;¬_¬)", "(;¬_¬)",
                    "menhera"), new o("(▔□▔)/", "(▔□▔)/", "menhera"), new o("(ﾟДﾟ≡ﾟдﾟ)!?", "(ﾟДﾟ≡ﾟдﾟ)!?",
                    "menhera"), new o("Σ(ﾟдﾟ;)", "Σ(ﾟдﾟ;)", "menhera"), new o("Σ(￣□￣||)", "Σ(￣□￣||)", "menhera"),
                new o("(’；ω；‘)", "(’；ω；‘)", "menhera"), new o("（/TДT)/", "（/TДT)/", "menhera"), new o(
                    "(^・ω・^ )", "(^・ω・^ )", "menhera"), new o("(｡･ω･｡)", "(｡･ω･｡)", "menhera"), new o(
                    "(●￣(ｴ)￣●)", "(●￣(ｴ)￣●)", "menhera"), new o("ε=ε=(ノ≧∇≦)ノ", "ε=ε=(ノ≧∇≦)ノ", "menhera"), new o(
                    "(’･_･‘)", "(’･_･‘)", "menhera"), new o("(-_-#)", "(-_-#)", "menhera"), new o("（￣へ￣）",
                    "（￣へ￣）", "menhera"), new o("(￣ε(#￣)Σ", "(￣ε(#￣)Σ", "menhera"), new o("ヽ(‘Д’)ﾉ", "ヽ(‘Д’)ﾉ",
                    "menhera"), new o("（#-_-)┯━┯", "（#-_-)┯━┯", "menhera"), new o("(╯°口°)╯(┴—┴", "(╯°口°)╯(┴—┴",
                    "menhera"), new o("←◡←", "←◡←", "menhera"), new o("( ♥д♥)", "( ♥д♥)", "menhera"), new o(
                    "_(:3」∠)_", "_(:3」∠)_", "menhera"), new o("Σ>―(〃°ω°〃)♡→", "Σ>―(〃°ω°〃)♡→", "menhera"), new o(
                    "⁄(⁄ ⁄•⁄ω⁄•⁄ ⁄)⁄", "⁄(⁄ ⁄•⁄ω⁄•⁄ ⁄)⁄", "menhera"), new o("(╬ﾟдﾟ)▄︻┻┳═一", "(╬ﾟдﾟ)▄︻┻┳═一",
                    "menhera"), new o("･*･:≡(　ε:)", "･*･:≡(　ε:)", "menhera"), new o("(笑)", "(笑)", "menhera"),
                new o("(汗)", "(汗)", "menhera"), new o("(泣)", "(泣)", "menhera"), new o("(苦笑)", "(苦笑)", "menhera")
                ];
        t["default"] = [...r, ...i, ...a, ...s]
    },
    fc6a: function (e, t, n) {
        var o = n("44ad"),
            r = n("1d80");
        e.exports = function (e) {
            return o(r(e))
        }
    },
    fdbf: function (e, t, n) {
        var o = n("4930");
        e.exports = o && !Symbol.sham && "symbol" == typeof Symbol.iterator
    },
    fffd: function (e, t, n) {
        "use strict";
        var o = n("00ce"),
            r = n("a0d3"),
            i = o("%TypeError%");
        e.exports = function (e, t) {
            if ("Object" !== e.Type(t)) return !1;
            var n = {
                "[[Configurable]]": !0,
                "[[Enumerable]]": !0,
                "[[Get]]": !0,
                "[[Set]]": !0,
                "[[Value]]": !0,
                "[[Writable]]": !0
            };
            for (var o in t)
                if (r(t, o) && !n[o]) return !1;
            if (e.IsDataDescriptor(t) && e.IsAccessorDescriptor(t)) throw new i(
                "Property Descriptors may not be both accessor and data descriptors");
            return !0
        }
    }
});
//# sourceMappingURL=halo-comment.min.js.map