<img src="https://cdn.jsdelivr.net/gh/qinhua/halo-theme-joe2.0@master/source/img/logo.png" style="width:6vw;min-width:90px;" alt="Joe2.0">

<!-- # **Joe2.0** -->

> 一款简单的 Halo 博客主题

- 简洁 + 轻量化配置
- Freemarker 渲染
- 浅色/暗黑模式切换

[GitHub](https://github.com/qinhua/halo-theme-joe2.0)
[马上开始](#readme)
